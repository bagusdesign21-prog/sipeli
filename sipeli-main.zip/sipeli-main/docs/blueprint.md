# **App Name**: SI-PELITA

## Core Features:

- Document Builder: Automates report generation (LPJ, APBDes) using templates, internal data, and generative AI for narrative sections. This includes an AI tool for generating narrative sections based on data analysis.
- Digital Guestbook & SKM Sentiment Analysis: Replaces physical guestbooks; uses AI to analyze survey responses, identify key issues (e.g., service delays), and suggest actionable improvements. The AI tool will analyze text and categorize it into key issues.
- Online Form & Document Upload: Enables citizens to update data (KK/KTP) and Kasi Kesejahteraan to upload project photos with geotagging for real-time progress reports.
- Real-time Announcement: Displays important information (Musdes schedules, report deadlines) with instant updates using Firestore snapshot listeners.

## Style Guidelines:

- Background: Light Cream (#FAF9F6) for form and dashboard pages to reduce eye strain.
- Primary: Soft Peach (#FFDAB9) for header and main menu cards, creating a welcoming feel.
- Accent: Muted Teal (#66CDAA) for call-to-action buttons and status indicators (e.g., 'Verified').
- PT Sans: Bold for titles, regular for body text to ensure high readability in long reports.
- Flat Modern Icons: Home, Reports, Archive, Profile—with simple fade-in transitions.
- Mobile Responsive: Ensure all layouts adapt to different screen sizes.
- Subtle transitions when changing sections, never use obtrusive or distracting animations.