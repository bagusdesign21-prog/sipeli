
/**
 * @fileoverview This file contains the static data used to seed the Firestore database.
 * It includes data for villages, officials (pejabat), and legal documents.
 */
import { serviceHistoryData } from '../src/lib/data-riwayat';

export const usersData = [
    {
        email: 'admin@sipelita.id',
        password: 'password123',
        role: 'admin',
        fullName: 'Admin Kecamatan',
        nik: '1111222233334444',
        desa: 'Kantor Kecamatan'
    },
    {
        email: 'pegawai@sipelita.id',
        password: 'password123',
        role: 'perangkat',
        fullName: 'Pegawai Contoh',
        nik: '5555666677778888',
        desa: 'Sidomulyo'
    },
    {
        email: 'warga@sipelita.id',
        password: 'password123',
        role: 'warga',
        fullName: 'Warga Contoh',
        nik: '9999888877776666',
        desa: 'Keluang'
    },
    {
        email: 'bagusdewidn@gmail.com',
        password: 'password123',
        role: 'admin',
        fullName: 'Bagusdewi D.N',
        nik: '1234567890123456',
        desa: 'Sidomulyo'
    }
];


export const villagesData = [
    { id: '01', name: "Sidomulyo", kades: "Sudarman", operator: "Romarta Picu Tatoles", luas: "45.2", penduduk: "3,240", kk: "850", status: "Definitif", potensi: "Perdagangan & Jasa", desc: "Desa Sidomulyo adalah ibu kota kecamatan yang menjadi pusat pemerintahan dan perdagangan, dengan fasilitas publik yang lengkap.", imgColor: "bg-blue-500" },
    { id: '02', name: "Keluang", kades: "Robinhar", operator: "Arliandy", luas: "38.5", penduduk: "2,890", kk: "720", status: "Definitif", potensi: "Perkebunan Karet", desc: "Desa Keluang merupakan sentra perkebunan karet rakyat terbesar di wilayah ini, dengan masyarakat yang aktif bergotong royong.", imgColor: "bg-green-500" },
    { id: '03', name: "Bentayan", kades: "Sazali, ST", operator: "Yasir Arafat", luas: "42.1", penduduk: "3,100", kk: "780", status: "Definitif", potensi: "Minyak Bumi & Sawit", desc: "Bentayan memiliki potensi sumber daya alam strategis berupa minyak bumi dan perkebunan kelapa sawit yang luas.", imgColor: "bg-orange-500" },
    { id: '04', name: "Bumi Serdang", kades: "Wayan Muliarta", operator: "Yuli Suryadi", luas: "28.4", penduduk: "1,850", kk: "460", status: "Definitif", potensi: "Pertanian & Peternakan", desc: "Desa eks-transmigrasi yang unggul dalam pertanian tanaman pangan dan peternakan sapi terintegrasi.", imgColor: "bg-yellow-500" },
    { id: '05', name: "Teluk Tenggulang", kades: "Erpendi, S.I.P", operator: "Supradinata", luas: "35.6", penduduk: "2,450", kk: "610", status: "Definitif", potensi: "Perikanan & Sungai", desc: "Terletak di jalur perairan, desa ini memiliki potensi perikanan tangkap dan budidaya yang menjanjikan.", imgColor: "bg-cyan-500" },
    { id: '06', name: "Suka Jaya", kades: "Eka Sutrisna", operator: "Saiful Anwar", luas: "30.2", penduduk: "2,100", kk: "525", status: "Definitif", potensi: "Hortikultura", desc: "Pemasok sayur-mayur dan buah-buahan lokal, Suka Jaya memiliki tanah yang subur untuk hortikultura.", imgColor: "bg-emerald-500" },
    { id: '07', name: "Suka Karya", kades: "Misiana", operator: "Winda Puji Lestari", luas: "29.8", penduduk: "1,980", kk: "495", status: "Definitif", potensi: "UMKM & Kerajinan", desc: "Desa yang aktif memberdayakan perempuan melalui kelompok UMKM pengolahan pangan dan kerajinan tangan.", imgColor: "bg-pink-500" },
    { id: '08', name: "Panca Mulya", kades: "Tusriah", operator: "Dedi Saputra", luas: "31.5", penduduk: "2,200", kk: "550", status: "Definitif", potensi: "Pertanian Terpadu", desc: "Mengembangkan sistem pertanian terpadu antara perkebunan sawit dan peternakan kambing.", imgColor: "bg-indigo-500" },
    { id: '09', name: "Suka Raja", kades: "Sahid", operator: "Rukhman", luas: "27.9", penduduk: "1,750", kk: "440", status: "Definitif", potensi: "Perkebunan", desc: "Fokus pada perkebunan karet dan sawit mandiri, masyarakat Suka Raja dikenal ulet dan produktif.", imgColor: "bg-teal-500" },
    { id: '10', name: "Suka Mulya", kades: "Sucipto", operator: "Heri Susilo", luas: "33.4", penduduk: "2,340", kk: "585", status: "Definitif", potensi: "Sawit Plasma", desc: "Bekerjasama dengan perusahaan sekitar dalam skema plasma sawit, meningkatkan kesejahteraan petani.", imgColor: "bg-lime-500" },
    { id: '11', name: "Karang Mulya", kades: "Muhtar", operator: "Mujiono", luas: "25.6", penduduk: "1,650", kk: "415", status: "Definitif", potensi: "Peternakan Unggas", desc: "Menjadi sentra peternakan ayam potong yang memasok kebutuhan pasar kecamatan dan sekitarnya.", imgColor: "bg-red-500" },
    { id: '12', name: "Karang Anyar", kades: "Ngatimin", operator: "Supriadi", luas: "26.8", penduduk: "1,720", kk: "430", status: "Definitif", potensi: "Perkebunan Campuran", desc: "Mengembangkan pola tanam tumpang sari yang memaksimalkan hasil lahan perkebunan.", imgColor: "bg-amber-500" },
    { id: '13', name: "Karang Asem", kades: "Warso", operator: "I Gede Suliwan", luas: "24.5", penduduk: "1,590", kk: "400", status: "Definitif", potensi: "Seni & Budaya", desc: "Kental dengan budaya Bali, Karang Asem aktif melestarikan kesenian tradisional di tengah masyarakat majemuk.", imgColor: "bg-violet-500" },
    { id: '14', name: "Marga Rahayu", kades: "Solihin", operator: "Dyah Putri Utari", luas: "36.7", penduduk: "2,560", kk: "640", status: "Definitif", potensi: "Agrowisata", desc: "Merintis konsep desa wisata berbasis perkebunan buah dan pemancingan alami.", imgColor: "bg-rose-500" }
];

export const pejabatData = [
    { id: '1', nama: "Yudianto I.K., S.Sos", jabatan: "Camat Tungkal Ilir", nip: "19700724 199303 1 001", pangkat: "Pembina Tk.I", eselon: "III.a", color: "bg-blue-100", textColor: "text-blue-600" },
    { id: '2', nama: "Seman, S.Pd., M.Si", jabatan: "Sekretaris Kecamatan", nip: "19680309 199308 1 001", pangkat: "Pembina", eselon: "III.b", color: "bg-emerald-100", textColor: "text-emerald-600" },
    { id: '3', nama: "Iswadi Idris, S.IP", jabatan: "Kasubbag Umum & Kepegawaian", nip: "19791217 201001 1 004", pangkat: "Penata Tk.I", eselon: "IV.b", color: "bg-orange-100", textColor: "text-orange-600" },
    { id: '4', nama: "Ihwanul Mukorib, S.IP", jabatan: "Kasubbag Keuangan & Perencanaan", nip: "19791215 201001 1 005", pangkat: "Penata Tk.I", eselon: "IV.b", color: "bg-amber-100", textColor: "text-amber-600" },
    { id: '5', nama: "Yesriana, SE", jabatan: "Kasi PMD", nip: "19830122 200701 2 003", pangkat: "Penata", eselon: "IV.a", color: "bg-purple-100", textColor: "text-purple-600" },
    { id: '6', nama: "Drs. Subhan", jabatan: "Kasi Trantib", nip: "19680218 200701 1 026", pangkat: "Penata Tk.I", eselon: "IV.a", color: "bg-red-100", textColor: "text-red-600" },
    { id: '7', nama: "Kurniawan, S.Sos", jabatan: "Kasi Tata Pemerintahan", nip: "19831222 200701 1 006", pangkat: "Penata", eselon: "IV.a", color: "bg-indigo-100", textColor: "text-indigo-600" },
    { id: '8', nama: "Yosi Ariesandi, SE", jabatan: "Kasi Pemerintahan Umum", nip: "19820407 201101 1 005", pangkat: "Penata", eselon: "IV.a", color: "bg-cyan-100", textColor: "text-cyan-600" },
    { id: '9', nama: "Badarudin, SH.I", jabatan: "Kasi Pembinaan Pemdes", nip: "19800921 200801 1 016", pangkat: "Penata", eselon: "IV.a", color: "bg-teal-100", textColor: "text-teal-600" }
];


export const legalDocumentsData = [
    {
        id: 'terms',
        title: 'Syarat dan Ketentuan Penggunaan',
        lastUpdated: new Date().toISOString(),
        content: `
            <p>Selamat datang di Aplikasi SI-PELITA (Sistem Informasi Pelayanan Publik & Terintegrasi Administrasi). Dengan mengakses atau menggunakan aplikasi ini, Anda setuju untuk tunduk pada Syarat dan Ketentuan berikut:</p>
            <div class="legal-reference">
                <strong>Dasar Hukum:</strong>
                <ul class="mt-2 list-none p-0">
                    <li>1. Undang-Undang Nomor 11 Tahun 2008 tentang Informasi dan Transaksi Elektronik sebagaimana telah diubah dengan Undang-Undang Nomor 19 Tahun 2016 (UU ITE).</li>
                    <li>2. Undang-Undang Nomor 25 Tahun 2009 tentang Pelayanan Publik.</li>
                    <li>3. Peraturan Bupati Banyuasin Nomor 132 Tahun 2018 tentang Struktur Organisasi, Penjabaran Tugas dan Fungsi Kecamatan dalam Kabupaten Banyuasin.</li>
                </ul>
            </div>
            <h3>1. Definisi</h3>
            <p>
                <strong>"Aplikasi"</strong> merujuk pada platform SI-PELITA yang dikelola oleh Pemerintah Kecamatan Tungkal Ilir.<br/>
                <strong>"Pengguna"</strong> adalah warga, perangkat desa, atau instansi di lingkup Kecamatan Tungkal Ilir yang terdaftar dan menggunakan layanan aplikasi.<br/>
                <strong>"Layanan"</strong> mencakup pengurusan surat, pengaduan, akses informasi publik, dan integrasi data desa-kecamatan.
            </p>
            <h3>2. Pendaftaran Akun</h3>
            <ul>
                <li>Pengguna wajib memberikan data yang akurat, lengkap, dan terbaru saat mendaftar (NIK, Nama, Alamat) sesuai dengan data kependudukan yang sah.</li>
                <li>Pengguna bertanggung jawab penuh atas keamanan akun dan kata sandi masing-masing. Segala aktivitas yang terjadi melalui akun pengguna adalah tanggung jawab pengguna sepenuhnya.</li>
                <li>Pemerintah Kecamatan berhak melakukan verifikasi data dan menonaktifkan akun yang terindikasi melakukan penyalahgunaan, memberikan data palsu, atau melanggar ketentuan yang berlaku.</li>
            </ul>
            <h3>3. Penggunaan Layanan</h3>
            <p>Pengguna dilarang keras untuk:</p>
            <ul>
                <li>Mengunggah konten yang mengandung unsur SARA (Suku, Agama, Ras, dan Antargolongan), pornografi, ujaran kebencian, atau melanggar hukum yang berlaku di Indonesia.</li>
                <li>Menggunakan aplikasi untuk tujuan penipuan, penyesatan informasi, atau pemalsuan dokumen negara.</li>
                <li>Mencoba meretas, mengganggu, atau merusak sistem keamanan aplikasi, server, maupun jaringan yang terhubung dengan aplikasi SI-PELITA.</li>
                <li>Menggunakan data atau informasi yang diperoleh dari aplikasi untuk tujuan komersial tanpa izin tertulis dari Pemerintah Kecamatan Tungkal Ilir.</li>
            </ul>
            <h3>4. Validitas Dokumen</h3>
            <p>Dokumen yang diterbitkan melalui SI-PELITA dilengkapi dengan Tanda Tangan Elektronik (TTE) atau QR Code yang sah dan dapat diverifikasi keasliannya. Pengguna dilarang mengubah, memodifikasi, atau memalsukan dokumen digital yang telah diterbitkan. Segala bentuk pemalsuan dokumen akan diproses sesuai dengan ketentuan hukum yang berlaku.</p>
            <h3>5. Sanksi</h3>
            <p>Pelanggaran terhadap syarat dan ketentuan ini dapat mengakibatkan:</p>
            <ul>
                <li>Peringatan tertulis atau teguran.</li>
                <li>Penangguhan (suspend) atau penutupan akun secara permanen.</li>
                <li>Tuntutan hukum pidana maupun perdata sesuai peraturan perundang-undangan yang berlaku di Indonesia, termasuk namun tidak terbatas pada UU ITE dan KUHP.</li>
            </ul>
            <h3>6. Perubahan Ketentuan</h3>
            <p>Pemerintah Kecamatan Tungkal Ilir berhak mengubah Syarat dan Ketentuan ini sewaktu-waktu tanpa pemberitahuan sebelumnya. Perubahan akan diinformasikan melalui aplikasi atau website resmi. Penggunaan berkelanjutan atas aplikasi setelah perubahan tersebut dianggap sebagai persetujuan terhadap ketentuan yang baru.</p>
        `
    },
    {
        id: 'privacy',
        title: 'Kebijakan Privasi',
        lastUpdated: new Date().toISOString(),
        content: `
            <p>Pemerintah Kecamatan Tungkal Ilir menghormati privasi Anda dan berkomitmen untuk melindungi data pribadi yang Anda bagikan melalui aplikasi SI-PELITA. Kebijakan ini menjelaskan bagaimana kami mengelola data Anda.</p>
            <div class="legal-reference">
                <strong>Dasar Hukum:</strong>
                <ul class="mt-2 list-none p-0">
                    <li>1. Undang-Undang Nomor 27 Tahun 2022 tentang Perlindungan Data Pribadi (UU PDP).</li>
                    <li>2. Peraturan Menteri Dalam Negeri Nomor 47 Tahun 2016 tentang Administrasi Pemerintahan Desa.</li>
                    <li>3. Ketentuan peraturan perundang-undangan terkait Keterbukaan Informasi Publik yang mengecualikan informasi pribadi tertentu.</li>
                </ul>
            </div>
            <h3>1. Data yang Kami Kumpulkan</h3>
            <p>Kami mengumpulkan data pribadi yang diperlukan untuk pelayanan publik dan administrasi pemerintahan, antara lain:</p>
            <ul>
                <li><strong>Data Identitas:</strong> Nama lengkap, NIK, Nomor KK, Tempat/Tanggal Lahir, Jenis Kelamin, Pekerjaan, Agama.</li>
                <li><strong>Data Kontak:</strong> Alamat email, nomor telepon/WhatsApp, dan alamat domisili lengkap (Desa, RT/RW).</li>
                <li><strong>Dokumen Pendukung:</strong> Foto/Scan KTP, KK, Surat Pengantar Desa, dan dokumen lain yang diunggah untuk keperluan administrasi layanan.</li>
                <li><strong>Data Teknis:</strong> Alamat IP, jenis perangkat, browser, dan log aktivitas saat menggunakan aplikasi untuk keperluan keamanan dan perbaikan sistem.</li>
            </ul>
            <h3>2. Penggunaan Data</h3>
            <p>Data Anda digunakan semata-mata untuk:</p>
            <ul>
                <li>Memproses permohonan layanan administrasi (surat menyurat, perizinan, rekomendasi).</li>
                <li>Memverifikasi identitas pemohon sesuai database kependudukan.</li>
                <li>Menghubungi Anda terkait status permohonan, konfirmasi, atau tindak lanjut pengaduan.</li>
                <li>Meningkatkan kualitas layanan melalui analisis statistik (data dianonimkan) dan pelaporan kinerja kecamatan.</li>
                <li>Melaksanakan tugas dan fungsi pemerintahan sesuai ketentuan peraturan perundang-undangan.</li>
            </ul>
            <h3>3. Keamanan Data</h3>
            <p>Kami menerapkan langkah-langkah keamanan teknis dan organisasional yang memadai untuk melindungi data Anda dari akses, penggunaan, pengubahan, atau pengungkapan yang tidak sah. Data disimpan dalam server yang aman (Google Cloud Firestore / Firebase) dengan enkripsi standar industri dan akses terbatas hanya kepada petugas yang berwenang.</p>
            <h3>4. Berbagi Data (Pihak Ketiga)</h3>
            <p>Kami <strong>tidak akan</strong> menjual, menyewakan, atau membagikan data pribadi Anda kepada pihak ketiga komersial. Data hanya akan dibagikan kepada:</p>
            <ul>
                <li>Instansi Pemerintah terkait (seperti Dinas Kependudukan dan Pencatatan Sipil, Dinas Sosial, dll) jika diperlukan untuk verifikasi atau pemrosesan layanan lintas sektoral.</li>
                <li>Aparat penegak hukum atau lembaga peradilan jika diwajibkan oleh undang-undang atau perintah pengadilan yang sah.</li>
            </ul>
            <h3>5. Hak Pengguna</h3>
            <p>Sesuai dengan Undang-Undang Perlindungan Data Pribadi (UU PDP), Anda memiliki hak untuk:</p>
            <ul>
                <li>Mengakses dan meminta salinan data pribadi Anda yang kami simpan.</li>
                <li>Meminta perbaikan atau pembaruan data yang tidak akurat atau tidak lengkap.</li>
                <li>Mengajukan keberatan atau pengaduan jika terjadi dugaan penyalahgunaan data pribadi.</li>
                <li>Meminta penghapusan data (sesuai dengan ketentuan retensi arsip pemerintahan).</li>
            </ul>
            <h3>6. Kontak Kami</h3>
            <p>Jika Anda memiliki pertanyaan, saran, atau keluhan mengenai Kebijakan Privasi ini, silakan hubungi kami melalui:</p>
            <p class="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <strong>Sekretariat Kecamatan Tungkal Ilir</strong><br/>
                Email: tungkalilir@banyuasinkab.go.id<br/>
                Telepon: (0711) 123-4567<br/>
                Alamat: Jln. Jendral Sudirman - Lintas Bertak I, Desa Sidomulyo, Kode Pos 30781
            </p>
        `
    }
];


export { serviceHistoryData };
