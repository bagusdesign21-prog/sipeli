/**
 * @fileoverview A seeder script to populate the Firestore database with initial data.
 * This script is designed to be run from the command line.
 * 
 * It performs the following actions:
 * 1. Initializes the Firebase Admin SDK to interact with Firestore with admin privileges.
 * 2. Imports static data for `villages`, `pejabat` (officials), and `legalDocuments`.
 * 3. For each collection, it checks if documents already exist.
 * 4. If a collection is empty, it populates it with the corresponding static data using a batched write for efficiency.
 * 5. It also seeds users into Firebase Authentication and creates their corresponding profiles in Firestore.
 * 
 * To run this script, use the command: `npm run seed`
 * Make sure your `GOOGLE_APPLICATION_CREDENTIALS` environment variable is set.
 */

import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, Firestore } from 'firebase-admin/firestore';
import { getAuth, Auth, UserRecord } from 'firebase-admin/auth';
import { usersData, villagesData, pejabatData, legalDocumentsData, serviceHistoryData } from './data';
import { firebaseConfig } from '../src/firebase/config'; // Corrected import path

// Initialize Firebase Admin SDK
// It automatically uses the GOOGLE_APPLICATION_CREDENTIALS environment variable
try {
    initializeApp({
        projectId: firebaseConfig.projectId,
    });
    console.log('Firebase Admin SDK initialized successfully.');
} catch (error: any) {
    if (error.code === 'app/duplicate-app') {
        console.log('Firebase Admin SDK already initialized.');
    } else {
        console.error('Error initializing Firebase Admin SDK:', error);
        process.exit(1);
    }
}


const db = getFirestore();
const auth = getAuth();

/**
 * Seeds users into Firebase Authentication and creates their profiles in Firestore.
 * @param auth The Firebase Auth admin instance.
 * @param db The Firestore admin instance.
 */
async function seedUsers(auth: Auth, db: Firestore): Promise<Record<string, UserRecord>> {
  console.log(`⏳ Seeding 'users'...`);
  let createdCount = 0;
  let skippedCount = 0;
  const userRecords: Record<string, UserRecord> = {};

  for (const userData of usersData) {
    const { email, password, role, fullName, nik, desa } = userData;

    try {
      // Check if user already exists
      const userRecord = await auth.getUserByEmail(email);
      console.log(`- User with email ${email} already exists. Skipping.`);
      userRecords[email] = userRecord;
      skippedCount++;
    } catch (error: any) {
      if (error.code === 'auth/user-not-found') {
        // User does not exist, create them
        try {
          const userRecord = await auth.createUser({
            email,
            password,
            displayName: fullName,
          });
          
          // Now, create the user profile in Firestore
          const userDocRef = db.collection('users').doc(userRecord.uid);
          await userDocRef.set({
            id: userRecord.uid,
            ktpNumber: nik,
            kkNumber: "", // Default empty value
            fullName: fullName,
            address: desa,
            role: role,
          });
          
          userRecords[email] = userRecord;
          console.log(`+ Created user ${email} with UID ${userRecord.uid} and role '${role}'.`);
          createdCount++;

        } catch (creationError) {
          console.error(`❌ Error creating user ${email}:`, creationError);
        }
      } else {
        // Other errors related to fetching the user
        console.error(`❌ Error checking user ${email}:`, error);
      }
    }
  }
   console.log(`✅ User seeding complete. Created: ${createdCount}, Skipped: ${skippedCount}.`);
   return userRecords;
}


/**
 * A generic function to seed a collection in Firestore.
 * @param collectionName The name of the collection to seed.
 * @param data The array of data objects to add to the collection.
 * @param idField The field in the data object to use as the document ID.
 */
async function seedCollection<T extends { [key: string]: any }>(
  collectionName: string,
  data: T[],
  idField: keyof T
) {
  const collectionRef = db.collection(collectionName);
  const snapshot = await collectionRef.limit(1).get();

  if (!snapshot.empty) {
    console.log(`✅ Collection '${collectionName}' already contains data. Skipping seeding.`);
    return;
  }

  console.log(`⏳ Seeding '${collectionName}' collection...`);
  const batch = db.batch();

  data.forEach((item) => {
    const docId = String(item[idField]);
    const docRef = collectionRef.doc(docId);
    batch.set(docRef, item);
  });

  try {
    await batch.commit();
    console.log(`✅ Successfully seeded ${data.length} documents into '${collectionName}'.`);
  } catch (error) {
    console.error(`❌ Error seeding '${collectionName}':`, error);
  }
}

/**
 * Seeds the service history collection, linking it to the 'warga' user.
 * @param db The Firestore admin instance.
 * @param userRecords A map of user emails to their user records.
 */
async function seedServiceHistoryForSpecificUser(db: Firestore, userRecords: Record<string, UserRecord>) {
    const collectionName = 'serviceHistory';
    const specificUserEmail = 'bagusdewidn@gmail.com';
    const specificUserRecord = userRecords[specificUserEmail];

    if (!specificUserRecord) {
        console.log(`❌ Cannot seed '${collectionName}' because user '${specificUserEmail}' was not found or created.`);
        return;
    }
    
    // Check if this user already has service history to avoid duplication
    const historyQuery = db.collection(collectionName).where('userId', '==', specificUserRecord.uid).limit(1);
    const snapshot = await historyQuery.get();
    
    if (!snapshot.empty) {
        console.log(`✅ Service history for user '${specificUserEmail}' already exists. Skipping.`);
        return;
    }
    
    const collectionRef = db.collection(collectionName);
    console.log(`⏳ Seeding '${collectionName}' collection for user ${specificUserRecord.email}...`);
    const batch = db.batch();

    serviceHistoryData.forEach((item) => {
        const docRef = collectionRef.doc(); // Auto-generate ID for history entries
        batch.set(docRef, { ...item, id: docRef.id, userId: specificUserRecord.uid });
    });
    
    try {
        await batch.commit();
        console.log(`✅ Successfully seeded ${serviceHistoryData.length} documents into '${collectionName}' for user '${specificUserEmail}'.`);
    } catch (error) {
        console.error(`❌ Error seeding '${collectionName}' for user '${specificUserEmail}':`, error);
    }
}


/**
 * Main function to run all the seeding operations.
 */
async function main() {
  console.log('--- Starting Firestore Seeding ---');
  const userRecords = await seedUsers(auth, db);
  await seedCollection('villages', villagesData, 'id');
  await seedCollection('pejabat', pejabatData, 'id');
  await seedCollection('legalDocuments', legalDocumentsData, 'id');
  
  // Seed service history specifically for the specified user
  await seedServiceHistoryForSpecificUser(db, userRecords);

  console.log('--- Firestore Seeding Complete ---');
}

main().catch((error) => {
  console.error('An unexpected error occurred during the seeding process:', error);
  process.exit(1);
});
