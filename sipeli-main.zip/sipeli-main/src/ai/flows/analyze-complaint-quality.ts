
'use server';

/**
 * @fileOverview Analyzes the quality and content of a public complaint.
 *
 * - analyzeComplaintQuality - Analyzes the complaint and provides a structured quality assessment.
 * - AnalyzeComplaintQualityInput - The input type for the analyzeComplaintQuality function.
 * - AnalyzeComplaintQualityOutput - The return type for the analyzeComplaintQuality function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeComplaintQualityInputSchema = z.object({
  complaintText: z.string().describe('The full text of the public complaint to be analyzed.'),
});
export type AnalyzeComplaintQualityInput = z.infer<typeof AnalyzeComplaintQualityInputSchema>;

const AnalyzeComplaintQualityOutputSchema = z.object({
  qualityScore: z
    .number()
    .describe(
      'A score from 1 (very poor) to 5 (excellent) representing the clarity, completeness, and usefulness of the complaint.'
    ),
  isActionable: z
    .boolean()
    .describe('Whether the complaint contains enough specific information to be acted upon.'),
  urgency: z
    .enum(['Low', 'Medium', 'High'])
    .describe('The estimated urgency level of the complaint based on its content.'),
  summary: z.string().describe('A one-sentence summary of the main issue in the complaint.'),
  categorySuggestion: z
    .enum(['Administrasi Kependudukan', 'Infrastruktur Desa', 'Bantuan Sosial', 'Kinerja Perangkat', 'Lainnya'])
    .describe('A suggested category for the complaint.'),
});
export type AnalyzeComplaintQualityOutput = z.infer<typeof AnalyzeComplaintQualityOutputSchema>;

export async function analyzeComplaintQuality(
  input: AnalyzeComplaintQualityInput
): Promise<AnalyzeComplaintQualityOutput> {
  return analyzeComplaintQualityFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeComplaintQualityPrompt',
  input: {schema: AnalyzeComplaintQualityInputSchema},
  output: {schema: AnalyzeComplaintQualityOutputSchema},
  prompt: `You are an AI assistant for a local government office. Your task is to analyze public complaints and assess their quality.

Analyze the following complaint text:
---
{{{complaintText}}}
---

Based on the text, provide a structured analysis.
- **qualityScore**: Rate the complaint from 1 to 5. A high score means the report is clear, specific (mentions location, time, people involved), and provides evidence. A low score means it's vague, emotional, or lacks key details.
- **isActionable**: Determine if there's enough information for a government official to start an investigation or take action. This is true if the "who, what, where, when" are reasonably clear.
- **urgency**: Estimate the urgency. 'High' for safety risks, critical service failures. 'Medium' for service disruptions. 'Low' for minor issues or suggestions.
- **summary**: Provide a concise, one-sentence summary of the core problem.
- **categorySuggestion**: Suggest the most appropriate category for this complaint from the given options.

Provide the analysis in JSON format.`,
});

const analyzeComplaintQualityFlow = ai.defineFlow(
  {
    name: 'analyzeComplaintQualityFlow',
    inputSchema: AnalyzeComplaintQualityInputSchema,
    outputSchema: AnalyzeComplaintQualityOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
