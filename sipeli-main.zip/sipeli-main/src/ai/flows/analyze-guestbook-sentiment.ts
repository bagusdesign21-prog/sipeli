'use server';

/**
 * @fileOverview Analyzes guestbook sentiment, categorizes feedback, and suggests improvements.
 *
 * - analyzeGuestbookSentiment - Analyzes sentiment and provides actionable feedback.
 * - AnalyzeGuestbookSentimentInput - The input type for the analyzeGuestbookSentiment function.
 * - AnalyzeGuestbookSentimentOutput - The return type for the analyzeGuestbookSentiment function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeGuestbookSentimentInputSchema = z.object({
  text: z.string().describe('The guestbook entry or survey response to analyze.'),
});
export type AnalyzeGuestbookSentimentInput = z.infer<typeof AnalyzeGuestbookSentimentInputSchema>;

const AnalyzeGuestbookSentimentOutputSchema = z.object({
  sentiment: z.string().describe('The overall sentiment of the text (e.g., positive, negative, neutral).'),
  keyIssues: z.array(z.string()).describe('A list of key issues identified in the text.'),
  suggestedImprovements: z.array(z.string()).describe('A list of actionable improvements based on the text.'),
});
export type AnalyzeGuestbookSentimentOutput = z.infer<typeof AnalyzeGuestbookSentimentOutputSchema>;

export async function analyzeGuestbookSentiment(
  input: AnalyzeGuestbookSentimentInput
): Promise<AnalyzeGuestbookSentimentOutput> {
  return analyzeGuestbookSentimentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeGuestbookSentimentPrompt',
  input: {schema: AnalyzeGuestbookSentimentInputSchema},
  output: {schema: AnalyzeGuestbookSentimentOutputSchema},
  prompt: `You are an AI assistant tasked with analyzing sentiment in guestbook entries and survey responses to identify key issues and suggest actionable improvements.

Analyze the following text:

{{{text}}}

Provide the following information in your response:

- sentiment: The overall sentiment of the text (e.g., positive, negative, neutral).
- keyIssues: A list of key issues identified in the text.
- suggestedImprovements: A list of actionable improvements based on the text.

Format your response as a JSON object.`,
});

const analyzeGuestbookSentimentFlow = ai.defineFlow(
  {
    name: 'analyzeGuestbookSentimentFlow',
    inputSchema: AnalyzeGuestbookSentimentInputSchema,
    outputSchema: AnalyzeGuestbookSentimentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
