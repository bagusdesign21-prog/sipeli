'use server';

/**
 * @fileOverview A flow that uses generative AI to answer user questions about the application's services.
 *
 * - answerHelpQuestion - A function that answers user questions.
 * - AnswerHelpQuestionInput - The input type for the answerHelpQuestion function.
 * - AnswerHelpQuestionOutput - The return type for the answerHelpQuestion function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnswerHelpQuestionInputSchema = z.object({
  question: z.string().describe('The user\'s question about the service.'),
});
export type AnswerHelpQuestionInput = z.infer<typeof AnswerHelpQuestionInputSchema>;

const AnswerHelpQuestionOutputSchema = z.object({
  answer: z.string().describe('The AI-generated answer to the user\'s question.'),
});
export type AnswerHelpQuestionOutput = z.infer<typeof AnswerHelpQuestionOutputSchema>;

export async function answerHelpQuestion(
  input: AnswerHelpQuestionInput
): Promise<AnswerHelpQuestionOutput> {
  return answerHelpQuestionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'answerHelpQuestionPrompt',
  input: {schema: AnswerHelpQuestionInputSchema},
  output: {schema: AnswerHelpQuestionOutputSchema},
  prompt: `You are a helpful AI assistant for SI-PELITA, the integrated service platform for Kecamatan Tungkal Ilir. Your role is to answer user questions clearly and concisely in Bahasa Indonesia.

You have knowledge about the following services:
- **Administrasi Kependudukan**: Online services for KK (Kartu Keluarga), KTP (Kartu Tanda Penduduk), and Surat Pindah (moving letter).
- **Perizinan Usaha Desa**: Submission for IUMK (Izin Usaha Mikro dan Kecil) for small businesses in the village.
- **Layanan Sosial**: Checking DTKS (Data Terpadu Kesejahteraan Sosial), KIS (Kartu Indonesia Sehat), and applying for social assistance.
- **Pengaduan Masyarakat**: A channel for public aspirations and reports directly to the Camat (sub-district head).
- **Info & Profil Desa**: Statistical data and potential of the 14 villages in Tungkal Ilir.
- **Buku Tamu Digital**: Electronic guestbook for official or public visits.
- **Lacak Berkas**: A feature to track the status of submitted applications using a receipt number.

Based on the user's question, provide a helpful and straightforward answer. If the question is outside of your knowledge base, politely state that you can only answer questions related to the services of Kecamatan Tungkal Ilir.

User's Question:
{{{question}}}

Provide a helpful answer in Bahasa Indonesia.
`,
});

const answerHelpQuestionFlow = ai.defineFlow(
  {
    name: 'answerHelpQuestionFlow',
    inputSchema: AnswerHelpQuestionInputSchema,
    outputSchema: AnswerHelpQuestionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
