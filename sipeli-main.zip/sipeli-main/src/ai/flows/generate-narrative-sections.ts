'use server';

/**
 * @fileOverview A flow that uses generative AI to create narrative sections of reports based on data analysis.
 *
 * - generateNarrativeSections - A function that handles the generation of narrative sections.
 * - GenerateNarrativeSectionsInput - The input type for the generateNarrativeSections function.
 * - GenerateNarrativeSectionsOutput - The return type for the generateNarrativeSections function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateNarrativeSectionsInputSchema = z.object({
  reportType: z
    .string()
    .describe('The type of report to generate the narrative section for (e.g., LPJ, APBDes).'),
  dataAnalysis: z
    .string()
    .describe('The data analysis results that the narrative section should be based on.'),
  template: z
    .string()
    .optional()
    .describe('The template to use for generating the narrative section.'),
});
export type GenerateNarrativeSectionsInput = z.infer<typeof GenerateNarrativeSectionsInputSchema>;

const GenerateNarrativeSectionsOutputSchema = z.object({
  narrativeSection: z.string().describe('The generated narrative section.'),
});
export type GenerateNarrativeSectionsOutput = z.infer<typeof GenerateNarrativeSectionsOutputSchema>;

export async function generateNarrativeSections(
  input: GenerateNarrativeSectionsInput
): Promise<GenerateNarrativeSectionsOutput> {
  return generateNarrativeSectionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateNarrativeSectionsPrompt',
  input: {schema: GenerateNarrativeSectionsInputSchema},
  output: {schema: GenerateNarrativeSectionsOutputSchema},
  prompt: `You are an AI assistant specialized in generating narrative sections for reports.

  Based on the data analysis provided, generate a narrative section for the report.
  The report type is: {{{reportType}}}
  The data analysis is: {{{dataAnalysis}}}
  {{#if template}}
  Use the following template to generate the narrative section: {{{template}}}
  {{/if}}
  Otherwise, generate the section in your own style.
  Make it comprehensive and insightful, so it meets the requirement of the report.
  `,
});

const generateNarrativeSectionsFlow = ai.defineFlow(
  {
    name: 'generateNarrativeSectionsFlow',
    inputSchema: GenerateNarrativeSectionsInputSchema,
    outputSchema: GenerateNarrativeSectionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
