import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { UserCheck } from 'lucide-react';

export default function AdminDashboardPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline font-bold text-2xl flex items-center gap-2">
            <UserCheck />
            Admin Dashboard
        </CardTitle>
        <CardDescription>
          This is a protected area for administrators. You can manage users, settings, and view system-wide analytics here.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-center text-muted-foreground p-8">
            <p>Admin-specific content goes here.</p>
        </div>
      </CardContent>
    </Card>
  );
}
