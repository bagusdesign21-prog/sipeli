
'use client';

import { useState } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { answerHelpQuestionAction } from '@/lib/actions';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form';
import { Bot, Loader2, Send, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const formSchema = z.object({
  question: z.string().min(5, 'Pertanyaan terlalu singkat.'),
});

type FormValues = z.infer<typeof formSchema>;

type ChatMessage = {
  role: 'user' | 'assistant';
  content: string;
};

export function HelpAssistant() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      question: '',
    },
  });

  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    setIsLoading(true);
    const userMessage: ChatMessage = { role: 'user', content: data.question };
    setMessages((prev) => [...prev, userMessage]);
    form.reset();

    try {
      const result = await answerHelpQuestionAction(data);
      if (result.answer) {
        const assistantMessage: ChatMessage = { role: 'assistant', content: result.answer };
        setMessages((prev) => [...prev, assistantMessage]);
      } else {
        throw new Error('AI did not provide an answer.');
      }
    } catch (error) {
      console.error(error);
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: 'Maaf, terjadi kesalahan saat mencoba menjawab pertanyaan Anda. Silakan coba lagi.',
      };
      setMessages((prev) => [...prev, errorMessage]);
      toast({
        variant: 'destructive',
        title: 'Terjadi Kesalahan',
        description: 'Tidak dapat terhubung dengan asisten AI.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-white shadow-lg border-primary/20">
      <CardHeader>
        <CardTitle className="font-headline text-2xl font-bold flex items-center gap-3 text-slate-800">
          <Bot className="h-8 w-8 text-accent" />
          Tanya Asisten AI
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 mb-4 max-h-64 overflow-y-auto p-4 bg-muted/50 rounded-lg border">
          {messages.length === 0 ? (
            <div className="text-center text-muted-foreground p-4">
              <p>Ajukan pertanyaan tentang layanan SI-PELITA. <br />Contoh: "Bagaimana cara mengurus KTP?"</p>
            </div>
          ) : (
            messages.map((message, index) => (
              <div key={index} className={`flex items-start gap-3 ${message.role === 'user' ? 'justify-end' : ''}`}>
                {message.role === 'assistant' && <Bot className="h-6 w-6 text-accent flex-shrink-0" />}
                <div
                  className={`max-w-md rounded-lg p-3 text-sm ${
                    message.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background border'
                  }`}
                >
                  {message.content}
                </div>
                 {message.role === 'user' && <User className="h-6 w-6 text-muted-foreground flex-shrink-0" />}
              </div>
            ))
          )}
           {isLoading && (
              <div className="flex items-start gap-3">
                <Bot className="h-6 w-6 text-accent flex-shrink-0" />
                <div className="max-w-md rounded-lg p-3 bg-background flex items-center border">
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              </div>
            )}
        </div>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-start gap-2">
            <FormField
              control={form.control}
              name="question"
              render={({ field }) => (
                <FormItem className="flex-grow">
                  <FormControl>
                    <Input placeholder="Ketik pertanyaan Anda di sini..." {...field} disabled={isLoading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" disabled={isLoading} size="icon">
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              <span className="sr-only">Kirim</span>
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
