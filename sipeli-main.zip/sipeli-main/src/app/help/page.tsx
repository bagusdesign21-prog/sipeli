

'use client';

import { useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Mail, Phone } from 'lucide-react';
import { LandingHeader } from '@/components/landing/landing-header';
import { TrackingModal, GuestbookModal } from '@/components/landing/modals';
import { useUser, useFirestore } from '@/firebase';
import { useRouter } from 'next/navigation';
import { LandingFooter } from '@/components/landing/landing-footer';
import { HelpAssistant } from './components/help-assistant';
import { doc, getDoc } from 'firebase/firestore';


const faqs = [
  {
    question: 'Bagaimana cara mengajukan permohonan surat secara online?',
    answer:
      "Anda dapat mengajukan permohonan surat melalui menu 'Layanan Mandiri' di halaman utama. Pilih jenis layanan yang diinginkan, isi formulir yang tersedia, dan unggah dokumen yang diperlukan. Anda akan mendapatkan nomor resi untuk melacak status permohonan Anda.",
  },
  {
    question: 'Bagaimana cara melacak status permohonan saya?',
    answer:
      "Gunakan fitur 'Lacak Berkas' yang ada di bagian atas halaman. Masukkan nomor resi yang Anda dapatkan saat mengajukan permohonan untuk melihat status terbaru dari berkas Anda.",
  },
  {
    question: 'Apa saja dokumen yang perlu disiapkan untuk mengurus KTP atau KK?',
    answer:
      'Persyaratan dokumen dapat bervariasi. Umumnya, Anda memerlukan surat pengantar dari RT/RW dan desa, fotokopi Kartu Keluarga, dan dokumen pendukung lainnya. Detail spesifik akan ditampilkan saat Anda memilih jenis layanan.',
  },
  {
    question: 'Apakah layanan ini berbayar?',
    answer:
      'Seluruh layanan administrasi kependudukan yang disediakan melalui platform SI-PELITA adalah gratis dan tidak dipungut biaya (kecuali denda keterlambatan jika berlaku sesuai peraturan daerah).',
  },
];

export default function HelpPage() {
    const [activeModal, setActiveModal] = useState<string | null>(null);
    const { user } = useUser();
    const router = useRouter();
    const firestore = useFirestore();

    const handleLoginClick = async () => {
        if (user) {
            if (firestore) {
                const userDocRef = doc(firestore, 'users', user.uid);
                const userDoc = await getDoc(userDocRef);
                if (userDoc.exists()) {
                    const userData = userDoc.data();
                    switch (userData.role) {
                        case 'admin':
                            router.push('/admin/dashboard');
                            break;
                        case 'perangkat':
                            router.push('/pegawai/dashboard');
                            break;
                        default:
                            router.push('/warga/dashboard');
                            break;
                    }
                } else {
                    router.push('/warga/dashboard');
                }
            }
        } else {
          router.push('/login');
        }
      };

  const handleNavClick = (sectionId: string) => {
    if (['beranda', 'layanan', 'potensi', 'profil'].includes(sectionId)) {
      router.push(`/#${sectionId}`);
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };


  return (
    <div className="min-h-screen bg-muted/40 font-body flex flex-col">
       <LandingHeader
        onTrackClick={() => setActiveModal('tracking')}
        onLoginClick={handleLoginClick}
        onNavClick={handleNavClick}
      />

      <main className="container mx-auto max-w-4xl px-4 py-8 md:py-12 flex-grow mt-16">
        <div className="mb-12 text-center pt-8">
          <h1 className="font-headline text-4xl font-extrabold text-slate-900">
            Pusat Bantuan
          </h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Menemukan jawaban atas pertanyaan Anda tentang layanan kami.
          </p>
        </div>

        <HelpAssistant />

        <div className="grid gap-8 md:grid-cols-3 mt-12">
          <div className="md:col-span-2">
            <h2 className="mb-4 font-headline text-2xl font-bold">
              Pertanyaan Umum (FAQ)
            </h2>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left font-semibold">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Butuh Bantuan Lain?</CardTitle>
                <CardDescription>
                  Hubungi kami jika Anda tidak menemukan jawaban.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <Phone className="mt-1 h-5 w-5 flex-shrink-0 text-accent" />
                  <div>
                    <h4 className="font-semibold">Telepon</h4>
                    <p className="text-sm text-muted-foreground">
                      (0711) 123-4567
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Mail className="mt-1 h-5 w-5 flex-shrink-0 text-accent" />
                  <div>
                    <h4 className="font-semibold">Email</h4>
                    <p className="break-all text-sm text-muted-foreground">
                      tungkalilir@banyuasinkab.go.id
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <LandingFooter />

      {activeModal === 'tracking' && <TrackingModal onClose={() => setActiveModal(null)} />}
      {activeModal === 'guestbook' && <GuestbookModal onClose={() => setActiveModal(null)} />}
    </div>
  );
}
