import type {Metadata} from 'next';
import { Toaster } from "@/components/ui/toaster"
import './globals.css';
import { FirebaseClientProvider } from '@/firebase';
import { AuthProvider } from '@/firebase/provider';
import Script from 'next/script';

export const metadata: Metadata = {
  title: 'SI-PELITA | Kecamatan Tungkal Ilir',
  description: 'Platform layanan terpadu Kecamatan Tungkal Ilir. Digitalisasi arsip dan pelayanan untuk masyarakat yang lebih modern.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning data-scroll-behavior="smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=PT+Sans:ital,wght@0,400;0,700,1,400&display=swap" rel="stylesheet" />
        <Script src={`https://www.google.com/recaptcha/enterprise.js?render=${process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY}`} async defer />
      </head>
      <body className="font-body antialiased bg-[#FAF9F6] text-slate-800">
        <FirebaseClientProvider>
          <AuthProvider>
            {children}
          </AuthProvider>
        </FirebaseClientProvider>
        <Toaster />
      </body>
    </html>
  );
}
