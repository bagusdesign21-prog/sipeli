
export function LegalHeader() {
    return (
        <header className="pt-24 pb-12 bg-slate-900 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
            <div className="container mx-auto px-4 md:px-6 relative z-10 text-center">
                <h1 className="font-headline text-3xl md:text-4xl font-extrabold mb-4">Kebijakan & Privasi</h1>
                <p className="text-slate-300 max-w-2xl mx-auto">
                    Transparansi adalah kunci kepercayaan. Pelajari bagaimana kami melindungi data Anda dan aturan penggunaan layanan SI-PELITA.
                </p>
            </div>
        </header>
    );
}
