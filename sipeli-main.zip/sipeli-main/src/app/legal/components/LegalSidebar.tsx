
'use client';

import { FileText, Shield } from 'lucide-react';

interface LegalSidebarProps {
    activeTab: string;
    setActiveTab: (tab: 'terms' | 'privacy') => void;
}

export function LegalSidebar({ activeTab, setActiveTab }: LegalSidebarProps) {
    return (
        <aside className="lg:w-64 flex-shrink-0">
            <div className="bg-white p-2 rounded-xl shadow-sm border border-slate-200 sticky top-24">
                <button
                    onClick={() => setActiveTab('terms')}
                    className={`w-full text-left px-4 py-3 rounded-lg text-sm font-bold flex items-center gap-3 transition-all ${
                        activeTab === 'terms'
                        ? 'bg-accent text-white shadow-md'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                >
                    <FileText size={18}/> Syarat & Ketentuan
                </button>
                <button
                    onClick={() => setActiveTab('privacy')}
                    className={`w-full text-left px-4 py-3 rounded-lg text-sm font-bold flex items-center gap-3 transition-all mt-1 ${
                        activeTab === 'privacy'
                        ? 'bg-accent text-white shadow-md'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                >
                    <Shield size={18}/> Kebijakan Privasi
                </button>
            </div>
        </aside>
    );
}
