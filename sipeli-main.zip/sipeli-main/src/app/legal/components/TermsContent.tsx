import { format } from 'date-fns';
import { id } from 'date-fns/locale';

interface ContentProps {
    title: string;
    content: string;
    lastUpdated: string;
}

export function TermsContent({ title, content, lastUpdated }: ContentProps) {
    const updatedDate = lastUpdated ? new Date(lastUpdated) : new Date();

    return (
        <div className="prose prose-slate max-w-none animate-in fade-in slide-in-from-bottom-2">
            <div className="border-b border-slate-100 pb-6 mb-8">
                <h2 className="text-2xl font-headline font-bold text-slate-900 mb-2">{title}</h2>
                 <p className="text-sm text-muted-foreground">
                    Terakhir diperbarui: {format(updatedDate, "d MMMM yyyy", { locale: id })}
                </p>
            </div>
            <div dangerouslySetInnerHTML={{ __html: content }} />
        </div>
    );
}
