
'use client';

import { useState } from 'react';
import { LegalHeader } from './components/LegalHeader';
import { LegalNav } from './components/LegalNav';
import { LegalSidebar } from './components/LegalSidebar';
import { TermsContent } from './components/TermsContent';
import { PrivacyContent } from './components/PrivacyContent';
import { LandingFooter } from '@/components/landing/landing-footer';
import { useDoc, useFirestore, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { Loader2 } from 'lucide-react';
import type { LegalDocument } from '@/lib/types';


export default function LegalPage() {
    const [activeTab, setActiveTab] = useState<'terms' | 'privacy'>('terms');
    const firestore = useFirestore();

    const termsRef = useMemoFirebase(() => firestore ? doc(firestore, 'legalDocuments', 'terms') : null, [firestore]);
    const privacyRef = useMemoFirebase(() => firestore ? doc(firestore, 'legalDocuments', 'privacy') : null, [firestore]);
    
    const { data: termsData, isLoading: termsLoading } = useDoc<LegalDocument>(termsRef);
    const { data: privacyData, isLoading: privacyLoading } = useDoc<LegalDocument>(privacyRef);

    const isLoading = termsLoading || privacyLoading;

    return (
        <div className="min-h-screen flex flex-col bg-muted/40">
            <LegalNav />
            <LegalHeader />

            <main className="container mx-auto px-4 md:px-6 py-8 flex-1">
                <div className="flex flex-col lg:flex-row gap-8 max-w-6xl mx-auto">
                    <LegalSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
                    <div className="flex-1 bg-white p-6 md:p-10 rounded-2xl shadow-sm border border-slate-200 min-h-[600px]">
                        {isLoading ? (
                            <div className="flex justify-center items-center h-full">
                                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground"/>
                            </div>
                        ) : (
                            <>
                                {activeTab === 'terms' && termsData && (
                                    <TermsContent title={termsData.title} content={termsData.content} lastUpdated={termsData.lastUpdated} />
                                )}
                                {activeTab === 'privacy' && privacyData && (
                                    <PrivacyContent title={privacyData.title} content={privacyData.content} lastUpdated={privacyData.lastUpdated} />
                                )}
                            </>
                        )}
                    </div>
                </div>
            </main>

            <LandingFooter />
        </div>
    );
}
