
'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { useAuth, useFirestore, useUser } from '@/firebase';

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Loader2, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { doc, getDoc } from 'firebase/firestore';

declare global {
  interface Window {
    grecaptcha: any;
  }
}

const formSchema = z.object({
  email: z.string().email({ message: 'Format email tidak valid.' }),
  password: z.string().min(6, { message: 'Password minimal 6 karakter.' }),
});

type FormValues = z.infer<typeof formSchema>;

function getDashboardUrl(role: string): string {
    switch (role) {
        case 'admin':
            return '/admin/dashboard';
        case 'perangkat':
            return '/pegawai/dashboard';
        case 'warga':
            return '/warga/dashboard';
        default:
            return '/login'; 
    }
}


export function LoginForm() {
  const router = useRouter();
  const { toast } = useToast();
  const auth = useAuth();
  const firestore = useFirestore();
  const { user, isUserLoading } = useUser();
  const searchParams = useSearchParams();

  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  useEffect(() => {
    // This effect handles redirection after a user is confirmed to be logged in and the loading state is false.
    if (!isUserLoading && user && firestore) {
        const userDocRef = doc(firestore, 'users', user.uid);
        getDoc(userDocRef).then(userDoc => {
            const role = userDoc.exists() ? userDoc.data().role || 'warga' : 'warga';
            const redirectUrl = searchParams.get('redirect') || getDashboardUrl(role);
            router.replace(redirectUrl);
        }).catch(() => {
            // If fetching the doc fails, still attempt a fallback redirect.
            router.replace('/warga/dashboard');
        });
    }
  }, [user, isUserLoading, firestore, router, searchParams]);


  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    if (!auth || !firestore) {
        toast({
            variant: 'destructive',
            title: 'Kesalahan Aplikasi',
            description: 'Layanan autentikasi belum siap. Silakan coba lagi.',
        });
        return;
    }

    setIsLoading(true);

    try {
      if (!window.grecaptcha || !window.grecaptcha.enterprise) {
        throw new Error("reCAPTCHA script tidak dimuat atau tidak siap.");
      }

      window.grecaptcha.enterprise.ready(async () => {
        try {
          const token = await window.grecaptcha.enterprise.execute(process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY, {action: 'LOGIN'});
          
          const userCredential = await signInWithEmailAndPassword(auth, data.email, data.password);
          const loggedInUser = userCredential.user;

          const userDocRef = doc(firestore, 'users', loggedInUser.uid);
          const userDoc = await getDoc(userDocRef);
          
          const role = userDoc.exists() ? userDoc.data().role || 'warga' : 'warga';

          const idToken = await loggedInUser.getIdToken();
          
          document.cookie = `firebaseIdToken=${idToken}; path=/; max-age=3600; SameSite=Lax`;
          document.cookie = `userRole=${role}; path=/; max-age=3600; SameSite=Lax`;
          
          toast({
            title: 'Login Berhasil',
            description: 'Mengalihkan ke dashboard Anda...',
          });

          // The useEffect hook will handle the redirection, so we don't do it here.
          // We also don't set isLoading to false, to prevent the user from clicking again
          // while redirection is in progress.
          // This ensures the user object is fully propagated before redirect.

        } catch (error: any) {
          console.error("Login failed:", error);
          const errorMessage =
            error.code === 'auth/invalid-credential' || error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password'
              ? 'Email atau password salah. Silakan coba lagi.'
              : 'Terjadi kesalahan saat login. Silakan coba lagi nanti.';
          toast({
            variant: 'destructive',
            title: 'Login Gagal',
            description: errorMessage,
          });
          setIsLoading(false); // Reset loading state on failure
        }
      });
    } catch (e: any) {
       console.error("reCAPTCHA error:", e);
       toast({
          variant: 'destructive',
          title: 'Login Gagal',
          description: e.message || 'Gagal memuat atau menjalankan reCAPTCHA.',
        });
       setIsLoading(false); // Reset loading state on failure
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-center p-6 md:p-12 lg:p-20 overflow-y-auto">
      <div className="max-w-sm mx-auto w-full">
        <div className="mb-10 text-center md:text-left">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-accent mb-8 transition"
          >
            <ArrowLeft size={16} /> Kembali ke Beranda
          </Link>
          <h2 className="font-headline text-3xl font-bold text-slate-900 mb-2">Masuk Akun</h2>
          <p className="text-slate-500">Silakan masukkan kredensial Anda.</p>
        </div>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-5 animate-in fade-in slide-in-from-bottom-2"
          >
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="uppercase text-xs font-bold">Email</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        type="email"
                        placeholder="Masukkan email Anda"
                        {...field}
                        className="pl-10 pr-4 py-6"
                        disabled={isLoading}
                      />
                      <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <div className="flex justify-between items-center mb-2">
                    <FormLabel className="uppercase text-xs font-bold">Password</FormLabel>
                    <Link href="#" className="text-xs text-accent hover:underline font-medium">
                      Lupa Password?
                    </Link>
                  </div>
                  <FormControl>
                    <div className="relative">
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Masukkan kata sandi"
                        {...field}
                        className="pl-10 pr-10 py-6"
                        disabled={isLoading}
                      />
                      <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 focus:outline-none"
                        disabled={isLoading}
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 h-auto bg-accent hover:bg-emerald-600 text-white font-bold rounded-xl shadow-lg transition text-base transform hover:-translate-y-0.5"
            >
              {isLoading ? (
                <>
                  <Loader2 size={20} className="animate-spin" /> Mengautentikasi...
                </>
              ) : (
                'Masuk Sekarang'
              )}
            </Button>
          </form>
        </Form>

        <div className="mt-8 text-center">
          <p className="text-slate-500 text-sm">
            Belum punya akun?{' '}
            <Link href="/register" className="font-bold text-slate-800 hover:text-accent transition">
              Daftar di sini
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
