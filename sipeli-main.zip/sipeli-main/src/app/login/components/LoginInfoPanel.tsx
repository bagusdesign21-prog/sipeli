
import Link from 'next/link';
import { Activity, Clock } from 'lucide-react';

export function LoginInfoPanel() {
  return (
    <div className="hidden md:flex md:w-1/2 bg-slate-900 text-white flex-col justify-between p-12 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-accent/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

      <div className="relative z-10">
        <Link href="/" className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center text-white font-bold text-xl">
            SP
          </div>
          <span className="font-headline font-bold text-xl tracking-tight">SI-PELITA</span>
        </Link>
        <h1 className="font-headline text-4xl font-extrabold leading-tight mb-6">
          Selamat Datang
          <br />
          <span className="text-accent">Kembali.</span>
        </h1>
        <p className="text-slate-400 text-lg leading-relaxed max-w-md">
          Masuk untuk mengakses layanan administrasi, memantau status permohonan, dan berpartisipasi dalam
          pembangunan desa.
        </p>
      </div>

      <div className="relative z-10 grid grid-cols-2 gap-6 mt-12">
        <div className="bg-white/5 border border-white/10 p-4 rounded-xl backdrop-blur-sm">
          <div className="text-accent mb-2">
            <Clock size={24} />
          </div>
          <h4 className="font-bold">Efisien</h4>
          <p className="text-xs text-slate-400">Hemat waktu dengan layanan online.</p>
        </div>
        <div className="bg-white/5 border border-white/10 p-4 rounded-xl backdrop-blur-sm">
          <div className="text-orange-400 mb-2">
            <Activity size={24} />
          </div>
          <h4 className="font-bold">Real-time</h4>
          <p className="text-xs text-slate-400">Pantau proses secara langsung.</p>
        </div>
      </div>

      <p className="relative z-10 text-xs text-slate-500 mt-12">
        © {new Date().getFullYear()} Pemerintah Kecamatan Tungkal Ilir.
      </p>
    </div>
  );
}
