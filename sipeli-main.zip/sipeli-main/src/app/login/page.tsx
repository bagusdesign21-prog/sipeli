import { LoginForm } from './components/LoginForm';
import { LoginInfoPanel } from './components/LoginInfoPanel';

export default function LoginPage() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-white">
      <LoginInfoPanel />
      <LoginForm />
    </div>
  );
}
