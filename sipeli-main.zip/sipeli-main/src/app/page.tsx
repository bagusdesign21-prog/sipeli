
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { HeroSection } from '@/components/landing/hero-section';
import { AnnouncementsSection } from '@/components/landing/announcements-section';
import { ServicesSection } from '@/components/landing/services-section';
import { PotensiSection } from '@/components/landing/potensi-section';
import { StrukturSection } from '@/components/landing/struktur-section';
import { LandingFooter } from '@/components/landing/landing-footer';
import { LandingHeader } from '@/components/landing/landing-header';
import { TrackingModal, GuestbookModal } from '@/components/landing/modals';
import { useUser, useFirestore } from '@/firebase';
import { doc, getDoc } from 'firebase/firestore';

export default function LandingPage() {
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const { user } = useUser();
  const router = useRouter();
  const firestore = useFirestore();

  const handleLoginClick = async () => {
    if (user) {
        if (firestore) {
            const userDocRef = doc(firestore, 'users', user.uid);
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
                const userData = userDoc.data();
                switch (userData.role) {
                    case 'admin':
                        router.push('/admin/dashboard');
                        break;
                    case 'perangkat':
                        router.push('/pegawai/dashboard');
                        break;
                    default:
                        router.push('/warga/dashboard');
                        break;
                }
            } else {
                router.push('/warga/dashboard');
            }
        }
    } else {
      router.push('/login');
    }
  };

  const handleNavClick = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-body">
      <LandingHeader
        onTrackClick={() => setActiveModal('tracking')}
        onLoginClick={handleLoginClick}
        onNavClick={handleNavClick}
      />
      <main>
        <HeroSection />
        <AnnouncementsSection />
        <ServicesSection />
        <PotensiSection />
        <StrukturSection />
      </main>
      <LandingFooter />

      {activeModal === 'tracking' && <TrackingModal onClose={() => setActiveModal(null)} />}
      {activeModal === 'guestbook' && <GuestbookModal onClose={() => setActiveModal(null)} />}
    </div>
  );
}
