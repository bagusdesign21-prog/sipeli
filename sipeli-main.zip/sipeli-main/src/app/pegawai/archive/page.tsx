import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Archive as ArchiveIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PegawaiArchivePage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline font-bold text-2xl">Archive</CardTitle>
        <CardDescription>
          A repository for all generated reports and historical data.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center gap-4 text-center border-2 border-dashed rounded-lg p-12 min-h-[400px]">
          <div className="rounded-full bg-muted p-4">
            <ArchiveIcon className="h-12 w-12 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-bold tracking-tight">
            Archive is Empty
          </h3>
          <p className="text-sm text-muted-foreground max-w-sm">
            Generated documents and archived records will appear here once they are created and saved.
          </p>
          <Button variant="outline" className="mt-4">
            Learn More
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
