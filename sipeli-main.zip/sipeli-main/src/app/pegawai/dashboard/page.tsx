import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Link from 'next/link';

const announcements = [
  {
    title: 'Musyawarah Desa (Musdes) Schedule',
    description: 'The next Musdes will be held on July 30, 2024. All citizens are invited to attend.',
    date: 'July 15, 2024'
  },
  {
    title: 'APBDes Report Deadline',
    description: 'The deadline for the APBDes report submission is August 15, 2024. Please prepare your documents.',
    date: 'July 10, 2024'
  },
  {
    title: 'Community Work Day (Kerja Bakti)',
    description: 'Join us this Sunday for cleaning the village square. Starts at 8 AM.',
    date: 'July 8, 2024'
  },
];

const recentProjects = PlaceHolderImages.filter(p => p.id.startsWith('project-')).slice(0, 2);

export default function PegawaiDashboardPage() {
  return (
    <div className="grid auto-rows-max items-start gap-4 md:gap-8">
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4">
        <Card className="sm:col-span-2 bg-primary/20 border-primary/40">
          <CardHeader className="pb-3">
            <CardTitle className="font-headline font-bold text-2xl">Welcome to SI-PELITA</CardTitle>
            <CardDescription className="max-w-lg text-balance leading-relaxed">
              Your Integrated Service Information System for efficient village administration and community service.
            </CardDescription>
          </CardHeader>
          <CardContent>
             <Link href="/pegawai/documents">
              <Button>Create New Report</Button>
            </Link>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Guestbook Entries</CardDescription>
            <CardTitle className="text-4xl font-bold">12</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              +5 since last week
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Documents Generated</CardDescription>
            <CardTitle className="text-4xl font-bold">25</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              +10 this month
            </div>
          </CardContent>
        </Card>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-full lg:col-span-4">
          <CardHeader>
            <CardTitle className="font-headline font-bold">Announcements</CardTitle>
            <CardDescription>Important information and updates for the community.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {announcements.map((ann, index) => (
                <div key={index} className="grid gap-1.5 rounded-lg border bg-muted/50 p-4">
                  <p className="font-semibold">{ann.title}</p>
                  <p className="text-sm text-muted-foreground">{ann.description}</p>
                  <p className="text-xs text-muted-foreground/80 pt-1">{ann.date}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-full lg:col-span-3">
          <CardHeader>
            <CardTitle className="font-headline font-bold">Recent Projects</CardTitle>
            <CardDescription>Latest project documentation uploads.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-6">
            {recentProjects.map((project) => (
              <div key={project.id} className="flex items-center gap-4">
                <div className="relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-md">
                   <Image
                      src={project.imageUrl}
                      alt={project.description}
                      className="object-cover"
                      fill
                      data-ai-hint={project.imageHint}
                    />
                </div>
                <div className="grid gap-1">
                  <p className="text-sm font-medium leading-none">
                    Project Progress Photo
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {project.description}
                  </p>
                </div>
                <Link href="/pegawai/forms" className="ml-auto">
                    <Button variant="outline" size="sm">View</Button>
                </Link>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
