import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { DocumentBuilderClient } from '@/app/(app)/documents/components/document-builder-client';

export default function PegawaiDocumentBuilderPage() {
  return (
    <div className="mx-auto max-w-6xl">
      <Card>
        <CardHeader>
          <CardTitle className="font-headline font-bold text-2xl">AI Document Builder</CardTitle>
          <CardDescription>
            Automate report generation (LPJ, APBDes) using templates and generative AI for narrative sections.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DocumentBuilderClient />
        </CardContent>
      </Card>
    </div>
  );
}
