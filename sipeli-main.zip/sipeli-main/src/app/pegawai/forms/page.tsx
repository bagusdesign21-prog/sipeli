import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import {
  FormDescription,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function PegawaiFormsPage() {
    const projectImages = PlaceHolderImages.filter(p => p.id.startsWith('project-'));

  return (
    <div className="grid gap-4 md:gap-8 lg:grid-cols-5">
      <div className="lg:col-span-3">
        <Tabs defaultValue="update-data" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="update-data">Update Citizen Data</TabsTrigger>
            <TabsTrigger value="upload-photo">Upload Project Photo</TabsTrigger>
          </TabsList>
          <TabsContent value="update-data">
            <Card>
              <CardHeader>
                <CardTitle className="font-headline font-bold">Update Citizen Data</CardTitle>
                <CardDescription>
                  Keep your personal data (KK/KTP) up to date. Submitted data will be verified by an official.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" placeholder="Enter your full name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="kk-number">Kartu Keluarga (KK) Number</Label>
                  <Input id="kk-number" placeholder="Enter your KK number" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ktp-number">KTP Number</Label>
                  <Input id="ktp-number" placeholder="Enter your KTP number" />
                </div>
                <Button className="w-full sm:w-auto">Submit for Verification</Button>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="upload-photo">
            <Card>
              <CardHeader>
                <CardTitle className="font-headline font-bold">Upload Project Photo</CardTitle>
                <CardDescription>
                  Upload photos for project documentation. Geotags can be added for location tracking.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid w-full max-w-sm items-center gap-1.5">
                    <Label htmlFor="picture">Project Photo</Label>
                    <Input id="picture" type="file" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" placeholder="Add a short description of the photo." />
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="location">Location (Geotag)</Label>
                  <Input id="location" placeholder="e.g., -6.200000, 106.816666" />
                  <FormDescription>Location can be captured automatically on mobile devices.</FormDescription>
                </div>
                <Button className="w-full sm:w-auto">Upload Photo</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="font-headline font-bold">Project Gallery</CardTitle>
            <CardDescription>Recently uploaded project photos.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
             {projectImages.map((project) => (
              <div key={project.id} className="space-y-3">
                 <div className="overflow-hidden rounded-lg">
                    <Image
                      alt={project.description}
                      className="aspect-video w-full object-cover transition-transform hover:scale-105"
                      height="338"
                      src={project.imageUrl}
                      width="600"
                      data-ai-hint={project.imageHint}
                    />
                  </div>
                <p className="text-sm text-muted-foreground">{project.description}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
