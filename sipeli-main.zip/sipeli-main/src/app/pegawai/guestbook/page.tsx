import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { GuestbookClient } from '@/app/(app)/guestbook/components/guestbook-client';

export default function PegawaiGuestbookPage() {
  return (
    <div className="mx-auto w-full max-w-6xl">
       <div className="mb-8">
            <h1 className="font-headline font-bold text-2xl">Digital Guestbook & Sentiment Analysis</h1>
            <p className="text-muted-foreground">
                Leave your feedback and see it analyzed by AI to help us improve our services.
            </p>
        </div>
      <GuestbookClient />
    </div>
  );
}
