import { AppHeader } from '@/components/app-header';
import { AppSidebar } from '@/components/app-sidebar';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';

export default function PegawaiLayout({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
        <div className="flex min-h-screen w-full">
            <AppSidebar />
            <SidebarInset>
                <div className="flex flex-col h-full">
                    <AppHeader />
                    <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-background">
                        {children}
                    </main>
                </div>
            </SidebarInset>
        </div>
    </SidebarProvider>
  );
}
