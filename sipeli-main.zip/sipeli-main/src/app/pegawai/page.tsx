import { redirect } from "next/navigation";

export default function PegawaiRootPage() {
  redirect("/pegawai/dashboard");
}
