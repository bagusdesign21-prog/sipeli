
'use client'

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Button } from '@/components/ui/button';
import { useUser } from '@/firebase';
import { Loader2 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function PegawaiProfilePage() {
    const avatar = PlaceHolderImages.find((img) => img.id === 'user-avatar');
    const { user, isUserLoading } = useUser();
    
    if(isUserLoading) {
      return (
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-72 mt-2" />
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center gap-4 text-center border-2 border-dashed rounded-lg p-12 min-h-[400px]">
              <Skeleton className="w-24 h-24 rounded-full" />
              <Skeleton className="h-8 w-40 mt-4" />
              <Skeleton className="h-4 w-32" />
            </div>
          </CardContent>
        </Card>
      )
    }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline font-bold text-2xl">User Profile</CardTitle>
        <CardDescription>
          Manage your account settings and preferences.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center gap-4 text-center border-2 border-dashed rounded-lg p-12 min-h-[400px]">
          {avatar && <Image src={avatar.imageUrl} width={100} height={100} alt="Avatar" className="rounded-full ring-4 ring-primary ring-offset-4 ring-offset-background" data-ai-hint={avatar.imageHint} />}
          <h3 className="text-2xl font-bold tracking-tight mt-4">
            {user?.email || "Kasi Kesejahteraan"}
          </h3>
          <p className="text-sm text-muted-foreground">
            Desa Makmur Jaya
          </p>
          <Button variant="outline" className="mt-4">Edit Profile</Button>
        </div>
      </CardContent>
    </Card>
  );
}
