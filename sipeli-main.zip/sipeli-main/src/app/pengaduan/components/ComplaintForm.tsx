
'use client';

import { useState, useRef } from 'react';
import {
    PenTool,
    UploadCloud,
    Send,
    Loader2,
    Info,
    Phone,
    MessageCircle,
    Wand2,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useUser, addDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { useStorage } from '@/firebase/provider';
import { collection } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { analyzeComplaintAction } from '@/lib/actions';
import type { AnalyzeComplaintQualityOutput } from '@/ai/flows/analyze-complaint-quality';
import { Badge } from '@/components/ui/badge';

declare global {
  interface Window {
    grecaptcha: any;
  }
}

export function ComplaintForm() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { toast } = useToast();
    const firestore = useFirestore();
    const storage = useStorage();
    const { user } = useUser();

    const complaintsCollection = useMemoFirebase(() => 
        firestore ? collection(firestore, 'complaints') : null
    , [firestore]);

    const [complaint, setComplaint] = useState({
        nama: '', nik: '', kontak: '', kategori: 'Administrasi', pesan: '', file: null as File | null
    });
    const [analysisResult, setAnalysisResult] = useState<AnalyzeComplaintQualityOutput | null>(null);

    const handleComplaintChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        if (name === 'nik') {
            const numericValue = value.replace(/[^0-9]/g, '');
            if (numericValue.length <= 16) {
                setComplaint(prev => ({ ...prev, [name]: numericValue }));
            }
        } else {
            setComplaint(prev => ({ ...prev, [name]: value }));
        }
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setComplaint(prev => ({ ...prev, file: e.target.files![0] }));
        }
    }

    const handleComplaintSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!complaintsCollection || !storage) {
            toast({
                variant: 'destructive',
                title: 'Koneksi Gagal',
                description: 'Tidak dapat terhubung ke database atau storage. Coba lagi nanti.'
            });
            return;
        }

        if (complaint.nik && complaint.nik.length !== 16) {
             toast({
                variant: "destructive",
                title: "NIK tidak valid",
                description: "NIK harus terdiri dari 16 digit angka.",
            });
            return;
        }
        setIsSubmitting(true);
        setAnalysisResult(null);

        window.grecaptcha.enterprise.ready(async () => {
            try {
                const token = await window.grecaptcha.enterprise.execute(process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY, {action: 'SUBMIT_COMPLAINT'});
                // In a real app, you'd send this token to your backend for verification.
                
                // 1. Analyze the complaint with AI
                const analysis = await analyzeComplaintAction({ complaintText: complaint.pesan });
                setAnalysisResult(analysis); // Show analysis to user

                let fileUrl = '';
                // 2. If a file exists, upload it to Firebase Storage
                if (complaint.file) {
                    const filePath = `complaints/${user ? user.uid : 'anonymous'}/${Date.now()}-${complaint.file.name}`;
                    const storageRef = ref(storage, filePath);
                    const uploadResult = await uploadBytes(storageRef, complaint.file);
                    fileUrl = await getDownloadURL(uploadResult.ref);
                }

                // 3. Save the complaint and the analysis to Firestore
                const ticketNumber = `TKL-${Date.now()}`;
                addDocumentNonBlocking(complaintsCollection, {
                    nama: complaint.nama,
                    nik: complaint.nik,
                    kontak: complaint.kontak,
                    kategori: complaint.kategori,
                    pesan: complaint.pesan,
                    fileUrl: fileUrl,
                    createdAt: new Date().toISOString(),
                    ticketNumber,
                    analysis, // Save the AI analysis
                });

                toast({
                    title: "Pengaduan Terkirim",
                    description: `Nomor Tiket Anda: ${ticketNumber}. Terima kasih atas laporan Anda.`,
                });
                setComplaint({ nama: '', nik: '', kontak: '', kategori: 'Administrasi', pesan: '', file: null });
            } catch (error) {
                console.error(error);
                toast({
                    variant: 'destructive',
                    title: 'Gagal Mengirim',
                    description: 'Terjadi kesalahan saat menganalisis atau mengirim pengaduan.'
                });
            } finally {
                setIsSubmitting(false);
            }
        });
    };

    return (
        <div className="grid md:grid-cols-3 gap-8 animate-in fade-in slide-in-from-bottom-4">
            <div className="md:col-span-2">
                <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200">
                    <h2 className="font-headline text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                        <PenTool className="text-accent" /> Tulis Pengaduan
                    </h2>
                    <form onSubmit={handleComplaintSubmit} className="space-y-5">
                        <div className="grid md:grid-cols-2 gap-5">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Nama Lengkap</label>
                                <input required name="nama" value={complaint.nama} onChange={handleComplaintChange} type="text" className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-accent focus:ring-2 focus:ring-accent/20 outline-none transition" placeholder="Sesuai KTP" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">NIK (Opsional)</label>
                                <input name="nik" value={complaint.nik} onChange={handleComplaintChange} type="text" pattern="[0-9]{16}" title="NIK harus 16 digit angka" className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-accent focus:ring-2 focus:ring-accent/20 outline-none transition" placeholder="1607..." />
                            </div>
                        </div>
                        <div className="grid md:grid-cols-2 gap-5">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">No. HP / WhatsApp</label>
                                <input required name="kontak" value={complaint.kontak} onChange={handleComplaintChange} type="tel" className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-accent focus:ring-2 focus:ring-accent/20 outline-none transition" placeholder="08..." />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Kategori</label>
                                <select name="kategori" value={complaint.kategori} onChange={handleComplaintChange} className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-accent focus:ring-2 focus:ring-accent/20 outline-none transition bg-white">
                                    <option>Administrasi Kependudukan</option>
                                    <option>Infrastruktur Desa</option>
                                    <option>Bantuan Sosial</option>
                                    <option>Kinerja Perangkat</option>
                                    <option>Lainnya</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Isi Pengaduan</label>
                            <textarea required name="pesan" value={complaint.pesan} onChange={handleComplaintChange} rows={5} className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-accent focus:ring-2 focus:ring-accent/20 outline-none transition" placeholder="Jelaskan secara detail, lokasi, dan waktu kejadian..."></textarea>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Lampiran Bukti (Opsional)</label>
                                <div className="relative border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:bg-slate-50 transition cursor-pointer">
                                <input type="file" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" onChange={handleFileChange} />
                                <UploadCloud size={32} className="mx-auto text-slate-400 mb-2" />
                                {complaint.file ? (
                                    <p className="text-sm font-bold text-accent">{complaint.file.name}</p>
                                ) : (
                                    <>
                                        <p className="text-sm text-slate-500">Klik untuk upload atau drag &amp; drop</p>
                                        <p className="text-xs text-slate-400 mt-1">Maks. 5MB (JPG, PNG, PDF)</p>
                                    </>
                                )}
                            </div>
                        </div>
                         {analysisResult && (
                            <div className="p-4 bg-muted rounded-lg border">
                                <h4 className="font-bold text-sm mb-3 flex items-center gap-2"><Wand2 className="text-accent"/> Hasil Analisis AI</h4>
                                <div className="space-y-2 text-sm">
                                    <p><span className="font-semibold">Ringkasan:</span> {analysisResult.summary}</p>
                                    <div className="flex items-center gap-4">
                                        <p><span className="font-semibold">Saran Kategori:</span> <Badge variant="secondary">{analysisResult.categorySuggestion}</Badge></p>
                                        <p><span className="font-semibold">Tingkat Urgensi:</span> <Badge variant={analysisResult.urgency === 'High' ? 'destructive' : 'default'}>{analysisResult.urgency}</Badge></p>
                                    </div>
                                </div>
                            </div>
                        )}

                        <button disabled={isSubmitting} className="w-full py-3 bg-slate-900 text-white font-bold rounded-lg hover:bg-slate-800 transition shadow-lg flex justify-center items-center gap-2 disabled:opacity-50">
                            {isSubmitting ? <><Loader2 size={18} className="animate-spin" /> Menganalisis & Mengirim...</> : <><Send size={18} /> Kirim Pengaduan</>}
                        </button>
                    </form>
                </div>
            </div>
            <div className="space-y-6">
                <div className="bg-primary/10 p-6 rounded-2xl border border-accent/30">
                    <h3 className="font-bold text-accent-foreground mb-3 flex items-center gap-2">
                        <Info size={18} /> Alur Pengaduan
                    </h3>
                    <ul className="space-y-4 relative before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-accent/30">
                        <li className="relative pl-6">
                            <div className="absolute left-0 top-1 w-4 h-4 bg-accent rounded-full border-4 border-primary/10"></div>
                            <p className="text-sm font-bold text-slate-700">Verifikasi</p>
                            <p className="text-xs text-slate-500">Admin mengecek kelengkapan laporan.</p>
                        </li>
                        <li className="relative pl-6">
                            <div className="absolute left-0 top-1 w-4 h-4 bg-accent rounded-full border-4 border-primary/10"></div>
                            <p className="text-sm font-bold text-slate-700">Tindak Lanjut</p>
                            <p className="text-xs text-slate-500">Diteruskan ke bidang terkait.</p>
                        </li>
                        <li className="relative pl-6">
                            <div className="absolute left-0 top-1 w-4 h-4 bg-accent rounded-full border-4 border-primary/10"></div>
                            <p className="text-sm font-bold text-slate-700">Selesai</p>
                            <p className="text-xs text-slate-500">Laporan ditangani &amp; diinformasikan.</p>
                        </li>
                    </ul>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-800 mb-2">Kontak Darurat</h3>
                    <p className="text-sm text-slate-500 mb-4">Untuk keadaan mendesak, hubungi:</p>
                    <a href="tel:112" className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition mb-2">
                        <div className="w-8 h-8 bg-red-100 text-red-600 rounded-full flex items-center justify-center font-bold"><Phone size={14} /></div>
                        <span className="font-bold text-slate-700">112 (Bebas Pulsa)</span>
                    </a>
                    <a href="#" className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition">
                        <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold"><MessageCircle size={14} /></div>
                        <span className="font-bold text-slate-700">WhatsApp Center</span>
                    </a>
                </div>
            </div>
        </div>
    );
}
