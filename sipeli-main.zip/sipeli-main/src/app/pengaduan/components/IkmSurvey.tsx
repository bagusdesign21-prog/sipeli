
'use client';

import { useState } from 'react';
import {
    User,
    CheckCircle,
    Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, addDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { collection } from 'firebase/firestore';

const IKM_INDICATORS = [
    { id: 1, text: "Kemudahan Prosedur Pelayanan" },
    { id: 2, text: "Kejelasan Persyaratan Pelayanan" },
    { id: 3, text: "Kepastian dan Kejelasan Petugas Pelayanan" },
    { id: 4, text: "Kedisiplinan Petugas Pelayanan" },
    { id: 5, text: "Tanggung Jawab Petugas Pelayanan" },
    { id: 6, text: "Kemampuan Petugas Pelayanan" },
    { id: 7, text: "Kesopanan dan Keramahan Petugas" },
    { id: 8, text: "Keadilan Mendapatkan Pelayanan" },
    { id: 9, text: "Ketepatan Pelaksanaan Terhadap Jadwal Waktu Pelayanan" },
    { id: 10, text: "Kecepatan Pelayanan" },
    { id: 11, text: "Lama Waktu Kepengurusan" },
    { id: 12, text: "Kewajaran Biaya Pelayanan" },
    { id: 13, text: "Kenyamanan Lingkungan Unit Pelayanan" },
    { id: 14, text: "Keamanan Pelayanan" }
];

const IKM_OPTIONS = [
    { val: 1, label: "Tidak Baik", color: "bg-red-100 text-red-700 border-red-200" },
    { val: 2, label: "Kurang Baik", color: "bg-orange-100 text-orange-700 border-orange-200" },
    { val: 3, label: "Baik", color: "bg-blue-100 text-blue-700 border-blue-200" },
    { val: 4, label: "Sangat Baik", color: "bg-green-100 text-green-700 border-green-200" }
];

export function IkmSurvey() {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { toast } = useToast();
    const firestore = useFirestore();

    const ikmCollection = useMemoFirebase(() => 
        firestore ? collection(firestore, 'ikm-surveys') : null
    , [firestore]);
    
    const [ikmScores, setIkmScores] = useState<Record<number, number>>({});
    const [respondent, setRespondent] = useState({
        name: '', address: '', age: '', gender: 'L', education: 'SMA', job: 'Wiraswasta'
    });

    const handleIkmSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!ikmCollection) {
             toast({
                variant: 'destructive',
                title: 'Koneksi Gagal',
                description: 'Tidak dapat terhubung ke database. Coba lagi nanti.'
            });
            return;
        }

        if (!respondent.name || !respondent.address) {
            toast({ variant: 'destructive', title: "Data Responden Belum Lengkap", description: "Mohon lengkapi Nama dan Alamat Anda." });
            return;
        }
        if (Object.keys(ikmScores).length < IKM_INDICATORS.length) {
            toast({ variant: 'destructive', title: "Survei Belum Lengkap", description: `Mohon berikan penilaian untuk ke-${IKM_INDICATORS.length} indikator pelayanan.` });
            return;
        }
        setIsSubmitting(true);
        
        try {
            addDocumentNonBlocking(ikmCollection, {
                respondent: {
                    ...respondent,
                    age: parseInt(respondent.age, 10) || 0,
                },
                scores: ikmScores,
                createdAt: new Date().toISOString(),
            });

            toast({
                title: `Terima Kasih, ${respondent.name}!`,
                description: "Partisipasi Anda dalam Survei Kepuasan Masyarakat sangat berarti.",
            });
            setIkmScores({});
            setRespondent({ name: '', address: '', age: '', gender: 'L', education: 'SMA', job: 'Wiraswasta' });
            window.scrollTo(0, 0);

        } catch (error) {
             console.error(error);
            toast({
                variant: 'destructive',
                title: 'Gagal Mengirim',
                description: 'Terjadi kesalahan saat mengirim survei.'
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleRespondentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setRespondent(prev => ({...prev, [name]: value}));
    };

    const handleIkmScoreChange = (questionId: number, value: number) => {
        setIkmScores(prev => ({ ...prev, [questionId]: value }));
    };

    return (
        <div className="animate-in fade-in slide-in-from-bottom-4">
            <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
                <div className="bg-slate-900 p-6 md:p-8 text-white">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                            <h2 className="text-xl md:text-2xl font-bold mb-1">Survei Kepuasan Masyarakat</h2>
                            <p className="text-slate-400 text-sm">Berdasarkan 14 Indikator Layanan (PermenPAN &amp; RB)</p>
                        </div>
                        <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-lg border border-white/20">
                            <p className="text-xs text-slate-300 uppercase tracking-wider mb-1">Target IKM 2025</p>
                            <p className="text-2xl font-bold text-accent">82.50 <span className="text-sm font-normal text-white">(Sangat Baik)</span></p>
                        </div>
                    </div>
                </div>

                <form onSubmit={handleIkmSubmit} className="p-6 md:p-8">
                    <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 mb-8">
                        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                            <User size={18} className="text-accent" /> Data Responden
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 mb-1">Nama</label>
                                <input type="text" name="name" value={respondent.name} onChange={handleRespondentChange} className="w-full px-3 py-2 border rounded-lg text-sm" placeholder="Nama Lengkap" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 mb-1">Desa / Alamat</label>
                                <input type="text" name="address" value={respondent.address} onChange={handleRespondentChange} className="w-full px-3 py-2 border rounded-lg text-sm" placeholder="Nama Desa / Alamat" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 mb-1">Umur</label>
                                <input type="number" name="age" value={respondent.age} onChange={handleRespondentChange} className="w-full px-3 py-2 border rounded-lg text-sm" placeholder="Tahun" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 mb-1">Jenis Kelamin</label>
                                <select name="gender" value={respondent.gender} onChange={handleRespondentChange} className="w-full px-3 py-2 border rounded-lg text-sm bg-white">
                                    <option value="L">Laki-laki</option>
                                    <option value="P">Perempuan</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 mb-1">Pendidikan</label>
                                <select name="education" value={respondent.education} onChange={handleRespondentChange} className="w-full px-3 py-2 border rounded-lg text-sm bg-white">
                                    <option>SD</option> <option>SMP</option> <option>SMA</option> <option>S1/D4</option> <option>S2/S3</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 mb-1">Pekerjaan</label>
                                <select name="job" value={respondent.job} onChange={handleRespondentChange} className="w-full px-3 py-2 border rounded-lg text-sm bg-white">
                                    <option>PNS/TNI/POLRI</option> <option>Swasta</option> <option>Wiraswasta</option> <option>Pelajar</option> <option>Lainnya</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-8">
                        {IKM_INDICATORS.map((q) => (
                            <div key={q.id} className="border-b border-slate-100 pb-6 last:border-0">
                                <p className="font-bold text-slate-800 mb-4 text-sm md:text-base">
                                    <span className="text-accent mr-2">{q.id}.</span> {q.text}
                                </p>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    {IKM_OPTIONS.map((opt) => (
                                        <label key={opt.val} className={cn('cursor-pointer p-3 rounded-lg border text-center transition-all relative overflow-hidden', ikmScores[q.id] === opt.val ? `${opt.color} ring-2 ring-offset-1 ring-accent` : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50')}>
                                            <input type="radio" name={`q-${q.id}`} value={opt.val} className="absolute opacity-0 w-0 h-0" onChange={() => handleIkmScoreChange(q.id, opt.val)} />
                                            <div className="text-lg font-bold mb-1">{opt.val}</div>
                                            <div className="text-xs font-medium">{opt.label}</div>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="mt-8 pt-6 border-t border-slate-200">
                        <button disabled={isSubmitting} className="w-full py-4 bg-accent hover:bg-emerald-600 text-white font-bold rounded-xl shadow-lg transition flex justify-center items-center gap-2 text-lg disabled:opacity-50">
                            {isSubmitting ? <><Loader2 size={24} className="animate-spin" /> Memproses...</> : <><CheckCircle size={24} /> Kirim Survei</>}
                        </button>
                    </div>
                </form>

                <div className="bg-slate-50 p-6 border-t border-slate-200 text-xs text-slate-500">
                    <h4 className="font-bold text-slate-700 mb-3 uppercase tracking-wider">Keterangan Nilai Indeks (Konversi):</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-center">
                        <div className="p-2 bg-white border rounded"><span className="block font-bold text-red-600 text-lg">D</span> (1.00 - 1.75) Tidak Baik</div>
                        <div className="p-2 bg-white border rounded"><span className="block font-bold text-orange-500 text-lg">C</span> (1.76 - 2.50) Kurang Baik</div>
                        <div className="p-2 bg-white border rounded"><span className="block font-bold text-blue-600 text-lg">B</span> (2.51 - 3.25) Baik</div>
                        <div className="p-2 bg-white border rounded"><span className="block font-bold text-green-600 text-lg">A</span> (3.26 - 4.00) Sangat Baik</div>
                    </div>
                </div>
            </div>
        </div>
    );
}
