
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
    ArrowLeft,
    Home,
    MessageSquareWarning,
    ClipboardCheck,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { ComplaintForm } from './ComplaintForm';
import { IkmSurvey } from './IkmSurvey';

export function PengaduanLayout() {
    const [activeTab, setActiveTab] = useState('pengaduan'); // 'pengaduan' | 'ikm'
    const [isScrolled, setIsScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => setIsScrolled(window.scrollY > 20);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div className="min-h-screen flex flex-col bg-background">
            {/* NAVBAR */}
            <nav className={cn('fixed top-0 left-0 right-0 z-50 transition-all duration-300', isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-3' : 'bg-white py-4 border-b border-slate-100')}>
                <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <Link href="/" className="p-2 hover:bg-slate-100 rounded-full transition text-slate-500">
                            <ArrowLeft size={20} />
                        </Link>
                        <div className="h-6 w-px bg-slate-200"></div>
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center text-white font-bold text-sm">SP</div>
                            <span className="font-headline font-bold text-slate-800">Layanan Aspirasi</span>
                        </div>
                    </div>
                    <Link href="/" className="text-sm font-medium text-accent hover:text-emerald-600 flex items-center gap-1">
                        <Home size={16} /> <span className="hidden sm:inline">Beranda</span>
                    </Link>
                </div>
            </nav>

            {/* HERO HEADER */}
            <header className="pt-24 pb-12 bg-slate-900 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-96 h-96 bg-accent/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
                <div className="container mx-auto px-4 md:px-6 relative z-10 text-center">
                    <h1 className="font-headline text-3xl md:text-4xl font-extrabold mb-4">Suara Anda, Semangat Kami</h1>
                    <p className="text-slate-300 max-w-2xl mx-auto">
                        Sampaikan pengaduan layanan atau berikan penilaian kinerja kami melalui Survei Kepuasan Masyarakat (SKM) untuk mewujudkan pelayanan publik yang lebih baik.
                    </p>
                </div>
            </header>

            {/* MAIN CONTENT */}
            <main className="container mx-auto px-4 md:px-6 py-8 flex-1">
                {/* Tab Navigation */}
                <div className="flex justify-center mb-8">
                    <div className="inline-flex bg-white p-1.5 rounded-xl shadow-sm border border-slate-200">
                        <button
                            onClick={() => setActiveTab('pengaduan')}
                            className={cn('px-6 py-2.5 rounded-lg text-sm font-bold transition-all flex items-center gap-2', activeTab === 'pengaduan' ? 'bg-accent text-white shadow-md' : 'text-slate-500 hover:bg-slate-50')}
                        >
                            <MessageSquareWarning size={18} /> Pengaduan Layanan
                        </button>
                        <button
                            onClick={() => setActiveTab('ikm')}
                            className={cn('px-6 py-2.5 rounded-lg text-sm font-bold transition-all flex items-center gap-2', activeTab === 'ikm' ? 'bg-accent text-white shadow-md' : 'text-slate-500 hover:bg-slate-50')}
                        >
                            <ClipboardCheck size={18} /> Survei Kepuasan (SKM)
                        </button>
                    </div>
                </div>

                {/* CONTENT AREA */}
                <div className="max-w-4xl mx-auto">
                    {activeTab === 'pengaduan' && <ComplaintForm />}
                    {activeTab === 'ikm' && <IkmSurvey />}
                </div>
            </main>
            <footer className="bg-white border-t border-slate-200 py-8 mt-12">
                <div className="container mx-auto px-4 text-center">
                    <p className="text-xs text-slate-500">
                        &copy; {new Date().getFullYear()} Pemerintah Kecamatan Tungkal Ilir. Hak Cipta Dilindungi.
                    </p>
                </div>
            </footer>
        </div>
    );
};
