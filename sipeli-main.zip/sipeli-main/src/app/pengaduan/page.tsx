
'use client';

import { PengaduanLayout } from './components/PengaduanLayout';

export default function PengaduanPage() {
    return <PengaduanLayout />;
}
