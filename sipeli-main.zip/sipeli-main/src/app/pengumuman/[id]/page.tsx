
'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { NEWS_DATA } from '@/lib/data-pengumuman';
import { ArrowLeft, Home, Calendar, User, FileText, ArrowRight, Facebook, MessageCircle, Link as LinkIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { LandingFooter } from '@/components/landing/landing-footer';

export default function DetailPengumumanPage() {
    const [isScrolled, setIsScrolled] = useState(false);
    const params = useParams();
    const router = useRouter();

    const articleId = Array.isArray(params.id) ? params.id[0] : params.id;
    const article = NEWS_DATA.find(item => item.id.toString() === articleId);

    useEffect(() => {
        const handleScroll = () => setIsScrolled(window.scrollY > 20);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    if (!article) {
        return (
            <div className="flex h-screen items-center justify-center">
                <p>Artikel tidak ditemukan.</p>
                 <button onClick={() => router.back()}>Kembali</button>
            </div>
        )
    }
    
    // Hard-coded full content and related articles based on the provided HTML.
    // In a real app, this would come from a CMS or database.
     const fullContent = `
        <p><strong>TUNGKAL ILIR</strong> – Pemerintah Kecamatan Tungkal Ilir kembali menggelar agenda tahunan yang sangat krusial bagi pembangunan desa, yaitu Musyawarah Perencanaan Pembangunan Desa (Musrenbangdes) untuk Tahun Anggaran 2025. Kegiatan ini dijadwalkan akan dimulai secara serentak pada pekan depan, melibatkan seluruh elemen masyarakat dari 14 desa definitif di wilayah kecamatan.</p>
        <p>Camat Tungkal Ilir, Bapak Yudianto I.K., S.Sos, dalam keterangannya menyampaikan bahwa Musrenbangdes tahun ini mengusung tema <em>"Pembangunan Inklusif dan Berkelanjutan Berbasis Potensi Lokal"</em>. Beliau menekankan pentingnya partisipasi aktif warga dalam mengusulkan program-program prioritas yang benar-benar menyentuh kebutuhan dasar masyarakat.</p>
        <h3 class="text-xl font-bold font-headline text-slate-800 my-4">Fokus Pembangunan Tahun 2025</h3>
        <ul class="list-disc list-inside space-y-2 mb-4">
            <li><strong>Infrastruktur Dasar:</strong> Perbaikan jalan poros desa dan jembatan penghubung antar dusun yang menjadi urat nadi perekonomian warga.</li>
            <li><strong>Ketahanan Pangan:</strong> Optimalisasi lahan pertanian pasang surut dan dukungan sarana produksi bagi kelompok tani.</li>
            <li><strong>Pemberdayaan Ekonomi:</strong> Penguatan Badan Usaha Milik Desa (BUMDes) dan pelatihan keterampilan bagi pemuda serta ibu-ibu PKK.</li>
        </ul>
        <p>"Kami berharap usulan yang masuk tidak hanya sekadar daftar keinginan, tetapi merupakan daftar kebutuhan mendesak yang telah disepakati bersama dalam musyawarah dusun sebelumnya," ujar Camat Yudianto.</p>
        <h3 class="text-xl font-bold font-headline text-slate-800 my-4">Jadwal Pelaksanaan</h3>
        <p>Berikut adalah jadwal tentatif pelaksanaan Musrenbangdes di beberapa desa:</p>
        <ul class="list-disc list-inside space-y-2 mb-4">
            <li><strong>Senin, 15 Juli:</strong> Desa Sidomulyo dan Desa Keluang</li>
            <li><strong>Selasa, 16 Juli:</strong> Desa Bentayan dan Desa Bumi Serdang</li>
            <li><strong>Rabu, 17 Juli:</strong> Desa Teluk Tenggulang dan Desa Suka Jaya</li>
        </ul>
        <p>Jadwal lengkap untuk desa-desa lainnya akan segera didistribusikan melalui surat resmi kepada Kepala Desa masing-masing. Masyarakat dihimbau untuk memantau papan pengumuman di kantor desa atau melalui aplikasi SI-PELITA ini.</p>
        <p>Mari bersama-sama kita kawal perencanaan pembangunan ini agar tepat sasaran dan memberikan manfaat maksimal bagi kemajuan Kecamatan Tungkal Ilir yang kita cintai.</p>
    `;
    const relatedArticles = NEWS_DATA.filter(item => [2, 4].includes(item.id));
    const authorRole = "Humas Tungkal Ilir";


    return (
        <div className="min-h-screen flex flex-col bg-muted/40">
            <nav className={cn('fixed top-0 left-0 right-0 z-50 transition-all duration-300', isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-3' : 'bg-white py-4 border-b border-slate-100')}>
                <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <Link href="/pengumuman" className="p-2 hover:bg-slate-100 rounded-full transition text-slate-500">
                            <ArrowLeft size={20}/>
                        </Link>
                        <div className="h-6 w-px bg-slate-200"></div>
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center text-white font-bold text-sm">SP</div>
                            <span className="font-headline font-bold text-slate-800">Detail Berita</span>
                        </div>
                    </div>
                    <Link href="/" className="text-sm font-medium text-accent hover:text-emerald-600 flex items-center gap-1">
                        <Home size={16}/> <span className="hidden sm:inline">Beranda</span>
                    </Link>
                </div>
            </nav>

            <main className="container mx-auto px-4 md:px-6 py-8 mt-20 flex-1">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                    <article className="lg:col-span-8 bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="relative aspect-video w-full overflow-hidden">
                            <img src={article.image} alt={article.title} className="w-full h-full object-cover"/>
                            <div className="absolute top-4 left-4">
                                <span className="bg-accent text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-md">
                                    {article.category}
                                </span>
                            </div>
                        </div>

                        <div className="p-6 md:p-10 pb-0">
                            <h1 className="text-2xl md:text-4xl font-headline font-bold text-slate-900 leading-tight mb-6">
                                {article.title}
                            </h1>
                            
                            <div className="flex items-center justify-between border-b border-slate-100 pb-6 mb-8">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500">
                                        <User size={20}/>
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-slate-800">{article.author}</p>
                                        <p className="text-xs text-slate-500">{authorRole}</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs text-slate-400 mb-1 flex items-center gap-1 justify-end">
                                        <Calendar size={12}/> Diposting
                                    </p>
                                    <p className="text-sm font-medium text-slate-600">{article.date}</p>
                                </div>
                            </div>
                        </div>

                        <div 
                            className="prose prose-lg prose-slate max-w-none px-6 md:px-10 pb-10 font-body"
                            dangerouslySetInnerHTML={{ __html: fullContent }}
                        ></div>

                        <div className="bg-slate-50 px-6 md:px-10 py-6 border-t border-slate-100 flex justify-between items-center">
                            <p className="text-sm font-bold text-slate-500">Bagikan info ini:</p>
                            <div className="flex gap-2">
                                <button className="p-2 bg-white border border-slate-200 rounded-full text-blue-600 hover:bg-blue-50 transition"><Facebook size={18}/></button>
                                <button className="p-2 bg-white border border-slate-200 rounded-full text-green-500 hover:bg-green-50 transition"><MessageCircle size={18}/></button>
                                <button className="p-2 bg-white border border-slate-200 rounded-full text-slate-600 hover:bg-slate-100 transition"><LinkIcon size={18}/></button>
                            </div>
                        </div>
                    </article>

                    <aside className="lg:col-span-4 space-y-8">
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm sticky top-24">
                            <h3 className="font-headline font-bold text-slate-800 mb-6 flex items-center gap-2 pb-4 border-b border-slate-100">
                                <FileText size={20} className="text-accent"/> Berita Terkait
                            </h3>
                            
                            <div className="space-y-6">
                                {relatedArticles.map(item => (
                                    <Link href={`/pengumuman/${item.id}`} key={item.id} className="group flex gap-4 items-start">
                                        <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 relative">
                                            <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-110 transition duration-500"/>
                                        </div>
                                        <div>
                                            <h4 className="font-headline font-bold text-sm text-slate-800 line-clamp-2 mb-2 group-hover:text-accent transition">
                                                {item.title}
                                            </h4>
                                            <span className="text-xs text-slate-400 flex items-center gap-1">
                                                <Calendar size={10}/> {item.date}
                                            </span>
                                        </div>
                                    </Link>
                                ))}
                            </div>

                            <div className="mt-8 pt-6 border-t border-slate-100">
                                <Link href="/pengumuman" className="w-full py-3 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm hover:bg-accent hover:text-white hover:border-accent transition flex items-center justify-center gap-2">
                                    Lihat Semua Berita <ArrowRight size={16}/>
                                </Link>
                            </div>
                        </div>
                    </aside>
                </div>
            </main>
            
            <LandingFooter />
        </div>
    );
}
