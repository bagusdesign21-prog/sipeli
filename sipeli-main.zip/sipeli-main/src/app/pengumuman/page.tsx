

'use client';

import { useState } from 'react';
import { LandingFooter } from '@/components/landing/landing-footer';
import { NEWS_DATA, CATEGORIES } from '@/lib/data-pengumuman';
import { AnnouncementNav } from '@/components/pengumuman/announcement-nav';
import { FeaturedNews } from '@/components/pengumuman/featured-news';
import { CategoryFilter } from '@/components/pengumuman/category-filter';
import { NewsGrid } from '@/components/pengumuman/news-grid';
import { SidebarWidgets } from '@/components/pengumuman/sidebar-widgets';

export default function AnnouncementsPage() {
    const [activeCategory, setActiveCategory] = useState("Semua");
    const [searchQuery, setSearchQuery] = useState("");

    const filteredNews = NEWS_DATA.filter(news => {
        const matchesCategory = activeCategory === "Semua" || news.category === activeCategory;
        const matchesSearch = news.title.toLowerCase().includes(searchQuery.toLowerCase()) || news.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    const featuredNews = NEWS_DATA.find(n => n.featured);

    return (
        <div className="min-h-screen flex flex-col bg-muted/40">
            <AnnouncementNav 
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
            />

            <header className="pt-24 pb-8 md:pb-12 bg-white relative">
                 <div className="container mx-auto px-4 md:px-6">
                    {activeCategory === "Semua" && !searchQuery && featuredNews && (
                       <FeaturedNews news={featuredNews} />
                    )}
                </div>
            </header>

            <main className="container mx-auto px-4 md:px-6 py-8 flex-1">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
                    <div className="lg:col-span-8">
                        <CategoryFilter 
                            categories={CATEGORIES}
                            activeCategory={activeCategory}
                            setActiveCategory={setActiveCategory}
                        />
                        <NewsGrid newsItems={filteredNews} activeCategory={activeCategory} searchQuery={searchQuery} />
                    </div>
                    <aside className="lg:col-span-4">
                        <SidebarWidgets />
                    </aside>
                </div>
            </main>
            
            <LandingFooter />
        </div>
    );
}
