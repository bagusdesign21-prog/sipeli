

'use client';

import { useState, useEffect, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { Home, Info, Map as MapIcon, Maximize, Sprout, UserCheck, Users, Navigation, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { ProfileFooter } from '@/components/profil-kecamatan/profile-footer';
import { useCollection, useDoc, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, doc, query, orderBy } from 'firebase/firestore';
import type { Village } from '@/lib/types';


export default function DetailDesaPage() {
    const params = useParams();
    const router = useRouter();
    const firestore = useFirestore();

    const desaId = Array.isArray(params.desaId) ? params.desaId[0] : params.desaId;

    const villagesQuery = useMemoFirebase(() =>
        firestore ? query(collection(firestore, 'villages'), orderBy('id')) : null
    , [firestore]);

    // Fetch all villages for the top navigation
    const { data: allVillages, isLoading: allVillagesLoading } = useCollection<Village>(villagesQuery);

    // Fetch the specific village for the detail view
    const selectedDesaRef = useMemoFirebase(() =>
        (firestore && desaId) ? doc(firestore, 'villages', desaId) : null
    , [firestore, desaId]);
    const { data: selectedDesa, isLoading: selectedDesaLoading } = useDoc<Village>(selectedDesaRef);
    
    const [isScrolled, setIsScrolled] = useState(false);
    const touchStartX = useRef(0);
    
    useEffect(() => {
        const handleScroll = () => setIsScrolled(window.scrollY > 10);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const handleTouchStart = (e: React.TouchEvent) => {
        touchStartX.current = e.touches[0].clientX;
    };

    const handleTouchEnd = (e: React.TouchEvent) => {
        if (!allVillages) return;
        const touchEndX = e.changedTouches[0].clientX;
        const swipeDistance = touchEndX - touchStartX.current;
        const swipeThreshold = 50; 
        
        const currentIndex = allVillages.findIndex(v => v.id === selectedDesa?.id);
        if (currentIndex === -1) return;

        if (swipeDistance > swipeThreshold) { // Swipe Right
            const prevIndex = (currentIndex - 1 + allVillages.length) % allVillages.length;
            router.push(`/profil-kecamatan/${allVillages[prevIndex].id}`);
        } else if (swipeDistance < -swipeThreshold) { // Swipe Left
            const nextIndex = (currentIndex + 1) % allVillages.length;
            router.push(`/profil-kecamatan/${allVillages[nextIndex].id}`);
        }
    };


    const renderLoadingState = () => (
        <div className="flex items-center justify-center h-screen">
             <Loader2 className="w-10 h-10 animate-spin text-muted-foreground"/>
        </div>
    );

    if (selectedDesaLoading) {
       return renderLoadingState();
    }
    
    if (!selectedDesa) {
        return (
            <div className="flex items-center justify-center h-screen">
                <p>Data desa tidak ditemukan.</p>
            </div>
        );
    }

    return (
        <div 
            className="min-h-screen flex flex-col bg-[#FAF9F6]"
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
        >
            {/* NAVBAR */}
            <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-3' : 'bg-white py-4 border-b border-slate-100'}`}>
                <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <Link href="/profil-kecamatan" className="p-2 hover:bg-slate-100 rounded-full transition text-slate-500">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
                        </Link>
                        <div className="h-6 w-px bg-slate-200"></div>
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center text-white font-bold text-sm">TI</div>
                            <span className="font-headline font-bold text-slate-800">Detail Desa</span>
                        </div>
                    </div>
                    <Link href="/" className="text-sm font-medium text-accent hover:text-emerald-600 flex items-center gap-1">
                        <Home size={16}/> <span className="hidden sm:inline">Beranda</span>
                    </Link>
                </div>
            </nav>

            {/* HERO HEADER */}
            <header className="pt-24 pb-8 md:pb-12 bg-white border-b border-slate-200 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-accent/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
                <div className="container mx-auto px-4 md:px-6 relative z-10 text-center">
                    <h1 className="font-headline text-3xl md:text-4xl font-extrabold text-slate-900 mb-2">Potensi & Data Desa</h1>
                    <p className="text-slate-500">Menjelajahi keunggulan 14 Desa di Kecamatan Tungkal Ilir.</p>
                </div>
            </header>

            {/* MAIN CONTENT AREA */}
            <main className="container mx-auto px-4 md:px-6 py-8 flex-1 w-full">
                
                 {/* HORIZONTAL TAB NAVIGATION */}
                <div className="mb-8">
                     <ScrollArea className="w-full whitespace-nowrap">
                        <div className="flex w-max space-x-2 p-1">
                            {allVillagesLoading ? (
                                <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="w-4 h-4 animate-spin"/> Memuat desa...</div>
                            ) : (
                                allVillages?.map((desa) => (
                                    <button
                                        key={desa.id}
                                        onClick={() => router.push(`/profil-kecamatan/${desa.id}`)}
                                        className={cn(
                                            'inline-block px-4 py-2.5 rounded-full text-sm transition-all duration-200',
                                            selectedDesa.id === desa.id
                                                ? 'bg-accent text-white font-semibold shadow-md shadow-accent/30'
                                                : 'text-slate-600 hover:bg-muted hover:text-accent-foreground'
                                        )}
                                    >
                                        {desa.name}
                                    </button>
                                ))
                            )}
                        </div>
                        <ScrollBar orientation="horizontal" />
                    </ScrollArea>
                </div>


                {/* DETAIL CONTENT AREA */}
                <div className="flex-1" key={selectedDesa.id}>
                    {/* Header Card */}
                    <div className="bg-white rounded-3xl shadow-lg border border-slate-100 overflow-hidden mb-8">
                        <div className={cn("h-32 md:h-48 relative", selectedDesa.imgColor)}>
                            <div className="absolute inset-0 bg-black/20"></div>
                            <div className="absolute bottom-0 left-0 p-6 md:p-8 text-white">
                                <div className="inline-block px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold uppercase tracking-wider mb-2 border border-white/30">
                                    {selectedDesa.status}
                                </div>
                                <h2 className="text-3xl md:text-5xl font-headline font-extrabold">{selectedDesa.name}</h2>
                            </div>
                        </div>
                        <div className="p-6 md:p-8">
                            <div className="flex items-start gap-4 mb-6">
                                <div className="mt-1 text-accent"><Info size={24}/></div>
                                <p className="text-slate-600 leading-relaxed md:text-lg">
                                    {selectedDesa.desc}
                                </p>
                            </div>

                            {/* Stats Grid */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">
                                    <div className="text-slate-400 mb-1 flex justify-center"><Maximize size={20}/></div>
                                    <div className="text-xl font-bold text-slate-800">{selectedDesa.luas}</div>
                                    <div className="text-xs text-slate-500 uppercase tracking-wider">km² Luas</div>
                                </div>
                                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">
                                    <div className="text-slate-400 mb-1 flex justify-center"><Users size={20}/></div>
                                    <div className="text-xl font-bold text-slate-800">{selectedDesa.penduduk}</div>
                                    <div className="text-xs text-slate-500 uppercase tracking-wider">Jiwa</div>
                                </div>
                                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">
                                    <div className="text-slate-400 mb-1 flex justify-center"><Home size={20}/></div>
                                    <div className="text-xl font-bold text-slate-800">{selectedDesa.kk}</div>
                                    <div className="text-xs text-slate-500 uppercase tracking-wider">Kepala Keluarga</div>
                                </div>
                                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">
                                    <div className="text-slate-400 mb-1 flex justify-center"><Sprout size={20}/></div>
                                    <div className="text-sm font-bold text-slate-800 line-clamp-2">{selectedDesa.potensi}</div>
                                    <div className="text-xs text-slate-500 uppercase tracking-wider">Potensi</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Officials Card */}
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                            <h3 className="font-headline font-bold text-lg text-slate-800 mb-4 flex items-center gap-2">
                                <UserCheck className="text-accent"/> Perangkat Desa
                            </h3>
                            <div className="space-y-4">
                                <div className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50 transition">
                                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">KD</div>
                                    <div>
                                        <p className="text-xs text-slate-500 uppercase font-bold">Kepala Desa</p>
                                        <p className="text-slate-800 font-medium">{selectedDesa.kades}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50 transition">
                                    <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-bold">OP</div>
                                    <div>
                                        <p className="text-xs text-slate-500 uppercase font-bold">Operator / Sekdes</p>
                                        <p className="text-slate-800 font-medium">{selectedDesa.operator}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        {/* Map Placeholder / Contact */}
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between">
                            <div>
                                <h3 className="font-headline font-bold text-lg text-slate-800 mb-4 flex items-center gap-2">
                                    <MapIcon className="text-accent"/> Lokasi & Kontak
                                </h3>
                                <p className="text-sm text-slate-600 mb-4">
                                    Kantor Kepala Desa {selectedDesa.name} terletak di pusat pemukiman warga, mudah diakses dan dekat dengan fasilitas umum.
                                </p>
                            </div>
                            <button className="w-full py-2.5 rounded-lg border border-slate-300 text-slate-600 font-bold text-sm hover:border-accent hover:text-accent transition flex items-center justify-center gap-2">
                                <Navigation size={16}/> Petunjuk Arah (Maps)
                            </button>
                        </div>
                    </div>
                </div>
            </main>

            {/* FOOTER */}
            <ProfileFooter />
        </div>
    );
}
