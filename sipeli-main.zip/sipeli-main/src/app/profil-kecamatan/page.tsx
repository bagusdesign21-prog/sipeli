

'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Home } from 'lucide-react';
import { ProfileHeader } from '@/components/profil-kecamatan/profile-header';
import { VisiMisiSection } from '@/components/profil-kecamatan/visi-misi-section';
import { PemerintahanSection } from '@/components/profil-kecamatan/pemerintahan-section';
import { DataDesaSection } from '@/components/profil-kecamatan/data-desa-section';
import { ProfileFooter } from '@/components/profil-kecamatan/profile-footer';


export default function ProfileKecamatanPage() {
    const [isScrolled, setIsScrolled] = useState(false);
    const router = useRouter();

    useEffect(() => {
        const handleScroll = () => setIsScrolled(window.scrollY > 20);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div className="min-h-screen flex flex-col bg-white">
            
            <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-3' : 'bg-white py-4 border-b border-slate-100'}`}>
                <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <Link href="/" className="p-2 hover:bg-slate-100 rounded-full transition text-slate-500">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
                        </Link>
                        <div className="h-6 w-px bg-slate-200"></div>
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center text-white font-bold text-sm">TI</div>
                            <span className="font-headline font-bold text-slate-800">Profil Kecamatan</span>
                        </div>
                    </div>
                    <Link href="/" className="text-sm font-medium text-accent hover:text-emerald-600 flex items-center gap-1">
                        <Home size={16}/> <span className="hidden sm:inline">Beranda</span>
                    </Link>
                </div>
            </nav>

            <ProfileHeader />

            <main className="container mx-auto px-4 md:px-6 py-12 space-y-20">
                
                <VisiMisiSection />

                <PemerintahanSection />

                <DataDesaSection />

            </main>

            <ProfileFooter />
        </div>
    );
}
