
'use client';

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { useAuth, useCollection, useMemoFirebase, useFirestore, useUser } from "@/firebase";
import { collection, setDoc, doc } from 'firebase/firestore';

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CreditCard, Mail, Lock, CheckSquare, ArrowLeft, Info } from "lucide-react";
import type { Village } from '@/lib/types';
import { cn } from "@/lib/utils";
import { RoleSwitcher, type Role } from "./RoleSwitcher";
import { User as UserIconLucide } from 'lucide-react';


declare global {
  interface Window {
    grecaptcha: any;
  }
}

const formSchema = z.object({
  nik: z.string().length(16, "NIK harus 16 digit"),
  nama: z.string().min(2, "Nama terlalu pendek"),
  desa: z.string().min(1, "Silakan pilih desa"),
  email: z.string().email("Format email tidak valid"),
  password: z.string().min(8, "Password minimal 8 karakter"),
  confirmPassword: z.string(),
  kodeRegistrasi: z.string().optional(),
  terms: z.boolean().refine(val => val === true, {
    message: "Anda harus menyetujui syarat & ketentuan.",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "Konfirmasi password tidak cocok",
  path: ["confirmPassword"],
});

type FormValues = z.infer<typeof formSchema>;

export function RegistrationForm() {
  const router = useRouter();
  const { toast } = useToast();
  const auth = useAuth();
  const firestore = useFirestore();
  const { user, isUserLoading } = useUser();

  const [role, setRole] = useState<Role>('warga');
  const [isLoading, setIsLoading] = useState(false);


  const villagesQuery = useMemoFirebase(() => {
    if (!firestore) return null;
    return collection(firestore, 'villages');
  }, [firestore]);
  const { data: villages, isLoading: villagesLoading } = useCollection<Village>(villagesQuery);

  
  useEffect(() => {
    if (!isUserLoading && user) {
       // If user is already logged in, middleware will handle redirection.
       // We can simply push them to a generic path to trigger it.
       router.replace('/warga/dashboard');
    }
  }, [user, isUserLoading, router]);


  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    mode: "onChange",
    defaultValues: {
      nik: "",
      nama: "",
      desa: "",
      email: "",
      password: "",
      confirmPassword: "",
      kodeRegistrasi: "",
      terms: false,
    },
  });
  
  useEffect(() => {
    form.reset();
    const newSchema = z.object({
      nik: z.string().length(16, "NIK harus 16 digit"),
      nama: z.string().min(2, "Nama terlalu pendek"),
      desa: z.string().min(1, "Silakan pilih desa"),
      email: z.string().email("Format email tidak valid"),
      password: z.string().min(8, "Password minimal 8 karakter"),
      confirmPassword: z.string(),
      kodeRegistrasi: role === 'perangkat' ? z.string().min(4, "Kode registrasi diperlukan") : z.string().optional(),
      terms: z.boolean().refine(val => val === true, {
        message: "Anda harus menyetujui syarat & ketentuan.",
      }),
    }).refine(data => data.password === data.confirmPassword, {
      message: "Konfirmasi password tidak cocok",
      path: ["confirmPassword"],
    });

    form.trigger();
  }, [role, form]);


  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    setIsLoading(true);

    window.grecaptcha.enterprise.ready(async () => {
      try {
        const token = await window.grecaptcha.enterprise.execute(process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY, {action: 'REGISTER'});
        
        if (role === 'perangkat' && !data.kodeRegistrasi) {
            throw new Error("Kode registrasi diperlukan untuk perangkat desa.");
        }
        
        if (!auth || !firestore) {
            throw new Error("Layanan autentikasi tidak tersedia.");
        }

        const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
        const user = userCredential.user;

        if (user) {
            const userDocRef = doc(firestore, "users", user.uid);
            await setDoc(userDocRef, {
                id: user.uid,
                ktpNumber: data.nik,
                kkNumber: "",
                fullName: data.nama,
                address: data.desa,
                role: role, 
            });
        }

        toast({
          title: "Pendaftaran Berhasil!",
          description: "Akun Anda telah dibuat. Silakan masuk.",
        });
        router.push("/login");

      } catch (error: any) {
          console.error("Registration error:", error);
          const errorMessage = error.code === 'auth/email-already-in-use'
              ? "Email ini sudah terdaftar. Silakan masuk."
              : "Terjadi kesalahan saat pendaftaran. Silakan coba lagi.";
        toast({
          variant: "destructive",
          title: "Pendaftaran Gagal",
          description: errorMessage,
        });
      } finally {
        setIsLoading(false);
      }
    });
  };
  
  const nikValue = form.watch("nik");

  if (isUserLoading) {
    return (
        <div className="flex-1 flex flex-col justify-center items-center p-6">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground"/>
            <p className="mt-4 text-muted-foreground">Memeriksa sesi...</p>
        </div>
    );
  }

  if (user) {
      return (
          <div className="flex-1 flex flex-col justify-center items-center p-6">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground"/>
            <p className="mt-4 text-muted-foreground">Anda sudah login, mengalihkan...</p>
        </div>
      )
  }

  return (
    <div className="flex-1 flex flex-col justify-center p-6 md:p-12 lg:p-20 overflow-y-auto">
        <div className="max-w-md mx-auto w-full">
            
            <div className="mb-8 text-center md:text-left">
                <Link href="/" className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-accent mb-6 transition">
                    <ArrowLeft size={16}/> Kembali ke Beranda
                </Link>
                <h2 className="font-headline text-3xl font-bold text-slate-900 mb-2">Buat Akun Baru</h2>
                <p className="text-slate-500">Silakan lengkapi data diri Anda untuk mendaftar.</p>
            </div>

            <RoleSwitcher role={role} setRole={setRole} />

            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                    
                    {role === 'perangkat' && (
                        <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg text-sm flex items-start gap-3">
                            <Info size={18} className="mt-0.5 flex-shrink-0"/>
                            <p>Pendaftaran Perangkat Desa memerlukan <strong>Kode Registrasi</strong> khusus dari Admin Kecamatan.</p>
                        </div>
                    )}
                    
                    <FormField control={form.control} name="nik" render={({ field }) => (
                        <FormItem>
                            <FormLabel className="uppercase text-xs font-bold">NIK (Nomor Induk Kependudukan)</FormLabel>
                            <FormControl>
                                <div className="relative">
                                    <Input
                                        type="text"
                                        placeholder="16 digit angka"
                                        {...field}
                                        onChange={(e) => {
                                            const numericValue = e.target.value.replace(/[^0-9]/g, '');
                                            if (numericValue.length <= 16) {
                                                field.onChange(numericValue);
                                            }
                                        }}
                                        className={cn(
                                            "pl-10",
                                            nikValue?.length === 16 ? "text-green-600 font-medium" : ""
                                        )}
                                    />
                                    <CreditCard size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}/>
                    
                    <FormField control={form.control} name="nama" render={({ field }) => (
                        <FormItem>
                            <FormLabel className="uppercase text-xs font-bold">Nama Lengkap</FormLabel>
                            <FormControl>
                                <div className="relative">
                                    <Input placeholder="Sesuai KTP" {...field} className="pl-10"/>
                                    <UserIconLucide size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}/>

                    <div className={`grid ${role === 'perangkat' ? 'grid-cols-2' : 'grid-cols-1'} gap-4`}>
                         <FormField control={form.control} name="desa" render={({ field }) => (
                            <FormItem>
                                <FormLabel className="uppercase text-xs font-bold">Desa Domisili</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Pilih Desa..." />
                                        </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        {villagesLoading ? <SelectItem value="loading" disabled>Memuat...</SelectItem> :
                                         villages?.map(v => <SelectItem key={v.id} value={v.name}>{v.name}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                            </FormItem>
                        )}/>
                        {role === 'perangkat' && (
                            <FormField control={form.control} name="kodeRegistrasi" render={({ field }) => (
                                <FormItem>
                                    <FormLabel className="uppercase text-xs font-bold">Kode Registrasi</FormLabel>
                                    <FormControl>
                                        <Input placeholder="Kode Unik" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}/>
                        )}
                    </div>
                    
                    <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem>
                            <FormLabel className="uppercase text-xs font-bold">Email</FormLabel>
                             <FormControl>
                                <div className="relative">
                                    <Input placeholder="contoh@email.com" {...field} className="pl-10"/>
                                    <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}/>

                     <FormField control={form.control} name="password" render={({ field }) => (
                        <FormItem>
                            <FormLabel className="uppercase text-xs font-bold">Password</FormLabel>
                             <FormControl>
                                <div className="relative">
                                    <Input type="password" placeholder="Minimal 8 karakter" {...field} className="pl-10"/>
                                    <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}/>

                     <FormField control={form.control} name="confirmPassword" render={({ field }) => (
                        <FormItem>
                            <FormLabel className="uppercase text-xs font-bold">Konfirmasi Password</FormLabel>
                             <FormControl>
                                <div className="relative">
                                    <Input type="password" placeholder="Ulangi password" {...field} className="pl-10"/>
                                    <CheckSquare size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}/>
                    
                    <FormField control={form.control} name="terms" render={({ field }) => (
                        <FormItem className="flex items-start gap-3 pt-2">
                             <FormControl>
                                <input type="checkbox" id="terms" checked={field.value} onChange={field.onChange} className="mt-1 accent-accent w-4 h-4"/>
                             </FormControl>
                             <div className="grid gap-1.5 leading-none">
                                <label htmlFor="terms" className="text-sm text-slate-500 leading-tight cursor-pointer">
                                    Saya menyetujui <Link href="/legal" className="text-accent hover:underline font-bold">Syarat &amp; Ketentuan</Link> serta <Link href="/legal" className="text-accent hover:underline font-bold">Kebijakan Privasi</Link> yang berlaku.
                                </label>
                                <FormMessage />
                             </div>
                        </FormItem>
                    )}/>
                    
                    <Button 
                        type="submit"
                        disabled={isLoading}
                        className="w-full py-3.5 h-auto bg-accent hover:bg-emerald-600 text-white font-bold rounded-xl shadow-lg transition text-base transform hover:-translate-y-0.5"
                    >
                        {isLoading ? <><Loader2 size={20} className="animate-spin"/> Mendaftar...</> : 'Daftar Sekarang'}
                    </Button>

                </form>
            </Form>

            <div className="mt-8 text-center">
                <p className="text-slate-500 text-sm">
                    Sudah punya akun? <Link href="/login" className="font-bold text-slate-800 hover:text-accent transition">Masuk di sini</Link>
                </p>
            </div>

        </div>
    </div>
  );
}
