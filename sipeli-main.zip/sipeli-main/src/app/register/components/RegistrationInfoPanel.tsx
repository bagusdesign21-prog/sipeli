
import Link from 'next/link';
import { CheckCircle, ShieldCheck } from 'lucide-react';

export function RegistrationInfoPanel() {
  return (
    <div className="hidden md:flex md:w-1/2 bg-slate-900 text-white flex-col justify-between p-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
        
        <div className="relative z-10">
            <Link href="/" className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center text-white font-bold text-xl">SP</div>
                <span className="font-headline font-bold text-xl tracking-tight">SI-PELITA</span>
            </Link>
            <h1 className="font-headline text-4xl font-extrabold leading-tight mb-6">
                Bergabunglah Bersama<br/>
                <span className="text-accent">Masyarakat Digital</span><br/>
                Tungkal Ilir.
            </h1>
            <p className="text-slate-400 text-lg leading-relaxed max-w-md">
                Nikmati kemudahan layanan administrasi desa tanpa antre, akses informasi transparan, dan sampaikan aspirasi Anda langsung dari rumah.
            </p>
        </div>

        <div className="relative z-10 space-y-4">
            <div className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
                <div className="p-3 bg-accent/20 rounded-xl text-accent"><CheckCircle size={24}/></div>
                <div>
                    <h4 className="font-bold">Layanan Mandiri 24/7</h4>
                    <p className="text-sm text-slate-400">Ajukan surat kapan saja, di mana saja.</p>
                </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
                <div className="p-3 bg-orange-500/20 rounded-xl text-orange-400"><ShieldCheck size={24}/></div>
                <div>
                    <h4 className="font-bold">Data Aman & Tervalidasi</h4>
                    <p className="text-sm text-slate-400">Terintegrasi dengan data kependudukan resmi.</p>
                </div>
            </div>
        </div>

        <p className="relative z-10 text-xs text-slate-500 mt-12">© {new Date().getFullYear()} Pemerintah Kecamatan Tungkal Ilir.</p>
    </div>
  );
}
