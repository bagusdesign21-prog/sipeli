
'use client';

import { Briefcase, User } from "lucide-react";

export type Role = 'warga' | 'perangkat';

interface RoleSwitcherProps {
  role: Role;
  setRole: (role: Role) => void;
}

export function RoleSwitcher({ role, setRole }: RoleSwitcherProps) {
  return (
    <div className="bg-slate-100 p-1.5 rounded-xl flex mb-8">
        <button 
            onClick={() => setRole('warga')}
            className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition flex items-center justify-center gap-2 ${role === 'warga' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
            <User size={16}/> Warga
        </button>
        <button 
            onClick={() => setRole('perangkat')}
            className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition flex items-center justify-center gap-2 ${role === 'perangkat' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
            <Briefcase size={16}/> Perangkat Desa / ASN
        </button>
    </div>
  );
}
