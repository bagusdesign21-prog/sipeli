
import { RegistrationInfoPanel } from './components/RegistrationInfoPanel';
import { RegistrationForm } from './components/RegistrationForm';

export default function RegisterPage() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-white">
        <RegistrationInfoPanel />
        <RegistrationForm />
    </div>
  );
}
