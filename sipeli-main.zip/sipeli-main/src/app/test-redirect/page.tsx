
'use client';

import Link from 'next/link';

export default function TestRedirectPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 text-center">
      <div className="bg-white p-10 rounded-lg shadow-md border border-slate-200">
        <h1 className="text-2xl font-bold text-red-600 mb-4">Akses Gagal</h1>
        <p className="text-slate-600 mb-6 max-w-sm">
          Jika Anda melihat halaman ini, artinya pengalihan otomatis setelah login tidak berfungsi dengan benar.
        </p>
        <Link href="/" className="text-blue-600 font-medium hover:underline">
          Kembali ke Beranda
        </Link>
      </div>
    </div>
  );
}
