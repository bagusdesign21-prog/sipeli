import { DashboardClient } from '@/components/warga/DashboardClient';

export default function WargaDashboardPage() {
  return <DashboardClient />;
}
