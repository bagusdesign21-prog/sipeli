'use client';

import { WargaSidebar } from '@/components/warga/WargaSidebar';
import { WargaHeader } from '@/components/warga/WargaHeader';
import { useState } from 'react';

export default function WargaLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen flex bg-[#F8FAFC]">
      <WargaSidebar
        isSidebarOpen={isSidebarOpen}
        setIsSidebarOpen={setIsSidebarOpen}
      />
      <main className="flex-1 md:ml-64 flex flex-col min-h-screen">
        <WargaHeader setIsSidebarOpen={setIsSidebarOpen} />
        <div className="p-4 md:p-8 max-w-5xl mx-auto w-full">
            {children}
        </div>
      </main>
    </div>
  );
}
