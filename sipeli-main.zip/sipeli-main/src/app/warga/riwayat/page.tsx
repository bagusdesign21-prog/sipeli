
'use client';

import { useState, useEffect } from 'react';
import {
  Check,
  ChevronDown,
  ChevronUp,
  Clock,
  Download,
  Edit2,
  Eye,
  FileCheck,
  FileSearch,
  Info,
  User,
  XCircle,
  ArrowLeft,
  Calendar,
} from 'lucide-react';
import Link from 'next/link';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, where } from 'firebase/firestore';
import type { ServiceHistory } from '@/lib/types';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const STEPS = [
  { id: 1, label: 'Dikirim' },
  { id: 2, label: 'Verifikasi' },
  { id: 3, label: 'TTE Camat' },
  { id: 4, label: 'Selesai' },
];

export default function RiwayatLayananPage() {
  const [filter, setFilter] = useState('Semua');
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  
  const { user } = useUser();
  const firestore = useFirestore();

  const historyQuery = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return query(collection(firestore, 'serviceHistory'), where('userId', '==', user.uid));
  }, [firestore, user]);

  const { data: historyData, isLoading: historyLoading } = useCollection<ServiceHistory>(historyQuery);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const filteredData =
    !historyData ? [] :
    filter === 'Semua'
      ? historyData
      : historyData.filter((item) => item.status === filter);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Selesai':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'Diproses':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Ditolak':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  const getStatusIcon = (status: string) => {
      switch(status) {
          case 'Selesai': return <FileCheck size={24} />;
          case 'Ditolak': return <XCircle size={24} />;
          default: return <Clock size={24} />
      }
  }
  
  const getStatusIconColor = (status: string) => {
      switch(status) {
          case 'Selesai': return 'bg-green-50 text-green-600';
          case 'Ditolak': return 'bg-red-50 text-red-600';
          default: return 'bg-blue-50 text-blue-600';
      }
  }


  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC]">
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-sm py-3'
            : 'bg-white py-4 border-b border-slate-100'
        }`}
      >
        <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Link
              href="/warga/dashboard"
              className="p-2 hover:bg-slate-100 rounded-full transition text-slate-500"
            >
              <ArrowLeft size={20} />
            </Link>
            <div className="h-6 w-px bg-slate-200"></div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center text-white font-bold text-sm">
                SP
              </div>
              <span className="font-headline font-bold text-slate-800">
                Riwayat Layanan
              </span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-slate-600 hidden sm:inline">
              {user?.displayName || user?.email}
            </span>
            <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center text-slate-500 overflow-hidden">
              <User size={16} />
            </div>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 md:px-6 py-8 mt-20 flex-1 max-w-4xl">
        <div className="flex gap-2 overflow-x-auto pb-4 mb-6">
          {['Semua', 'Diproses', 'Selesai', 'Ditolak'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition border ${
                filter === f
                  ? 'bg-slate-800 text-white border-slate-800'
                  : 'bg-white text-slate-500 border-slate-200 hover:border-accent hover:text-accent'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {historyLoading ? (
            <div className="text-center py-12">
              <Loader2 className="mx-auto h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : filteredData.length > 0 ? (
            filteredData.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden transition hover:shadow-md"
              >
                <div
                  className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer"
                  onClick={() =>
                    setSelectedItem(selectedItem === item.id ? null : item.id)
                  }
                >
                  <div className="flex items-start gap-4">
                    <div
                      className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${getStatusIconColor(item.status)}`}
                    >
                      {getStatusIcon(item.status)}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800 text-lg mb-1">
                        {item.type}
                      </h4>
                      <div className="flex items-center gap-3 text-xs text-slate-500">
                        <span className="font-mono bg-slate-100 px-2 py-0.5 rounded">
                          {item.id.substring(0, 8)}...
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar size={12} /> {new Date(item.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between sm:justify-end gap-3 w-full sm:w-auto">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold border ${getStatusColor(
                        item.status
                      )}`}
                    >
                      {item.status}
                    </span>
                    {selectedItem === item.id ? <ChevronUp size={20} className="text-slate-400" /> : <ChevronDown size={20} className="text-slate-400" />}
                  </div>
                </div>

                {selectedItem === item.id && (
                  <div className="border-t border-slate-100 bg-slate-50 p-5 sm:p-8 animate-in slide-in-from-top-2 fade-in duration-200">
                    <div className="mb-8 relative">
                      <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-200 -translate-y-1/2 rounded-full z-0"></div>
                      <div
                        className={`absolute top-1/2 left-0 h-1 -translate-y-1/2 rounded-full z-0 transition-all duration-500 ${
                          item.status === 'Ditolak' ? 'bg-red-500' : 'bg-accent'
                        }`}
                        style={{
                          width: `${
                            ((item.step - 1) / (STEPS.length - 1)) * 100
                          }%`,
                        }}
                      ></div>

                      <div className="relative z-10 flex justify-between w-full">
                        {STEPS.map((step) => (
                          <div
                            key={step.id}
                            className="flex flex-col items-center gap-2"
                          >
                            <div
                              className={cn(`w-8 h-8 rounded-full flex items-center justify-center border-2 text-xs font-bold transition-all duration-300`,
                                item.step >= step.id
                                  ? item.status === 'Ditolak' &&
                                    item.step === step.id
                                    ? 'bg-red-500 border-red-500 text-white'
                                    : 'bg-accent border-accent text-white'
                                  : 'bg-white border-slate-300 text-slate-400'
                              )}
                            >
                              {item.step > step.id ? (
                                <Check size={14} />
                              ) : (
                                step.id
                              )}
                            </div>
                            <span
                              className={`text-[10px] font-bold ${
                                item.step >= step.id
                                  ? 'text-slate-700'
                                  : 'text-slate-400'
                              }`}
                            >
                              {step.label}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div
                      className={`p-4 rounded-xl border mb-6 flex gap-3 ${
                        item.status === 'Ditolak'
                          ? 'bg-red-50 border-red-100 text-red-700'
                          : 'bg-blue-50 border-blue-100 text-blue-700'
                      }`}
                    >
                      <Info size={20} className="flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-sm mb-1">
                          Status Terkini:
                        </p>
                        <p className="text-sm">{item.note}</p>
                      </div>
                    </div>

                    <div className="flex gap-3 justify-end">
                      {item.status === 'Selesai' && (
                        <button className="px-4 py-2 bg-accent hover:bg-emerald-600 text-white rounded-lg text-sm font-bold flex items-center gap-2 shadow-sm transition">
                          <Download size={16} /> Unduh Dokumen
                        </button>
                      )}
                      {item.status === 'Ditolak' && (
                        <button className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-sm font-bold flex items-center gap-2 shadow-sm transition">
                          <Edit2 size={16} /> Perbaiki Pengajuan
                        </button>
                      )}
                      <button className="px-4 py-2 bg-white border border-slate-300 text-slate-600 hover:bg-slate-50 rounded-lg text-sm font-bold flex items-center gap-2 transition">
                        <Eye size={16} /> Lihat Detail
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-12 bg-white rounded-xl border border-slate-200 border-dashed">
              <div className="inline-flex p-4 bg-slate-50 rounded-full text-slate-300 mb-4">
                <FileSearch size={32} />
              </div>
              <p className="text-slate-500 font-medium">
                Belum ada riwayat pengajuan.
              </p>
              <button className="mt-4 px-4 py-2 text-sm text-accent font-bold hover:underline">
                Buat Pengajuan Baru
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
