'use client';

import { SidebarTrigger } from '@/components/ui/sidebar';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from './ui/breadcrumb';
import { usePathname, useRouter } from 'next/navigation';
import { Fragment } from 'react';
import Link from 'next/link';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Button } from './ui/button';
import { useUser, useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from './ui/skeleton';

export function AppHeader() {
    const pathname = usePathname();
    const router = useRouter();
    const { toast } = useToast();
    const auth = useAuth();
    const { user, isUserLoading } = useUser();
    const pathSegments = pathname.split('/').filter(Boolean);
    const avatar = PlaceHolderImages.find((img) => img.id === 'user-avatar');
    
    const roleBasePath = pathSegments[0] === 'admin' ? '/admin' : '/pegawai';
    const breadcrumbs = pathSegments.slice(1);

    const handleLogout = async () => {
        try {
            await signOut(auth);
            // Clear cookies
            document.cookie = 'firebaseIdToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
            document.cookie = 'userRole=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
            toast({ title: 'Logged Out', description: 'You have been successfully logged out.' });
            router.push('/login');
        } catch (error) {
            toast({ variant: 'destructive', title: 'Logout Failed', description: 'Could not log you out. Please try again.' });
        }
    };


    return (
      <header className="flex h-14 items-center gap-4 border-b bg-background/60 px-6 backdrop-blur-sm">
        <SidebarTrigger className="md:hidden" />
        <Breadcrumb className="hidden flex-1 md:flex">
            <BreadcrumbList>
                <BreadcrumbItem>
                    <BreadcrumbLink asChild>
                    <Link href={roleBasePath}>Home</Link>
                    </BreadcrumbLink>
                </BreadcrumbItem>
                {breadcrumbs.map((crumb, index) => (
                    <Fragment key={crumb}>
                    <BreadcrumbSeparator />
                    <BreadcrumbItem>
                        {index === breadcrumbs.length - 1 ? (
                        <BreadcrumbPage className="font-semibold capitalize text-foreground">
                            {crumb.replace('-', ' ')}
                        </BreadcrumbPage>
                        ) : (
                        <BreadcrumbLink asChild>
                            <Link href={`${roleBasePath}/${breadcrumbs.slice(0, index + 1).join('/')}`} className="capitalize">
                            {crumb.replace('-', ' ')}
                            </Link>
                        </BreadcrumbLink>
                        )}
                    </BreadcrumbItem>
                    </Fragment>
                ))}
            </BreadcrumbList>
        </Breadcrumb>
         <DropdownMenu>
            <DropdownMenuTrigger asChild>
            <Button
                variant="outline"
                size="icon"
                className="overflow-hidden rounded-full ml-auto"
            >
                {isUserLoading ? (
                     <Skeleton className="h-8 w-8 rounded-full" />
                ) : (
                     avatar && (
                        <Image
                            src={avatar.imageUrl}
                            width={36}
                            height={36}
                            alt="Avatar"
                            className="overflow-hidden rounded-full"
                            data-ai-hint={avatar.imageHint}
                        />
                    )
                )}
            </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
            <DropdownMenuLabel>{user ? user.email : 'My Account'}</DropdownMenuLabel>
            <DropdownMenuSeparator />
             <Link href="/pegawai/profile">
                <DropdownMenuItem>Profile</DropdownMenuItem>
            </Link>
            <DropdownMenuItem>Support</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
      </header>
    );
}