'use client'

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
} from '@/components/ui/sidebar';
import { Archive, FileText, Home, MessageSquareQuote, ClipboardList, Settings, User, LogOut, ChevronDown, LifeBuoy, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Separator } from './ui/separator';
import { useUser, useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from './ui/button';

export function AppSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { toast } = useToast();
  const auth = useAuth();
  const { user } = useUser();
  
  const isAdmin = pathname.startsWith('/admin');

  const baseNavItems = [
    { href: '/dashboard', icon: Home, label: 'Dashboard' },
    { href: '/documents', icon: FileText, label: 'Document Builder' },
    { href: '/guestbook', icon: MessageSquareQuote, label: 'Guestbook' },
    { href: '/forms', icon: ClipboardList, label: 'Forms' },
    { href: '/archive', icon: Archive, label: 'Archive' },
  ];

  const navItems = baseNavItems.map(item => ({
    ...item,
    href: `${isAdmin ? '/admin' : '/pegawai'}${item.href}`,
    isActive: pathname === `${isAdmin ? '/admin' : '/pegawai'}${item.href}` || pathname.startsWith(`${isAdmin ? '/admin' : '/pegawai'}${item.href}/`),
  }));
  
  if (pathname.startsWith('/admin/dashboard')) {
      navItems.find(item => item.label === 'Dashboard')!.isActive = true;
  } else if (pathname.startsWith('/pegawai/dashboard')) {
      navItems.find(item => item.label === 'Dashboard')!.isActive = true;
  }

  const handleLogout = async () => {
    try {
        await signOut(auth);
        toast({ title: 'Logged Out', description: 'You have been successfully logged out.' });
        router.push('/login');
    } catch (error) {
        toast({ variant: 'destructive', title: 'Logout Failed', description: 'Could not log you out. Please try again.' });
    }
  };


  return (
    <Sidebar>
      <SidebarHeader>
        <div className="flex items-center gap-2.5">
           <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
               <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
             </svg>
           </div>
           <span className="font-bold text-lg font-headline">SI-PELITA</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {navItems.map((item) => (
            <SidebarMenuItem key={item.label}>
              <SidebarMenuButton asChild isActive={item.isActive} tooltip={item.label}>
                <Link href={item.href}>
                  <item.icon />
                  <span>{item.label}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
           {isAdmin && (
                <SidebarMenuItem>
                    <SidebarMenuButton asChild isActive={pathname.startsWith('/admin/users')} tooltip="User Management">
                        <Link href="#">
                            <ShieldCheck />
                            <span>User Management</span>
                        </Link>
                    </SidebarMenuButton>
                </SidebarMenuItem>
            )}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter>
        <Separator className='mb-2' />
        <SidebarMenu>
            <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Support">
                     <Link href="#">
                        <LifeBuoy />
                        <span>Support</span>
                    </Link>
                </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Profile" isActive={pathname.startsWith('/pegawai/profile')}>
                     <Link href="/pegawai/profile">
                        <User />
                        <span>Profile</span>
                    </Link>
                </SidebarMenuButton>
            </SidebarMenuItem>
             <SidebarMenuItem>
                <SidebarMenuButton onClick={handleLogout} tooltip="Logout">
                    <LogOut />
                    <span>Logout</span>
                </SidebarMenuButton>
            </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}