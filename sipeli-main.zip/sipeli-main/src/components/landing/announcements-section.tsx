
import { cn } from '@/lib/utils';
import Link from 'next/link';

const ANNOUNCEMENTS = [
    { id: 1, tag: "PENTING", title: "Jadwal Musrenbangdes 2025", date: "2 Jam lalu", desc: "Dimohon kehadiran seluruh perangkat desa untuk pembahasan prioritas pembangunan." },
    { id: 2, tag: "INFO", title: "Pencairan BLT Dana Desa Tahap II", date: "1 Hari lalu", desc: "Dana Desa tahap 2 telah masuk ke RKDes. Jadwal penyaluran akan diumumkan segera." },
    { id: 3, tag: "UPDATE", title: "Pemutakhiran Data Prodeskel", date: "3 Hari lalu", desc: "Batas akhir update data profil desa semester 1 adalah tanggal 30 Juli." }
];

export function AnnouncementsSection() {
    return (
        <section id="pengumuman" className="py-16 bg-white">
            <div className="container mx-auto px-4 md:px-6">
                <div className="flex justify-between items-end mb-8">
                    <div>
                        <h2 className="text-2xl font-bold text-slate-900 font-ui">Papan Informasi</h2>
                        <p className="text-slate-500">Kabar terkini dari Kecamatan dan Desa.</p>
                    </div>
                    <Link href="/pengumuman" className="text-sm font-bold text-[#66CDAA] hover:underline hidden sm:block font-ui">Lihat Semua →</Link>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {ANNOUNCEMENTS.map((item) => (
                        <div key={item.id} className="group bg-[#FAF9F6] hover:bg-white border border-transparent hover:border-slate-200 p-6 rounded-2xl transition shadow-sm hover:shadow-md cursor-pointer">
                            <div className="flex justify-between items-start mb-4">
                                <span className={cn('px-2 py-1 rounded text-[10px] font-bold tracking-wider font-ui', 
                                    item.tag === 'PENTING' ? 'bg-red-100 text-red-600' : 
                                    item.tag === 'INFO' ? 'bg-blue-100 text-blue-600' : 
                                    'bg-orange-100 text-orange-600'
                                )}>{item.tag}</span>
                                <span className="text-xs text-slate-400">{item.date}</span>
                            </div>
                            <h3 className="font-bold text-lg text-slate-800 mb-2 group-hover:text-[#66CDAA] transition font-ui">{item.title}</h3>
                            <p className="text-sm text-slate-500 leading-relaxed line-clamp-2">{item.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
