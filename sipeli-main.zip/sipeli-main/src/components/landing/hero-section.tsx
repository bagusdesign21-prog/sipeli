
'use client';

import Link from 'next/link';
import { FilePlus, Search, Star, Check, User } from 'lucide-react';

const STATS = [
    { label: "Desa Definitif", val: "14" },
    { label: "Penduduk Terlayani", val: "32.8k" },
    { label: "Layanan Online", val: "24/7" },
];

export function HeroSection() {
  return (
    <section id="beranda" className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-4 overflow-hidden">
        <div className="absolute top-[-10%] right-[-5%] w-[600px] h-[600px] bg-primary/40 rounded-full blur-[120px] animate-float opacity-60"></div>
        <div className="absolute bottom-[10%] left-[-10%] w-[500px] h-[500px] bg-accent/20 rounded-full blur-[100px] opacity-50"></div>

        <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
                 <div className="animate-in fade-in slide-in-from-bottom-8 duration-700 text-center lg:text-left">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 text-orange-600 text-xs font-bold mb-6 border border-orange-200 font-ui">
                        <Star size={12} className="fill-current"/> 
                        MOTTO: P.R.I.M.A (Profesional, Ramah, Inovatif, Mudah, Akuntabel)
                    </div>
                    <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-slate-900 leading-tight mb-6 font-ui">
                        Urusan Desa <br/>
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-emerald-600">
                            Jadi Lebih Mudah.
                        </span>
                    </h1>
                    <p className="text-lg text-slate-600 mb-8 leading-relaxed max-w-lg mx-auto lg:mx-0">
                        Layanan administrasi terpadu Kecamatan Tungkal Ilir. Ajukan surat, pantau pembangunan desa, dan sampaikan aspirasi dalam satu aplikasi.
                    </p>
                    
                    <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                        <Link href="/pegawai/documents" className="px-8 py-4 bg-accent hover:bg-emerald-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-accent/30 transition transform hover:-translate-y-1 flex items-center justify-center gap-2 font-ui">
                            <FilePlus size={20}/> Buat Permohonan
                        </Link>
                        <Link href="/#layanan" className="px-8 py-4 bg-white border border-slate-200 hover:border-accent text-slate-700 rounded-xl font-bold text-lg shadow-sm transition flex items-center justify-center gap-2 font-ui">
                            <Search size={20}/> Cek Layanan
                        </Link>
                    </div>

                    <div className="mt-12 flex items-center justify-center lg:justify-start gap-8 border-t border-slate-200/60 pt-8">
                        {STATS.map((stat, i) => (
                            <div key={i}>
                                <p className="text-2xl font-bold text-slate-900 font-ui">{stat.val}</p>
                                <p className="text-xs text-slate-500 uppercase tracking-wide font-semibold font-ui">{stat.label}</p>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Hero Visual */}
                <div className="relative hidden lg:block">
                    <div className="relative z-10 glass-card p-4 rounded-2xl shadow-2xl transform rotate-[-2deg] hover:rotate-0 transition duration-500">
                        <div className="bg-slate-50 rounded-xl overflow-hidden border border-slate-100">
                            <div className="h-8 bg-white border-b flex items-center px-3 gap-2">
                                <div className="flex gap-1.5"><div className="w-2.5 h-2.5 rounded-full bg-red-400"></div><div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div><div className="w-2.5 h-2.5 rounded-full bg-green-400"></div></div>
                                <div className="bg-slate-100 px-3 py-0.5 rounded text-[10px] text-slate-400 flex-1 text-center">sipelita.tungkalilir.go.id</div>
                            </div>
                            <div className="p-6 space-y-4">
                                <div className="flex gap-4 mb-6">
                                    <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-orange-600"><User size={32}/></div>
                                    <div><div className="h-4 w-32 bg-slate-200 rounded mb-2"></div><div className="h-3 w-48 bg-slate-100 rounded"></div></div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-100"><div className="h-8 w-8 bg-blue-100 rounded mb-2"></div><div className="h-3 w-20 bg-slate-200 rounded"></div></div>
                                    <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-100"><div className="h-8 w-8 bg-green-100 rounded mb-2"></div><div className="h-3 w-20 bg-slate-200 rounded"></div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="absolute -top-4 -right-2 z-50 bg-white p-3 rounded-xl shadow-lg border border-slate-100 animate-float delay-700">
                        <div className="flex items-center gap-2">
                            <div className="bg-green-100 p-1.5 rounded-lg text-green-600"><Check size={16}/></div>
                            <span className="text-xs font-bold">Berkas Disetujui</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
}
