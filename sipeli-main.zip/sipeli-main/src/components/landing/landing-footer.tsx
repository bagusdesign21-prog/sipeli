
export function LandingFooter() {
    return (
        <footer className="bg-white border-t border-slate-200 py-12">
            <div className="container mx-auto px-4 text-center">
                <div className="mb-6 flex justify-center items-center gap-2">
                    <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white font-bold font-ui">SP</div>
                    <span className="font-bold text-slate-900 text-lg font-ui">SI-PELITA</span>
                </div>
                <p className="text-sm text-slate-500 mb-8 max-w-md mx-auto">
                    Sistem Informasi Pelayanan Publik & Terintegrasi Administrasi.
                    <br/>Kecamatan Tungkal Ilir, Kabupaten Banyuasin.
                </p>
                <div className="text-xs text-slate-400">
                    &copy; {new Date().getFullYear()} Pemerintah Kecamatan Tungkal Ilir. All rights reserved.
                </div>
            </div>
        </footer>
    );
}
