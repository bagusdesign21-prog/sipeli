
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Menu, Search, User, UserCheck, X, Loader2 } from 'lucide-react';
import { useUser, useFirestore } from '@/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { cn } from '@/lib/utils';
import { useRouter } from 'next/navigation';
import { TrackingModal, GuestbookModal } from '@/components/landing/modals';

export function LandingHeader() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const router = useRouter();
  
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const handleLoginClick = async () => {
    if (user) {
        if (firestore) {
            const userDocRef = doc(firestore, 'users', user.uid);
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
                const userData = userDoc.data();
                switch (userData.role) {
                    case 'admin':
                        router.push('/admin/dashboard');
                        break;
                    case 'perangkat':
                        router.push('/pegawai/dashboard');
                        break;
                    default:
                        router.push('/warga/dashboard');
                        break;
                }
            } else {
                // Default for users without a role document yet
                router.push('/warga/dashboard');
            }
        }
    } else {
      router.push('/login');
    }
  };

  const handleNavClick = (sectionId: string) => {
    setIsMenuOpen(false);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'beranda') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={cn(
          'fixed top-0 left-0 right-0 z-40 transition-all duration-300 font-ui',
          isScrolled || isMenuOpen ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'
        )}
      >
        <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
          <button onClick={() => handleNavClick('beranda')} className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-[#66CDAA] to-emerald-500 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-emerald-500/20">
              SP
            </div>
            <div>
              <h1
                className={cn(
                  'font-bold text-lg leading-none',
                  isScrolled || isMenuOpen ? 'text-slate-800' : 'text-slate-900'
                )}
              >
                SI-PELITA
              </h1>
              <p className="text-[10px] uppercase tracking-wider font-semibold opacity-60">
                Tungkal Ilir Connect
              </p>
            </div>
          </button>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-6 font-medium text-sm">
             <button onClick={() => handleNavClick('beranda')} className="hover:text-[#66CDAA] transition">Beranda</button>
             <button onClick={() => handleNavClick('layanan')} className="hover:text-[#66CDAA] transition">Layanan</button>
             <button onClick={() => handleNavClick('profil')} className="hover:text-[#66CDAA] transition">Pemerintahan</button>
             <Link href="/help" className="hover:text-[#66CDAA] transition">Bantuan</Link>
            <button onClick={() => setActiveModal('tracking')} className="hover:text-[#66CDAA] transition flex items-center gap-1">
              <Search size={16} /> Lacak Berkas
            </button>
            <button onClick={handleLoginClick} className="px-5 py-2.5 bg-slate-900 text-white rounded-full font-bold hover:bg-slate-800 transition flex items-center gap-2 shadow-lg">
                {isUserLoading ? <Loader2 size={16} className="animate-spin"/> : user ? <UserCheck size={16}/> : <User size={16}/>}
                {user ? 'Dashboard' : 'Masuk'}
            </button>
          </div>

          {/* Mobile Toggle */}
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden p-2 text-slate-700">
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

       {/* Mobile Menu */}
        {isMenuOpen && (
             <div className="fixed inset-0 bg-slate-900/50 z-30 md:hidden animate-in fade-in" onClick={() => setIsMenuOpen(false)}>
                <div className="fixed right-4 top-24 w-full max-w-sm bg-white rounded-2xl p-6 shadow-2xl animate-in slide-in-from-top-4 duration-300" onClick={(e) => e.stopPropagation()}>
                    <div className="flex flex-col gap-2">
                       <button onClick={()=> handleNavClick("beranda")} className="p-3 rounded-lg hover:bg-slate-100 font-bold text-left">Beranda</button>
                       <button onClick={()=> handleNavClick("layanan")} className="p-3 rounded-lg hover:bg-slate-100 font-bold text-left">Layanan</button>
                       <button onClick={()=> handleNavClick("profil")} className="p-3 rounded-lg hover:bg-slate-100 font-bold text-left">Pemerintahan</button>
                       <Link href="/help" onClick={() => setIsMenuOpen(false)} className="p-3 rounded-lg hover:bg-slate-100 font-bold">Bantuan</Link>
                       <button onClick={() => { setActiveModal('tracking'); setIsMenuOpen(false); }} className="p-3 rounded-lg hover:bg-slate-100 font-bold text-left">Lacak Berkas</button>
                       <button onClick={() => { handleLoginClick(); setIsMenuOpen(false); }} className="mt-4 w-full p-3 rounded-lg bg-slate-900 text-white font-bold">
                         {user ? 'Dashboard' : 'Masuk'}
                       </button>
                    </div>
                </div>
            </div>
        )}
        
        {/* Modals */}
        {activeModal === 'tracking' && <TrackingModal onClose={() => setActiveModal(null)} />}
        {activeModal === 'guestbook' && <GuestbookModal onClose={() => setActiveModal(null)} />}
    </>
  );
}
