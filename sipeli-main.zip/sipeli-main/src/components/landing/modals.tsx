
'use client';

import { useState } from 'react';
import { Search, X, BookOpen, Bot, Send, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { analyzeGuestbookSentimentAction } from '@/lib/actions';

type ModalProps = {
    onClose: () => void;
};

export function TrackingModal({ onClose }: ModalProps) {
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 relative">
                <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"><X size={20}/></button>
                <div className="text-center mb-6">
                    <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Search size={24}/>
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 font-ui">Lacak Berkas</h3>
                    <p className="text-sm text-slate-500">Masukkan Nomor Resi atau NIK Anda</p>
                </div>
                <input type="text" placeholder="Contoh: 140/025/KEC.TI/2025" className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-[#66CDAA] focus:ring-2 focus:ring-[#66CDAA]/20 outline-none mb-4 font-mono text-center"/>
                <button className="w-full py-3 rounded-lg bg-[#66CDAA] hover:bg-[#5bb899] text-white font-bold transition shadow-lg shadow-[#66CDAA]/20 font-ui">
                    Cek Status
                </button>
            </div>
        </div>
    );
}


export function GuestbookModal({ onClose }: ModalProps) {
    const [guestName, setGuestName] = useState('');
    const [guestMsg, setGuestMsg] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { toast } = useToast();

    const handleGuestSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!guestName.trim() || !guestMsg.trim() || guestMsg.trim().length < 10) {
            toast({
                variant: "destructive",
                title: "Data Tidak Lengkap",
                description: "Silakan isi nama dan pesan Anda (minimal 10 karakter).",
            });
            return;
        }
        setIsSubmitting(true);
        try {
            // In a real app, you would save this to a database (e.g., Firestore)
            // For now, we just call the analysis action
            await analyzeGuestbookSentimentAction({ text: guestMsg });
            
            toast({
                title: `Terima kasih Sdr/i ${guestName}`,
                description: "Data kunjungan dan masukan Anda telah tersimpan.",
            });
            setGuestName('');
            setGuestMsg('');
            onClose();
        } catch (error) {
            console.error("Error submitting guestbook:", error);
            toast({
                variant: "destructive",
                title: "Gagal Mengirim",
                description: "Terjadi kesalahan saat menyimpan data. Silakan coba lagi.",
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
                <div className="bg-[#FFDAB9] p-6 flex justify-between items-center border-b border-[#eecba8]">
                    <div className="flex items-center gap-3">
                        <div className="bg-white/50 p-2 rounded-lg text-slate-800"><BookOpen size={20}/></div>
                        <h3 className="font-bold text-lg text-slate-900 font-ui">Buku Tamu Digital</h3>
                    </div>
                    <button onClick={onClose} className="bg-white/50 p-1 rounded-full hover:bg-white text-slate-700 transition"><X size={20}/></button>
                </div>
                <form onSubmit={handleGuestSubmit} className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-bold text-slate-700 mb-1 font-ui">Nama Lengkap</label>
                        <input 
                            required
                            type="text" 
                            value={guestName}
                            onChange={(e) => setGuestName(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#66CDAA] outline-none transition"
                            placeholder="Contoh: Budi Santoso"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-slate-700 mb-1 font-ui">Pesan / Keperluan (SKM)</label>
                        <textarea 
                            required
                            value={guestMsg}
                            onChange={(e) => setGuestMsg(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-[#66CDAA] outline-none transition h-24 resize-none"
                            placeholder="Tuliskan keperluan atau masukan Anda..."
                        ></textarea>
                        <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1"><Bot size={12}/> Powered by AI Sentiment Analysis</p>
                    </div>
                    <button 
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-[#66CDAA] text-white py-3 rounded-lg font-bold hover:bg-[#5bb899] transition flex justify-center items-center gap-2 shadow-lg font-ui disabled:opacity-50"
                    >
                        {isSubmitting ? (
                            <><Loader2 size={18} className="animate-spin"/> Mengirim Data...</>
                        ) : (
                            <><Send size={18}/> Kirim Data</>
                        )}
                    </button>
                </form>
            </div>
        </div>
    );
}
