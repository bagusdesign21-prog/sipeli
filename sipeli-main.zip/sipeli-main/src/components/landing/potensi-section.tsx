

const POTENSI = [
    { title: "Agro Industri", desc: "Pusat perkebunan sawit & karet produktif seluas ribuan hektar di Bentayan dan Keluang.", icon: "🌴" },
    { title: "Ketahanan Pangan", desc: "Lumbung padi dan jagung yang menopang kebutuhan daerah, didukung irigasi teknis.", icon: "🌾" },
    { title: "Peternakan Modern", desc: "Sentra sapi potong dengan populasi >1.500 ekor dan program inseminasi buatan.", icon: "🐄" }
];

export function PotensiSection() {
    return (
        <section id="potensi" className="py-20 bg-slate-900 text-white relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-10">
                <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-600 rounded-full blur-[120px]"></div>
                <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-green-600 rounded-full blur-[120px]"></div>
            </div>
            <div className="container mx-auto max-w-6xl relative z-10 px-4">
                <div className="text-center mb-16">
                    <h2 className="text-sm font-bold text-yellow-400 uppercase tracking-widest mb-2 font-ui">Kekayaan Daerah</h2>
                    <h3 className="text-3xl md:text-4xl font-bold font-ui">Potensi Unggulan</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {POTENSI.map((item, idx) => (
                        <div key={idx} className="bg-slate-800/50 backdrop-blur border border-slate-700 p-8 rounded-3xl hover:bg-slate-800 transition duration-300 group hover:-translate-y-2">
                            <div className="text-5xl mb-6 group-hover:scale-110 transition duration-300 transform inline-block">{item.icon}</div>
                            <h4 className="text-xl font-bold mb-3 font-ui">{item.title}</h4>
                            <p className="text-slate-400 leading-relaxed">
                                {item.desc}
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
