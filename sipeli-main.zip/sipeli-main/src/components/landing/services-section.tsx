
'use client'

import { cn } from "@/lib/utils";
import { IdCard, Store, HeartHandshake, MessageSquareWarning, Map, BookOpen } from "lucide-react";
import { useRouter } from "next/navigation";

const SERVICES = [
    { title: "Administrasi Kependudukan", desc: "Layanan KK, KTP, dan Surat Pindah secara online.", icon: <IdCard size={24}/>, color: "bg-blue-500", action: "link", href: "/pegawai/forms" },
    { title: "Perizinan Usaha Desa", desc: "Pengajuan IUMK untuk UMKM mikro di desa.", icon: <Store size={24}/>, color: "bg-orange-500", action: "link", href: "/pegawai/forms" },
    { title: "Layanan Sosial", desc: "Cek DTKS, KIS, dan pengajuan bantuan sosial.", icon: <HeartHandshake size={24}/>, color: "bg-red-500", action: "link", href: "/pegawai/forms" },
    { title: "Pengaduan Masyarakat", desc: "Saluran aspirasi dan laporan warga langsung ke Camat.", icon: <MessageSquareWarning size={24}/>, color: "bg-purple-500", action: "link", href: "/pengaduan" },
    { title: "Info & Profil Desa", desc: "Data statistik dan potensi 14 desa di Tungkal Ilir.", icon: <Map size={24}/>, color: "bg-emerald-500", action: "link", href: "/profil-kecamatan" },
    { title: "Buku Tamu Digital", desc: "Catat kunjungan dinas atau umum secara elektronik.", icon: <BookOpen size={24}/>, color: "bg-indigo-500", action: "link", href: "/pegawai/guestbook" }
];

type ServicesSectionProps = {
};

export function ServicesSection({ }: ServicesSectionProps) {
    const router = useRouter();

    const handleClick = (service: typeof SERVICES[0]) => {
        if (service.href) {
            router.push(service.href);
        }
    }

    return (
        <section id="layanan" className="py-20 bg-[#F0FDF9] relative">
            <div className="container mx-auto px-4 md:px-6 relative z-10">
                <div className="text-center max-w-2xl mx-auto mb-16">
                    <h2 className="text-3xl font-bold text-slate-900 mb-4 font-ui">Layanan Mandiri</h2>
                    <p className="text-slate-600">
                        Tidak perlu antre di kantor camat. Gunakan fitur layanan mandiri untuk keperluan administrasi Anda. 
                    </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {SERVICES.map((item, idx) => (
                        <div 
                            key={idx} 
                            onClick={() => handleClick(item)}
                            className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-lg hover:-translate-y-1 transition duration-300 group cursor-pointer"
                        >
                            <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center text-white mb-6 shadow-md group-hover:scale-110 transition", item.color)}>
                                {item.icon}
                            </div>
                            <h3 className="font-bold text-lg text-slate-800 mb-2 font-ui">{item.title}</h3>
                            <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
