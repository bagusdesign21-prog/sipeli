
'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, where, orderBy } from 'firebase/firestore';
import type { Pejabat } from '@/lib/types';
import { Loader2 } from 'lucide-react';


const TABS = [
    {id: 'pimpinan', label: 'Pimpinan'},
    {id: 'struktur', label: 'Struktur Organisasi'},
    {id: 'demografi', label: 'Demografi'},
];

const PimpinanTab = ({ pejabat, isLoading }: { pejabat?: Pejabat[] | null, isLoading: boolean }) => {
    const pimpinan = pejabat?.find(p => p.jabatan.toLowerCase() === 'camat tungkal ilir');

    if (isLoading) {
        return <div className="flex justify-center items-center min-h-[300px]"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground"/></div>;
    }

    if (!pimpinan) {
        return <div className="text-center text-muted-foreground">Data pimpinan tidak ditemukan.</div>;
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center animate-in fade-in">
            <div className="order-2 md:order-1">
                <div className="inline-block px-3 py-1 bg-yellow-100 text-yellow-700 rounded-lg text-xs font-bold mb-4">
                    CAMAT TUNGKAL ILIR
                </div>
                <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">{pimpinan.nama}</h3>
                <p className="text-slate-400 text-sm font-mono mb-6">NIP. {pimpinan.nip}</p>
                
                <div className="space-y-4">
                    <blockquote className="border-l-4 border-yellow-500 pl-4 italic text-slate-600">
                        "Terwujudnya Penyelenggaraan Pemerintahan, Pembangunan dan Pembinaan Masyarakat yang Berkualitas menuju Banyuasin Bangkit, Adil dan Sejahtera."
                    </blockquote>
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <h4 className="font-bold text-sm mb-2 text-slate-800">Motto Pelayanan (PRIMA):</h4>
                        <div className="flex flex-wrap gap-2">
                            {['Profesional', 'Ramah', 'Inovatif', 'Mudah', 'Akuntabel'].map((m, i) => (
                                <span key={i} className="text-xs bg-white border border-slate-200 px-2 py-1 rounded text-slate-600">{m}</span>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            <div className="order-1 md:order-2 flex justify-center">
                <div className="relative w-64 h-80 md:w-80 md:h-96 rounded-2xl overflow-hidden shadow-2xl border-4 border-white transform rotate-2 hover:rotate-0 transition duration-500 bg-slate-200 group">
                    <Image 
                        src="https://images.unsplash.com/photo-1556157382-97eda2d62296?q=80&w=2070&auto=format&fit=crop" 
                        alt="Camat Tungkal Ilir" 
                        fill
                        className="group-hover:scale-105 transition duration-700 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 text-white">
                        <p className="font-bold text-lg">Pemimpin Visioner</p>
                        <p className="text-xs opacity-80">Membangun Tungkal Ilir</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

const StrukturTab = ({ pejabat, isLoading }: { pejabat?: Pejabat[] | null, isLoading: boolean }) => {

    if (isLoading) {
        return <div className="flex justify-center items-center min-h-[300px]"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground"/></div>;
    }

    return (
        <div className="animate-in fade-in">
            <div className="text-center mb-8">
                <h3 className="text-xl font-bold">Pejabat Struktural</h3>
                <p className="text-sm text-slate-500">Pemerintah Kecamatan Tungkal Ilir Tahun 2025</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {pejabat && pejabat.map((p) => (
                    <div key={p.id} className="flex items-start gap-4 p-4 rounded-xl border border-slate-100 hover:border-blue-200 hover:shadow-md transition bg-slate-50/50">
                        <div className={`w-10 h-10 rounded-full ${p.color || 'bg-slate-200'} flex items-center justify-center font-bold ${p.textColor || 'text-slate-600'} text-xs flex-shrink-0`}>
                            {p.nama.charAt(0)}
                        </div>
                        <div>
                            <div className="font-bold text-slate-800 text-sm line-clamp-1" title={p.nama}>{p.nama}</div>
                            <div className={`text-xs ${p.textColor || 'text-blue-600'} font-bold mt-0.5 line-clamp-1`}>{p.jabatan}</div>
                            <div className="text-[10px] text-slate-400 mt-1 font-mono">NIP. {p.nip}</div>
                        </div>
                    </div>
                ))}
            </div>
            <div className="mt-8 text-center">
                <Link href="/profil-kecamatan">
                    <Button variant="link" className="text-blue-600 text-sm font-bold">
                        Lihat Bagan Struktur Lengkap
                    </Button>
                </Link>
            </div>
        </div>
    );
};

const DemografiTab = () => (
    <div className="animate-in fade-in">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <Card className="p-6 bg-blue-50 border-blue-100">
                <CardContent className="p-0">
                    <div className="text-blue-600 font-bold mb-2">Total Penduduk</div>
                    <div className="text-4xl font-extrabold text-slate-900">32.865</div>
                    <div className="text-xs text-slate-500 mt-2">Jiwa (Tahun 2025)</div>
                </CardContent>
            </Card>
            <Card className="p-6 bg-pink-50 border-pink-100">
                <CardContent className="p-0">
                    <div className="text-pink-600 font-bold mb-2">Laki-Laki</div>
                    <div className="text-4xl font-extrabold text-slate-900">17.205</div>
                    <div className="text-xs text-slate-500 mt-2">52.3%</div>
                </CardContent>
            </Card>
            <Card className="p-6 bg-purple-50 border-purple-100">
                <CardContent className="p-0">
                    <div className="text-purple-600 font-bold mb-2">Perempuan</div>
                    <div className="text-4xl font-extrabold text-slate-900">15.666</div>
                    <div className="text-xs text-slate-500 mt-2">47.7%</div>
                </CardContent>
            </Card>
        </div>
        
        <div className="mt-8 p-6 bg-slate-900 text-white rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
                <h4 className="font-bold text-lg">Kepadatan Penduduk</h4>
                <p className="text-slate-400 text-sm">Rata-rata kepadatan penduduk per Km²</p>
            </div>
            <div className="text-right">
                <div className="text-3xl font-bold text-yellow-400">79 <span className="text-base font-normal text-white">Jiwa/Km²</span></div>
                <div className="text-xs text-slate-400 mt-1">Wilayah Luas, Potensi Besar</div>
            </div>
        </div>
    </div>
);


export function StrukturSection() {
    const [activeProfileTab, setActiveProfileTab] = useState('pimpinan');
    const firestore = useFirestore();

    const pejabatCollection = useMemoFirebase(() =>
        firestore ? collection(firestore, 'pejabat') : null
    , [firestore]);
    const { data: pejabat, isLoading: pejabatLoading } = useCollection<Pejabat>(pejabatCollection);

    return (
        <section id="profil" className="py-20 px-4 md:px-6 bg-slate-50">
            <div className="container mx-auto max-w-6xl">
                <div className="text-center mb-10">
                    <h2 className="text-3xl font-bold text-slate-900">Profil Kecamatan</h2>
                    <p className="text-slate-500 mt-2">Mengenal lebih dekat Pemerintah Kecamatan Tungkal Ilir.</p>
                </div>

                <div className="flex justify-center mb-8">
                    <div className="bg-white p-1.5 rounded-full shadow-sm border border-slate-200 inline-flex flex-wrap justify-center gap-1">
                        {TABS.map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveProfileTab(tab.id)}
                                className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all ${
                                    activeProfileTab === tab.id 
                                    ? 'bg-slate-900 text-white shadow-md' 
                                    : 'text-slate-500 hover:bg-slate-100'
                                }`}
                            >
                                {tab.label}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="bg-white rounded-3xl p-6 md:p-10 shadow-xl border border-slate-100 min-h-[400px]">
                    {activeProfileTab === 'pimpinan' && <PimpinanTab pejabat={pejabat} isLoading={pejabatLoading} />}
                    {activeProfileTab === 'struktur' && <StrukturTab pejabat={pejabat} isLoading={pejabatLoading}/>}
                    {activeProfileTab === 'demografi' && <DemografiTab />}
                </div>
            </div>
        </section>
    );
}
