
'use client';

import { cn } from '@/lib/utils';

type CategoryFilterProps = {
    categories: string[];
    activeCategory: string;
    setActiveCategory: (category: string) => void;
};

export function CategoryFilter({ categories, activeCategory, setActiveCategory }: CategoryFilterProps) {
    return (
        <div className="w-full overflow-x-auto pb-4 mb-8">
            <div className="flex gap-2 w-max">
                {categories.map(cat => (
                    <button 
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={cn('px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap border transition-all duration-200', 
                            activeCategory === cat 
                                ? 'bg-slate-900 text-white border-slate-900 shadow-md' 
                                : 'bg-white text-slate-600 border-slate-200 hover:border-accent hover:text-accent'
                        )}
                    >
                        {cat}
                    </button>
                ))}
            </div>
        </div>
    );
}
