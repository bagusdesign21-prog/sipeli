
import { Calendar, ArrowRight } from 'lucide-react';
import type { NewsArticle } from '@/lib/data-pengumuman';
import Link from 'next/link';

type FeaturedNewsProps = {
    news: NewsArticle;
};

export function FeaturedNews({ news }: FeaturedNewsProps) {
    return (
        <Link href={`/pengumuman/${news.id}`} className="group relative block rounded-2xl md:rounded-3xl overflow-hidden shadow-xl aspect-video md:aspect-[21/9]">
            <img src={news.image} alt={news.title} className="w-full h-full object-cover transform group-hover:scale-105 transition duration-700"/>
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent"></div>
            <div className="absolute bottom-0 left-0 p-4 md:p-10 w-full md:w-2/3 lg:w-1/2">
                <div className="flex items-center gap-3 mb-3">
                    <span className="bg-accent text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-sm">
                        {news.category}
                    </span>
                    <span className="text-slate-300 text-xs flex items-center gap-1">
                        <Calendar size={12}/> {news.date}
                    </span>
                </div>
                <h1 className="text-xl md:text-4xl font-headline font-bold text-white mb-3 leading-tight group-hover:text-primary transition">
                    {news.title}
                </h1>
                <p className="text-slate-200 text-sm line-clamp-2 mb-6 hidden md:block">
                    {news.excerpt}
                </p>
                <div className="inline-flex px-5 py-2 md:px-6 md:py-2.5 bg-white/20 backdrop-blur-md border border-white/30 text-white rounded-lg font-bold text-xs md:text-sm group-hover:bg-white group-hover:text-slate-900 transition items-center gap-2">
                    Baca Selengkapnya <ArrowRight size={16}/>
                </div>
            </div>
        </Link>
    );
}
