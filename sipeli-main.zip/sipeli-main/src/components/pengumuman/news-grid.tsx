
import { Calendar, User, ArrowRight, FileSearch } from 'lucide-react';
import type { NewsArticle } from '@/lib/data-pengumuman';
import Link from 'next/link';

type NewsGridProps = {
    newsItems: NewsArticle[];
    activeCategory: string;
    searchQuery: string;
};

export function NewsGrid({ newsItems, activeCategory, searchQuery }: NewsGridProps) {
    const featuredNewsId = newsItems.find(n => n.featured)?.id;
    
    // Filter out the featured article only when viewing 'All' categories and not searching
    const displayItems = (activeCategory === "Semua" && !searchQuery) 
        ? newsItems.filter(news => news.id !== featuredNewsId)
        : newsItems;

    return (
        <>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8">
                {displayItems.length > 0 ? (
                    displayItems.map((news) => (
                        <div key={news.id} className="group bg-white rounded-2xl border border-slate-100 overflow-hidden hover:shadow-lg transition duration-300 flex flex-col">
                           <Link href={`/pengumuman/${news.id}`} className="block">
                                <div className="relative aspect-video overflow-hidden">
                                    <img src={news.image} alt={news.title} className="w-full h-full object-cover transform group-hover:scale-105 transition duration-500"/>
                                    <div className="absolute top-3 left-3">
                                        <span className="bg-white/90 backdrop-blur text-slate-800 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shadow-sm">
                                            {news.category}
                                        </span>
                                    </div>
                                </div>
                            </Link>
                            <div className="p-5 md:p-6 flex-1 flex flex-col">
                                <div className="flex items-center gap-3 text-xs text-slate-400 mb-3">
                                    <span className="flex items-center gap-1"><Calendar size={12}/> {news.date}</span>
                                    <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                                    <span className="flex items-center gap-1"><User size={12}/> {news.author}</span>
                                </div>
                                 <Link href={`/pengumuman/${news.id}`} className="block">
                                    <h3 className="text-lg md:text-xl font-headline font-bold text-slate-800 mb-3 line-clamp-2 group-hover:text-accent transition">
                                        {news.title}
                                    </h3>
                                </Link>
                                <p className="text-sm text-slate-500 line-clamp-3 mb-6 flex-1 leading-relaxed">
                                    {news.excerpt}
                                </p>
                                <Link href={`/pengumuman/${news.id}`} className="text-sm font-bold text-accent hover:text-emerald-600 flex items-center gap-1 self-start group/btn">
                                    Baca Selengkapnya <ArrowRight size={16} className="transform group-hover/btn:translate-x-1 transition"/>
                                </Link>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="col-span-1 sm:col-span-2 py-12 text-center text-slate-400">
                        <div className="inline-block p-4 bg-slate-100 rounded-full mb-3"><FileSearch size={32}/></div>
                        <p>Tidak ada berita yang ditemukan.</p>
                    </div>
                )}
            </div>

             {displayItems.length > 0 && (
                <div className="mt-12 flex justify-center gap-2">
                    <button className="w-10 h-10 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center shadow-lg">1</button>
                    <button className="w-10 h-10 rounded-full bg-white border border-slate-200 text-slate-600 hover:border-accent hover:text-accent font-bold flex items-center justify-center transition">2</button>
                    <button className="w-10 h-10 rounded-full bg-white border border-slate-200 text-slate-600 hover:border-accent hover:text-accent font-bold flex items-center justify-center transition">
                        <ArrowRight size={16} />
                    </button>
                </div>
            )}
        </>
    );
}
