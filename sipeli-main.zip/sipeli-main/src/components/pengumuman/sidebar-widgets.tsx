
import { Pin, Download, BarChart2, Image as ImageIcon, Send, Bell } from 'lucide-react';

export function SidebarWidgets() {
    return (
        <div className="w-full space-y-8 sticky top-24">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-headline font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <Pin size={18} className="text-red-500 fill-red-500"/> Info Penting
                </h3>
                <div className="space-y-4">
                    <div className="p-4 bg-red-50 border border-red-100 rounded-xl">
                        <p className="text-xs font-bold text-red-600 mb-1 uppercase tracking-wide">Peringatan Dini</p>
                        <p className="text-sm font-bold text-slate-800 mb-2">Waspada Banjir Kiriman</p>
                        <p className="text-xs text-slate-500 leading-relaxed">
                            Debit air sungai di hulu meningkat. Warga di bantaran sungai dimohon siaga.
                        </p>
                    </div>
                    <div className="p-4 bg-muted border border-accent/20 rounded-xl">
                        <p className="text-xs font-bold text-emerald-700 mb-1 uppercase tracking-wide">Layanan Publik</p>
                        <p className="text-sm font-bold text-slate-800 mb-2">Perekaman E-KTP Keliling</p>
                        <p className="text-xs text-slate-500 leading-relaxed">
                            Jadwal: Senin, 15 Juli 2025 di Kantor Desa Suka Mulya. 08:00 - 14:00 WIB.
                        </p>
                    </div>
                </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-headline font-bold text-slate-800 mb-4">Akses Cepat</h3>
                <ul className="space-y-2">
                    <li>
                        <a href="#" className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 group transition">
                            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center group-hover:scale-110 transition"><Download size={16}/></div>
                            <span className="text-sm font-medium text-slate-600 group-hover:text-blue-600">Unduh Dokumen</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 group transition">
                            <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center group-hover:scale-110 transition"><BarChart2 size={16}/></div>
                            <span className="text-sm font-medium text-slate-600 group-hover:text-orange-600">Statistik Desa</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 group transition">
                            <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center group-hover:scale-110 transition"><ImageIcon size={16}/></div>
                            <span className="text-sm font-medium text-slate-600 group-hover:text-purple-600">Galeri Kegiatan</span>
                        </a>
                    </li>
                </ul>
            </div>
            
            <div className="bg-slate-900 p-6 rounded-2xl text-white relative overflow-hidden">
                <div className="relative z-10">
                    <h3 className="font-headline font-bold text-lg mb-2">Berlangganan Info</h3>
                    <p className="text-xs text-slate-400 mb-4">Dapatkan update berita kecamatan langsung ke WhatsApp Anda.</p>
                    <div className="flex gap-2">
                        <input type="text" placeholder="No. WhatsApp" className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-sm focus:outline-none focus:border-accent"/>
                        <button className="bg-accent hover:bg-emerald-600 text-white p-2 rounded-lg transition"><Send size={18}/></button>
                    </div>
                </div>
                <Bell size={100} className="absolute -bottom-4 -right-4 text-white/5 rotate-12"/>
            </div>
        </div>
    );
}
