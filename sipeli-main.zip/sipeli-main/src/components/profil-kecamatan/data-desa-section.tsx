
'use client';
import Link from "next/link";
import { Info, Loader2 } from "lucide-react";
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import type { Village } from '@/lib/types';


export function DataDesaSection() {
    const firestore = useFirestore();

    const villagesQuery = useMemoFirebase(() => 
        firestore ? query(collection(firestore, 'villages'), orderBy('id')) : null
    , [firestore]);

    const { data: villages, isLoading: villagesLoading } = useCollection<Village>(villagesQuery);

    const totalPenduduk = villages?.reduce((acc, v) => acc + parseInt(v.penduduk.replace(',', ''), 10), 0).toLocaleString('id-ID') || '32.865';

    return (
        <section>
            <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
                <div>
                    <h2 className="font-headline text-2xl font-bold text-slate-900 mb-2">Data Desa</h2>
                    <p className="text-slate-500">Daftar 14 Desa Definitif di Kecamatan Tungkal Ilir.</p>
                </div>
                <div className="bg-white border border-slate-200 rounded-lg px-4 py-2 flex items-center gap-2 text-sm text-slate-600 shadow-sm">
                    <Info size={16} className="text-accent"/>
                    <span>Total Penduduk: <strong>{totalPenduduk} Jiwa</strong></span>
                </div>
            </div>
            
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                            <tr>
                                <th className="px-6 py-4 w-16 text-center">No</th>
                                <th className="px-6 py-4">Nama Desa</th>
                                <th className="px-6 py-4">Kepala Desa</th>
                                <th className="px-6 py-4">Luas Wilayah</th>
                                <th className="px-6 py-4">Penduduk</th>
                                <th className="px-6 py-4 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {villagesLoading ? (
                                <tr>
                                    <td colSpan={6} className="text-center py-10">
                                        <div className="flex justify-center items-center gap-2 text-muted-foreground">
                                            <Loader2 className="w-5 h-5 animate-spin"/> Memuat data desa...
                                        </div>
                                    </td>
                                </tr>
                            ) : (
                                villages?.map((d) => (
                                    <tr key={d.id} className="hover:bg-slate-50 transition">
                                        <td className="px-6 py-4 text-center font-medium text-slate-400">{d.id}</td>
                                        <td className="px-6 py-4 font-bold text-slate-800">{d.name}</td>
                                        <td className="px-6 py-4 text-slate-600">{d.kades}</td>
                                        <td className="px-6 py-4 text-slate-500">{d.luas}</td>
                                        <td className="px-6 py-4 text-slate-500">{d.penduduk}</td>
                                        <td className="px-6 py-4 text-center">
                                            <Link href={`/profil-kecamatan/${d.id}`}>
                                                <span className="text-accent hover:text-emerald-600 font-medium text-xs border border-accent px-3 py-1 rounded-full hover:bg-accent/10 transition cursor-pointer">
                                                    Detail
                                                </span>
                                            </Link>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    )
}
