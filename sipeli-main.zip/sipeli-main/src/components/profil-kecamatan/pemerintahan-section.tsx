
'use client';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection } from 'firebase/firestore';
import type { Pejabat } from '@/lib/types';
import { Loader2 } from 'lucide-react';

export function PemerintahanSection() {
    const firestore = useFirestore();
    const pejabatCollection = useMemoFirebase(() => firestore ? collection(firestore, 'pejabat') : null, [firestore]);
    const { data: pejabat, isLoading: pejabatLoading } = useCollection<Pejabat>(pejabatCollection);
    
    return (
        <section className="bg-slate-50 p-8 md:p-12 rounded-3xl border border-slate-200">
            <div className="text-center mb-12">
                <h2 className="font-headline text-2xl font-bold text-slate-800 mb-2">Pemerintahan Kecamatan</h2>
                <p className="text-slate-500">Pejabat Struktural Kecamatan Tungkal Ilir.</p>
            </div>
             {pejabatLoading ? (
                <div className="flex justify-center items-center h-48">
                    <Loader2 className="w-8 h-8 animate-spin text-muted-foreground"/>
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {pejabat && pejabat.slice(0, 7).map((p) => (
                        <div key={p.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md transition group flex items-center gap-5">
                            <div className={`w-16 h-16 rounded-full flex items-center justify-center font-bold text-xl flex-shrink-0 shadow-inner ${p.color} ${p.textColor} overflow-hidden`}>
                                {p.nama.charAt(0)}
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="font-bold text-slate-800 text-sm md:text-base truncate" title={p.nama}>{p.nama}</h3>
                                <p className={`text-xs font-bold mt-1 mb-1 truncate ${p.textColor}`}>{p.jabatan}</p>
                                <p className="text-[10px] text-slate-400 font-mono truncate">NIP. {p.nip}</p>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </section>
    )
}
