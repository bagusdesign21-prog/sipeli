
import Link from 'next/link';
import { Globe, Mail, MapPin } from "lucide-react";

const CONTACT = {
    alamat: "Jln. Jendral Sudirman - Lintas Bertak I, Desa Sidomulyo, Kode Pos 30781",
    email: "tungkalilir@banyuasinkab.go.id",
    web: "kec-tungkalilir.banyuasinkab.go.id"
};

export function ProfileFooter() {
    return (
        <footer className="bg-slate-900 text-white py-16 mt-auto">
            <div className="container mx-auto px-4 md:px-6">
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
                    <div>
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center text-white font-bold text-xl">TI</div>
                            <div>
                                <h3 className="font-headline font-bold text-lg leading-none">Tungkal Ilir</h3>
                                <p className="text-xs text-slate-400 mt-1">Kabupaten Banyuasin</p>
                            </div>
                        </div>
                        <p className="text-slate-400 text-sm leading-relaxed">
                            Portal informasi resmi Pemerintah Kecamatan Tungkal Ilir. 
                            Mewujudkan pelayanan publik yang prima dan transparan.
                        </p>
                    </div>
                    
                    <div>
                        <h4 className="font-bold text-lg mb-6 text-primary">Kontak Kami</h4>
                        <ul className="space-y-4 text-sm text-slate-300">
                            <li className="flex items-start gap-3">
                                <MapPin size={18} className="mt-0.5 text-accent flex-shrink-0"/>
                                <span>{CONTACT.alamat}</span>
                            </li>
                            <li className="flex items-center gap-3">
                                <Mail size={18} className="text-accent flex-shrink-0"/>
                                <span>{CONTACT.email}</span>
                            </li>
                            <li className="flex items-center gap-3">
                                <Globe size={18} className="text-accent flex-shrink-0"/>
                                <span>{CONTACT.web}</span>
                            </li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="font-bold text-lg mb-6 text-primary">Tautan Cepat</h4>
                        <ul className="space-y-3 text-sm text-slate-300">
                            <li><Link href="/profil-kecamatan" className="hover:text-accent transition">Profil Pemerintah</Link></li>
                            <li><Link href="/#layanan" className="hover:text-accent transition">Layanan Publik</Link></li>
                            <li><Link href="/#pengumuman" className="hover:text-accent transition">Berita & Pengumuman</Link></li>
                            <li><Link href="/#potensi" className="hover:text-accent transition">Potensi Wilayah</Link></li>
                            <li><Link href="/#layanan" className="hover:text-accent transition">Pengaduan Masyarakat</Link></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="font-bold text-lg mb-6 text-primary">Jam Pelayanan</h4>
                        <ul className="space-y-3 text-sm text-slate-300">
                            <li className="flex justify-between">
                                <span>Senin - Kamis</span>
                                <span className="font-bold">08:00 - 16:00</span>
                            </li>
                            <li className="flex justify-between">
                                <span>Jumat</span>
                                <span className="font-bold">08:00 - 16:30</span>
                            </li>
                            <li className="flex justify-between text-slate-500">
                                <span>Sabtu - Minggu</span>
                                <span>Tutup</span>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <div className="border-t border-slate-800 mt-12 pt-8 text-center text-sm text-slate-500">
                    &copy; {new Date().getFullYear()} Pemerintah Kecamatan Tungkal Ilir. All rights reserved.
                </div>
            </div>
        </footer>
    )
}
