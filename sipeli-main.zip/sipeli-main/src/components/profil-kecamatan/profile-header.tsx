
import { MapPin, Users } from "lucide-react";

export function ProfileHeader() {
  return (
    <header className="pt-24 pb-16 bg-muted/40 relative overflow-hidden">
        <div className="absolute inset-0 pattern-grid" style={{ backgroundImage: 'radial-gradient(hsl(var(--accent)) 1px, transparent 1px)', backgroundSize: '24px 24px', opacity: 0.1 }}></div>
        <div className="container mx-auto px-4 text-center relative z-10">
            <div className="inline-block p-3 rounded-2xl bg-white shadow-sm mb-6">
                <img src="https://upload.wikimedia.org/wikipedia/commons/e/ee/Logo_Kabupaten_Banyuasin.png" alt="Logo Banyuasin" className="h-20 w-auto mx-auto"/>
            </div>
            <h1 className="font-headline text-3xl md:text-5xl font-bold text-slate-900 mb-4">Kecamatan Tungkal Ilir</h1>
            <p className="font-body text-lg text-slate-600 italic max-w-2xl mx-auto">
                "Banyuasin Bangkit, Adil, dan Sejahtera"
            </p>
            <div className="mt-8 flex justify-center gap-4 text-sm font-medium text-slate-500">
                <div className="flex items-center gap-1.5 px-4 py-2 bg-white rounded-full shadow-sm border border-slate-100">
                    <MapPin size={16} className="text-accent"/> Desa Sidomulyo
                </div>
                <div className="flex items-center gap-1.5 px-4 py-2 bg-white rounded-full shadow-sm border border-slate-100">
                    <Users size={16} className="text-accent"/> 32.8 Ribu Jiwa
                </div>
            </div>
        </div>
    </header>
  );
}
