
const VISI_MISI = {
    visi: "Terwujudnya Kecamatan Tungkal Ilir yang Maju, Berdaya Saing, dan Sejahtera menuju Banyuasin Bangkit, Adil, dan Sejahtera.",
    misi: [
        "Meningkatkan kualitas pelayanan publik yang profesional, ramah, dan akuntabel (PRIMA).",
        "Meningkatkan pembangunan infrastruktur dasar yang merata dan berkeadilan di seluruh desa.",
        "Mengoptimalkan potensi sumber daya alam (SDA) sektor pertanian dan perkebunan untuk kesejahteraan masyarakat.",
        "Mewujudkan tata kelola pemerintahan desa yang transparan, partisipatif, dan bebas korupsi.",
        "Meningkatkan kualitas sumber daya manusia melalui pendidikan dan kesehatan yang terjangkau."
    ]
};

export function VisiMisiSection() {
    return (
        <section className="grid md:grid-cols-2 gap-12 items-start">
            <div>
                <h2 className="font-headline text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                    <div className="w-10 h-1 bg-accent"></div> Visi & Misi
                </h2>
                <div className="bg-[#F0FDF9] border border-accent/20 rounded-2xl p-8 mb-8">
                    <h3 className="font-headline font-bold text-lg text-[#0f766e] mb-3">Visi</h3>
                    <p className="text-slate-700 leading-relaxed font-body italic text-lg">"{VISI_MISI.visi}"</p>
                </div>
                <div>
                    <h3 className="font-headline font-bold text-lg text-slate-800 mb-4">Misi Pembangunan</h3>
                    <ul className="space-y-4">
                        {VISI_MISI.misi.map((m, i) => (
                            <li key={i} className="flex gap-4">
                                <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">{i+1}</div>
                                <p className="text-slate-600 leading-relaxed">{m}</p>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
            <div className="space-y-8">
                <div className="bg-white rounded-2xl shadow-lg border border-slate-100 p-8">
                    <h2 className="font-headline text-xl font-bold text-slate-900 mb-4">Geografis</h2>
                    <p className="text-slate-600 leading-relaxed mb-6">
                        Kecamatan Tungkal Ilir merupakan salah satu dari 21 kecamatan di Kabupaten Banyuasin. 
                        Secara geografis, wilayah ini didominasi oleh dataran rendah yang subur, menjadikannya potensial untuk sektor perkebunan dan pertanian.
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-slate-50 rounded-xl">
                            <p className="text-xs text-slate-400 uppercase tracking-wider font-bold">Luas Wilayah</p>
                            <p className="text-xl font-bold text-slate-800">412 km²</p>
                        </div>
                        <div className="p-4 bg-slate-50 rounded-xl">
                            <p className="text-xs text-slate-400 uppercase tracking-wider font-bold">Ibu Kota</p>
                            <p className="text-xl font-bold text-slate-800">Sidomulyo</p>
                        </div>
                    </div>
                </div>
                <div className="bg-slate-900 text-white rounded-2xl shadow-lg p-8 relative overflow-hidden">
                    <div className="relative z-10">
                        <h2 className="font-headline text-xl font-bold mb-2">Motto Pelayanan</h2>
                        <div className="text-4xl font-extrabold text-primary tracking-widest mb-2">P.R.I.M.A</div>
                        <p className="text-slate-300 text-sm">Profesional • Ramah • Inovatif • Mudah • Akuntabel</p>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="150" height="150" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="absolute -bottom-10 -right-10 text-white/5"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path></svg>
                </div>
            </div>
        </section>
    )
}
