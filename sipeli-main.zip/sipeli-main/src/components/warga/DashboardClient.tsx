'use client';

import {
  Clock,
  FileCheck,
  FileText,
  CheckCircle,
  HeartHandshake,
  MessageSquareWarning,
  Store,
  AlertTriangle,
  Bell,
  User as UserIcon,
  Loader2,
} from 'lucide-react';
import { useUser } from '@/firebase';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';

const RECENT_ACTIVITIES = [
  {
    id: 1,
    type: 'Surat',
    title: 'Surat Keterangan Usaha',
    status: 'Selesai',
    date: '12 Juli 2025',
    icon: FileCheck,
    color: 'bg-green-100 text-green-600',
  },
  {
    id: 2,
    type: 'Surat',
    title: 'Pengantar KTP-El',
    status: 'Diproses',
    date: '14 Juli 2025',
    icon: Clock,
    color: 'bg-orange-100 text-orange-600',
  },
  {
    id: 3,
    type: 'Laporan',
    title: 'Jalan Rusak Dusun 2',
    status: 'Diterima',
    date: '10 Juli 2025',
    icon: AlertTriangle,
    color: 'bg-blue-100 text-blue-600',
  },
];

const NOTIFICATIONS = [
  {
    id: 1,
    title: 'Undangan Musdes',
    msg: 'Dimohon kehadiran Bapak/Ibu pada Musyawarah Desa, Senin 20 Juli.',
    read: false,
  },
  {
    id: 2,
    title: 'Berkas Disetujui',
    msg: 'Surat Keterangan Usaha Anda telah selesai ditandatangani.',
    read: true,
  },
];

const StatCard = ({ label, value, icon: Icon, color }: any) => (
  <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4">
    <div
      className={`w-12 h-12 rounded-lg flex items-center justify-center ${color}`}
    >
      <Icon size={24} />
    </div>
    <div>
      <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">
        {label}
      </p>
      <h4 className="text-xl font-bold text-slate-800">{value}</h4>
    </div>
  </div>
);

const ServiceButton = ({ label, icon: Icon, color }: any) => (
  <button className="flex flex-col items-center gap-2 p-4 bg-white rounded-xl shadow-sm border border-slate-100 hover:shadow-md hover:border-accent transition group w-full h-full">
    <div
      className={`w-12 h-12 rounded-full flex items-center justify-center text-white transition transform group-hover:scale-110 ${color}`}
    >
      <Icon size={24} />
    </div>
    <span className="text-xs font-bold text-slate-600 text-center group-hover:text-accent">
      {label}
    </span>
  </button>
);

export function DashboardClient() {
  const { user, isUserLoading } = useUser();
  const avatar = PlaceHolderImages.find((img) => img.id === 'user-avatar');

  // MOCK USER DATA
  const USER_DATA = {
    name: user?.displayName || user?.email?.split('@')[0] || 'Warga',
    nik: '1607123456780001',
    desa: 'Sidomulyo',
    photo: user?.photoURL || avatar?.imageUrl,
  };
  
  if (isUserLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <>
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-headline font-bold text-slate-800">
          Halo, {USER_DATA.name}! 👋
        </h1>
        <p className="text-slate-500">
          Selamat datang di dashboard pelayanan warga.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <StatCard
          label="Layanan Aktif"
          value="1"
          icon={Clock}
          color="bg-orange-100 text-orange-600"
        />
        <StatCard
          label="Selesai"
          value="12"
          icon={CheckCircle}
          color="bg-green-100 text-green-600"
        />
        <StatCard
          label="Total Pengajuan"
          value="13"
          icon={FileText}
          color="bg-blue-100 text-blue-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="font-headline font-bold text-slate-800 mb-4">
              Layanan Cepat
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <ServiceButton
                label="Surat Pengantar"
                icon={FileText}
                color="bg-blue-500"
              />
              <ServiceButton
                label="SK Usaha"
                icon={Store}
                color="bg-orange-500"
              />
              <ServiceButton
                label="Lapor / Aduan"
                icon={MessageSquareWarning}
                color="bg-red-500"
              />
              <ServiceButton
                label="Cek Bantuan"
                icon={HeartHandshake}
                color="bg-emerald-500"
              />
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-headline font-bold text-slate-800">
                Aktivitas Terakhir
              </h3>
              <button className="text-sm font-bold text-accent hover:underline">
                Lihat Semua
              </button>
            </div>
            <div className="divide-y divide-slate-100">
              {RECENT_ACTIVITIES.map((act) => (
                <div
                  key={act.id}
                  className="p-4 hover:bg-slate-50 transition flex items-center gap-4"
                >
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${act.color}`}
                  >
                    <act.icon size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-800 truncate">
                      {act.title}
                    </p>
                    <p className="text-xs text-slate-500">
                      {act.type} • {act.date}
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                      act.status === 'Selesai'
                        ? 'bg-green-100 text-green-700'
                        : act.status === 'Diproses'
                        ? 'bg-orange-100 text-orange-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}
                  >
                    {act.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-gradient-to-br from-accent to-emerald-600 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
            <div className="relative z-10 flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-white p-1 rounded-full mb-3 shadow-md">
                {USER_DATA.photo ? (
                  <Image
                    src={USER_DATA.photo}
                    alt="User photo"
                    width={80}
                    height={80}
                    className="rounded-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                    <UserIcon size={32} />
                  </div>
                )}
              </div>
              <h3 className="font-bold text-lg">{USER_DATA.name}</h3>
              <p className="text-sm opacity-90 mb-4">
                {USER_DATA.desa} • Warga
              </p>
              <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2 w-full text-xs font-mono">
                NIK: {USER_DATA.nik}
              </div>
            </div>
            <UserIcon
              size={150}
              className="absolute -bottom-10 -right-10 text-white/10"
            />
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="font-headline font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Bell size={18} className="text-accent" /> Notifikasi
            </h3>
            <div className="space-y-4">
              {NOTIFICATIONS.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-3 rounded-xl border ${
                    notif.read
                      ? 'bg-slate-50 border-slate-100 opacity-70'
                      : 'bg-white border-accent/30 shadow-sm'
                  }`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <span
                      className={`text-xs font-bold ${
                        notif.read ? 'text-slate-600' : 'text-accent'
                      }`}
                    >
                      {notif.title}
                    </span>
                    {!notif.read && (
                      <div className="w-2 h-2 rounded-full bg-red-500"></div>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {notif.msg}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
