'use client';

import { Menu } from 'lucide-react';

export function WargaHeader({ setIsSidebarOpen }: { setIsSidebarOpen: (isOpen: boolean) => void }) {
  return (
    <header className="md:hidden bg-white border-b border-slate-200 p-4 flex justify-between items-center sticky top-0 z-30">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center text-white font-bold">
          SP
        </div>
        <span className="font-bold text-slate-800">SI-PELITA</span>
      </div>
      <button
        onClick={() => setIsSidebarOpen(true)}
        className="p-2 text-slate-600 rounded-lg hover:bg-slate-100"
      >
        <Menu size={24} />
      </button>
    </header>
  );
}
