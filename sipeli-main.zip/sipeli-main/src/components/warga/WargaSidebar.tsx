'use client';

import {
  LayoutDashboard,
  History,
  Bell,
  User,
  LogOut,
  X,
  Loader2,
} from 'lucide-react';
import { useUser, useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';
import { useRouter, usePathname } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import React from 'react';
import Link from 'next/link';

const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, href: '/warga/dashboard' },
    { id: 'riwayat', label: 'Riwayat Layanan', icon: History, href: '/warga/riwayat' },
    { id: 'notifications', label: 'Notifikasi', icon: Bell, badge: 2, href: '#' },
];

const accountItems = [
    { id: 'profile', label: 'Profil Saya', icon: User, href: '#' },
];


export function WargaSidebar({ isSidebarOpen, setIsSidebarOpen }: { isSidebarOpen: boolean, setIsSidebarOpen: (isOpen: boolean) => void }) {
    const { user, isUserLoading } = useUser();
    const auth = useAuth();
    const router = useRouter();
    const pathname = usePathname();
    const { toast } = useToast();
    const avatar = PlaceHolderImages.find((img) => img.id === 'user-avatar');

    const handleLogout = async () => {
        try {
            await signOut(auth);
            toast({ title: 'Logout Berhasil', description: 'Anda telah berhasil keluar.' });
            router.push('/login');
        } catch (error) {
            toast({ variant: 'destructive', title: 'Logout Gagal', description: 'Gagal keluar, silakan coba lagi.' });
        }
    };
    
    const handleNavigation = (href: string) => {
        router.push(href);
        setIsSidebarOpen(false);
    };
    
    const USER_DATA = {
        name: user?.displayName || user?.email?.split('@')[0] || 'Warga',
        desa: 'Sidomulyo',
        photo: user?.photoURL || avatar?.imageUrl
    };


    const sidebarContent = (
         <div className="p-4 flex-1 overflow-y-auto">
            <div className="mb-6 px-2">
                <p className="text-xs font-bold text-slate-400 uppercase mb-3">Menu Utama</p>
                {menuItems.map(item => {
                    const isActive = pathname === item.href;
                    return (
                        <Link href={item.href} key={item.id} onClick={() => setIsSidebarOpen(false)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium mb-1 transition ${isActive ? 'bg-accent/10 text-accent' : 'text-slate-600 hover:bg-slate-50'}`}>
                            <item.icon size={18}/> {item.label}
                            {item.badge && <span className="bg-red-500 text-white text-[10px] px-1.5 rounded-full ml-auto">{item.badge}</span>}
                        </Link>
                    )
                })}
            </div>

            <div className="px-2">
                <p className="text-xs font-bold text-slate-400 uppercase mb-3">Akun</p>
                {accountItems.map(item => {
                    const isActive = pathname === item.href;
                    return (
                     <Link href={item.href} key={item.id} onClick={() => setIsSidebarOpen(false)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium mb-1 transition ${isActive ? 'bg-accent/10 text-accent' : 'text-slate-600 hover:bg-slate-50'}`}>
                        <item.icon size={18}/> {item.label}
                    </Link>
                )})}
                <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-500 hover:bg-red-50 transition">
                    <LogOut size={18}/> Keluar
                </button>
            </div>
        </div>
    );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 fixed h-full z-20">
        <div className="p-6 border-b border-slate-100 flex items-center gap-3">
          <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center text-white font-bold">
            SP
          </div>
          <span className="font-headline font-bold text-slate-800 text-lg">
            SI-PELITA
          </span>
        </div>

        {sidebarContent}

        <div className="p-4 border-t border-slate-100">
           {isUserLoading ? (
             <div className="flex items-center gap-3 animate-pulse">
                <div className="w-10 h-10 rounded-full bg-slate-200"></div>
                <div>
                  <div className="h-4 w-24 bg-slate-200 rounded"></div>
                  <div className="h-3 w-16 bg-slate-200 rounded mt-1"></div>
                </div>
             </div>
           ) : (
             <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 overflow-hidden">
                {USER_DATA.photo ? (
                    <Image src={USER_DATA.photo} width={40} height={40} alt="User Avatar" />
                ) : (
                    <User size={20} />
                )}
                </div>
                <div>
                <p className="text-sm font-bold text-slate-800 line-clamp-1">
                    {USER_DATA.name}
                </p>
                <p className="text-xs text-slate-500">{USER_DATA.desa}</p>
                </div>
            </div>
           )}
        </div>
      </aside>

      {/* Mobile Sidebar */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        >
          <div
            className="bg-white w-64 h-full shadow-xl flex flex-col animate-in slide-in-from-left-full duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <span className="font-bold text-slate-800 text-lg">Menu</span>
              <button onClick={() => setIsSidebarOpen(false)}>
                <X size={24} />
              </button>
            </div>
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}