export const firebaseConfig = {
  apiKey: "AIzaSyAq7oux5aAH8qQyxUt6gnYdAW_vSLS5lY0",
  authDomain: "studio-8079675825-104b0.firebaseapp.com",
  projectId: "studio-8079675825-104b0",
  storageBucket: "studio-8079675825-104b0.appspot.com",
  messagingSenderId: "642543018730",
  appId: "1:642543018730:web:8d449547bc2819fc906d93",
  measurementId: ""
};
