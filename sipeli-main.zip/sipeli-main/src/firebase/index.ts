'use client';

import { firebaseConfig } from '@/firebase/config';
import { initializeApp, getApps, getApp, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getStorage, type FirebaseStorage } from 'firebase/storage';

// --- Centralized Firebase Initialization ---

let firebaseApp: FirebaseApp;

// Check if Firebase has already been initialized
if (!getApps().length) {
  try {
    // Initialize with the explicit config object
    firebaseApp = initializeApp(firebaseConfig);
    console.log("🔥 Firebase initialized with config from src/firebase/config.ts");
  } catch (e) {
    console.error("❌ Firebase initialization failed:", e);
    // In a real-world app, you might want to show a global error UI here.
    // For now, we'll throw to make it obvious during development.
    throw new Error("Could not initialize Firebase. Please check your configuration.");
  }
} else {
  // If it's already initialized, get the existing app instance
  firebaseApp = getApp();
}

// Get the SDK instances
const auth = getAuth(firebaseApp);
const firestore = getFirestore(firebaseApp);
const storage = getStorage(firebaseApp);

/**
 * A central function to get all initialized Firebase SDKs.
 * This is now simplified as initialization happens once, above.
 */
export function initializeFirebase() {
  return {
    firebaseApp,
    auth,
    firestore,
    storage
  };
}

// --- Exports for hooks and providers ---

export * from './provider';
export * from './client-provider';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
export * from './non-blocking-updates';
export * from './non-blocking-login';
export * from './errors';
export * from './error-emitter';
