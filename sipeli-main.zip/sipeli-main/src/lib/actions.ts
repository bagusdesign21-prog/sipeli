"use server";

import { analyzeGuestbookSentiment } from "@/ai/flows/analyze-guestbook-sentiment";
import { generateNarrativeSections } from "@/ai/flows/generate-narrative-sections";
import { answerHelpQuestion } from "@/ai/flows/answer-help-question";
import { analyzeComplaintQuality } from "@/ai/flows/analyze-complaint-quality";
import { z } from "zod";

const generateNarrativeSchema = z.object({
  reportType: z.enum(["LPJ", "APBDes"]),
  dataAnalysis: z.string().min(50),
});

export async function generateNarrativeSectionsAction(input: z.infer<typeof generateNarrativeSchema>) {
  const validatedInput = generateNarrativeSchema.safeParse(input);

  if (!validatedInput.success) {
    throw new Error("Invalid input.");
  }

  return await generateNarrativeSections(validatedInput.data);
}


const analyzeSentimentSchema = z.object({
  text: z.string().min(10),
});

export async function analyzeGuestbookSentimentAction(input: z.infer<typeof analyzeSentimentSchema>) {
    const validatedInput = analyzeSentimentSchema.safeParse(input);

    if (!validatedInput.success) {
        throw new Error("Invalid input.");
    }
    
    return await analyzeGuestbookSentiment(validatedInput.data);
}

const answerHelpQuestionSchema = z.object({
  question: z.string().min(5),
});

export async function answerHelpQuestionAction(input: z.infer<typeof answerHelpQuestionSchema>) {
  const validatedInput = answerHelpQuestionSchema.safeParse(input);

  if (!validatedInput.success) {
    throw new Error("Invalid input.");
  }

  return await answerHelpQuestion(validatedInput.data);
}

const analyzeComplaintSchema = z.object({
  complaintText: z.string().min(10),
});

export async function analyzeComplaintAction(input: z.infer<typeof analyzeComplaintSchema>) {
    const validatedInput = analyzeComplaintSchema.safeParse(input);

    if (!validatedInput.success) {
        throw new Error("Invalid input.");
    }
    
    return await analyzeComplaintQuality(validatedInput.data);
}
