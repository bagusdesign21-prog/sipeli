
export type NewsArticle = {
    id: number;
    title: string;
    category: string;
    date: string;
    author: string;
    image: string;
    excerpt: string;
    featured: boolean;
};

export const NEWS_DATA: NewsArticle[] = [
    {
        id: 1,
        title: "Jadwal Musrenbangdes Tahun Anggaran 2025",
        category: "Pemerintahan",
        date: "12 Juli 2025",
        author: "Admin Kecamatan",
        image: "https://images.unsplash.com/photo-1577412647305-991150c7d163?q=80&w=2070&auto=format&fit=crop",
        excerpt: "Pemerintah Kecamatan Tungkal Ilir mengundang seluruh elemen masyarakat untuk hadir dalam Musyawarah Perencanaan Pembangunan Desa (Musrenbangdes) yang akan dilaksanakan serentak mulai minggu depan.",
        featured: true
    },
    {
        id: 2,
        title: "Penyaluran BLT Dana Desa Tahap II Berjalan Lancar",
        category: "Sosial",
        date: "10 Juli 2025",
        author: "Kasi PMD",
        image: "https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=2070&auto=format&fit=crop",
        excerpt: "Sebanyak 150 Keluarga Penerima Manfaat (KPM) di Desa Sidomulyo telah menerima Bantuan Langsung Tunai (BLT) Dana Desa tahap kedua hari ini.",
        featured: false
    },
    {
        id: 3,
        title: "Waspada Demam Berdarah, Dinkes Lakukan Fogging",
        category: "Kesehatan",
        date: "08 Juli 2025",
        author: "Puskesmas",
        image: "https://images.unsplash.com/photo-1584362917165-526a968579e8?q=80&w=2128&auto=format&fit=crop",
        excerpt: "Menanggapi laporan warga terkait peningkatan kasus DBD, tim Puskesmas melakukan fogging di wilayah Desa Keluang dan sekitarnya.",
        featured: false
    },
    {
        id: 4,
        title: "Update Data Prodeskel: Batas Akhir 30 Juli",
        category: "Pemerintahan",
        date: "05 Juli 2025",
        author: "Kasi Pemerintahan",
        image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?q=80&w=2070&auto=format&fit=crop",
        excerpt: "Kepada seluruh Operator Desa dimohon untuk segera melakukan pemutakhiran data Profil Desa dan Kelurahan (Prodeskel) sebelum tenggat waktu.",
        featured: false
    },
     {
        id: 5,
        title: "Gotong Royong Perbaikan Jembatan Desa Bentayan",
        category: "Pembangunan",
        date: "01 Juli 2025",
        author: "Humas Desa",
        image: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=2070&auto=format&fit=crop",
        excerpt: "Warga Desa Bentayan bahu-membahu memperbaiki jembatan kayu penghubung antar dusun yang rusak akibat banjir.",
        featured: false
    }
];

export const CATEGORIES = ["Semua", "Pemerintahan", "Pembangunan", "Sosial", "Kesehatan"];
