
export const serviceHistoryData = [
    {
        id: 'REQ-001',
        userId: '', // This will be replaced by the actual user ID during seeding
        type: 'Surat Keterangan Usaha',
        date: new Date('2025-07-12').toISOString(),
        status: 'Selesai',
        step: 4,
        note: 'Dokumen telah diterbitkan dan dapat diunduh.',
        fileUrl: '/documents/sku_warga_contoh_2025.pdf'
    },
    {
        id: 'REQ-002',
        userId: '',
        type: 'Pengantar KTP-El',
        date: new Date('2025-07-14').toISOString(),
        status: 'Diproses',
        step: 2,
        note: 'Menunggu verifikasi data oleh Kasi Pemerintahan.',
        fileUrl: null
    },
    {
        id: 'REQ-003',
        userId: '',
        type: 'Surat Keterangan Tidak Mampu',
        date: new Date('2025-07-10').toISOString(),
        status: 'Ditolak',
        step: 1,
        note: 'Foto KTP yang diunggah buram dan tidak terbaca. Mohon perbaiki pengajuan dengan mengunggah foto yang lebih jelas.',
        fileUrl: null
    }
];
