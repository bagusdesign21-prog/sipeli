
export type Village = {
    id: string; // Changed from number for Firestore compatibility
    name: string;
    kades: string;
    operator: string;
    luas: string;
    penduduk: string;
    kk: string;
    status: string;
    potensi: string;
    desc: string;
    imgColor: string;
};

export type Pejabat = {
    id: string;
    nama: string;
    jabatan: string;
    nip: string;
    pangkat?: string;
    eselon?: string;
    color: string;
    textColor: string;
};

export type NewsArticle = {
    id: string;
    title: string;
    category: string;
    date: string; // Should be ISO string
    author: string;
    image: string;
    excerpt: string;
    featured: boolean;
    content: string;
};

export type Announcement = {
    id: string;
    tag: 'PENTING' | 'INFO' | 'UPDATE';
    title: string;
    date: string; // Should be ISO string
    desc: string;
};

export type LegalDocument = {
  id: 'terms' | 'privacy';
  title: string;
  content: string; // HTML content
  lastUpdated: string; // ISO date string
};

export type ServiceHistory = {
    id: string;
    userId: string;
    type: string;
    date: string; // ISO date string
    status: 'Selesai' | 'Diproses' | 'Ditolak';
    step: number;
    note: string;
    fileUrl: string | null;
}
